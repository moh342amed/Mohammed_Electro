<?php
header('Content-Type: application/json');
require_once 'config.php';
requireLogin();

$response = ['status' => 'error', 'message' => 'حدث خطأ غير متوقع.'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method.';
    echo json_encode($response);
    exit();
}

// Extract and sanitize data from POST request
$customer_id = !empty($_POST['customer_id']) ? (int)$_POST['customer_id'] : null;
$prenom = sanitizeInput($_POST['prenom'] ?? '');
$nom = sanitizeInput($_POST['nom'] ?? '');
$identifiant = sanitizeInput($_POST['identifiant'] ?? '');
$ccp = sanitizeInput($_POST['ccp'] ?? '');
$cle = sanitizeInput($_POST['cle'] ?? '');
$phone = sanitizeInput($_POST['phone'] ?? '');
$address = sanitizeInput($_POST['address'] ?? '');
$creation_date = sanitizeInput($_POST['creation_date'] ?? date('Y-m-d'));
$start_date = !empty($_POST['start_date']) ? sanitizeInput($_POST['start_date']) : null;
$end_date = !empty($_POST['end_date']) ? sanitizeInput($_POST['end_date']) : null;
$installment_months = !empty($_POST['installment_months']) ? (int)$_POST['installment_months'] : null;
$deductions_per_month = !empty($_POST['deductions_per_month']) ? (int)$_POST['deductions_per_month'] : null;
$amount_int = sanitizeInput($_POST['montant'] ?? '0');
$amount_dec = sanitizeInput($_POST['montant_decimal'] ?? '00');
$total_amount = (float)($amount_int . '.' . $amount_dec);

$products = $_POST['products'] ?? [];
$branch_id = $_SESSION['branch_id'];

// Validation
if (empty($prenom) || empty($nom) || empty($identifiant) || empty($ccp) || empty($cle)) {
    $response['message'] = 'يرجى ملء جميع حقول العميل الإلزامية.';
    echo json_encode($response);
    exit();
}

$pdo->beginTransaction();

try {
    // If customer_id is not provided (manual entry), find the customer by NID and CCP.
    if (!$customer_id) {
        $stmt_find_customer = $pdo->prepare("SELECT id FROM customers WHERE national_id = ? AND ccp_account = ?");
        $stmt_find_customer->execute([$identifiant, $ccp]);
        $found_customer = $stmt_find_customer->fetch(PDO::FETCH_ASSOC);

        if ($found_customer) {
            $customer_id = (int)$found_customer['id'];
        } else {
            // If no customer is found, abort the transaction and inform the user.
            throw new Exception("هذا العميل غير موجود. يرجى إضافة العميل أولاً من خلال صفحة 'إضافة عميل جديد' قبل إنشاء عملية له.");
        }
    }

    // Step 1: Insert the main transaction
    $sql = "INSERT INTO transactions 
                (customer_id, branch_id, prenom, nom, national_id, ccp_account, ccp_key, phone, address, creation_date, start_date, end_date, amount, installment_months, deductions_per_month, status) 
            VALUES 
                (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $customer_id, $branch_id, $prenom, $nom, $identifiant, $ccp, $cle, $phone, $address, 
        $creation_date, $start_date, $end_date, $total_amount, $installment_months, $deductions_per_month
    ]);
    $transaction_id = $pdo->lastInsertId();

    // Step 2: Process products, check stock, and reduce quantity
    if (!empty($products)) {
        $stock_check_stmt = $pdo->prepare("SELECT quantity FROM branch_stock WHERE branch_id = ? AND product_id = ? FOR UPDATE");
        $stock_update_stmt = $pdo->prepare("UPDATE branch_stock SET quantity = quantity - ? WHERE branch_id = ? AND product_id = ?");
        $trans_prod_stmt = $pdo->prepare("INSERT INTO transaction_products (transaction_id, product_id, quantity, sale_price) VALUES (?, ?, ?, ?)");
        $product_name_stmt = $pdo->prepare("SELECT name FROM products WHERE id = ?");

        foreach ($products as $product) {
            $product_id = (int)$product['id'];
            $quantity_sold = (int)$product['quantity'];
            $sale_price = (float)$product['price'];

            if ($product_id <= 0 || $quantity_sold <= 0) continue;

            // Check for sufficient stock (and lock the row)
            $stock_check_stmt->execute([$branch_id, $product_id]);
            $available_stock = (int)$stock_check_stmt->fetchColumn();

            if ($available_stock < $quantity_sold) {
                $product_name_stmt->execute([$product_id]);
                $product_name = $product_name_stmt->fetchColumn();
                throw new Exception("المخزون غير كاف للمنتج '{$product_name}'. المتاح: {$available_stock}، المطلوب: {$quantity_sold}");
            }
            
            // Deduct stock
            $stock_update_stmt->execute([$quantity_sold, $branch_id, $product_id]);
            
            // Link product to the transaction
            $trans_prod_stmt->execute([$transaction_id, $product_id, $quantity_sold, $sale_price]);
        }
    }

    $pdo->commit();
    $response['status'] = 'success';
    $response['message'] = 'تم حفظ العملية بنجاح.';

} catch (Exception $e) {
    $pdo->rollBack();
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>