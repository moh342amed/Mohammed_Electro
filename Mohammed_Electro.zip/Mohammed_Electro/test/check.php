<?php

// Include the Composer autoloader to load PhpSpreadsheet
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

// Initialize variables for data processing and reporting
$results = [];
$banned_accounts = []; // This can be adapted if you have a "Banned" status
$total_paid_amount = 0.0;
$total_unpaid_amount = 0.0;
$total_failed_clients = 0;
$total_banned_clients = 0; // Or can be repurposed for other stats
$error = '';
$file_processed = false;
$months_in_file = [];

/**
 * Generates an HTML badge based on the transaction status.
 *
 * @param string $status The status text (e.g., "Pending", "Paid", "Failed").
 * @return string The HTML span element for the status badge.
 */
function get_status_badge($status) {
    $safe_status = htmlspecialchars(trim($status));
    $message = '';
    $class = '';

    // Use strtolower to make the check case-insensitive
    switch (strtolower($safe_status)) {
        case 'paid': // Assuming "Paid" is a possible status for successful transactions
            $message = 'ناجحة (مدفوعة)';
            $class = 'status-paid';
            break;
        case 'pending':
            $message = 'فاشلة (قيد الانتظار)';
            $class = 'status-failed';
            break;
        case 'failed': // A generic "Failed" status
            $message = 'فاشلة';
            $class = 'status-failed';
            break;
        default:
             $message = 'غير معروف';
             $class = 'status-info'; // A neutral class for unknown statuses
            break;
    }
    return '<span class="status-badge ' . $class . '">' . $message . '</span>';
}

// Check if a file was uploaded via POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['return_file'])) {
    // Verify that the file upload was successful
    if ($_FILES['return_file']['error'] === UPLOAD_ERR_OK) {
        $file_path = $_FILES['return_file']['tmp_name'];
        $file_extension = pathinfo($_FILES['return_file']['name'], PATHINFO_EXTENSION);

        // Ensure the file is an XLSX file
        if (strtolower($file_extension) !== 'xlsx') {
            $error = 'خطأ: يرجى رفع ملف بصيغة XLSX فقط.';
        } else {
            try {
                // Load the spreadsheet file
                $spreadsheet = IOFactory::load($file_path);
                $worksheet = $spreadsheet->getActiveSheet();
                
                $file_processed = true;
                $raw_transactions = [];
                $header_row_found = false;
                
                // Define column mapping based on your image
                $column_map = [
                    'comptea' => 'A',
                    'nom' => 'B',
                    'prenom' => 'C',
                    'montantvo' => 'J', // Column J for Amount
                    'reference' => 'N', // Column N for Reference
                    'etat' => 'P'       // Column P for Status
                ];

                // Iterate over each row in the worksheet
                foreach ($worksheet->getRowIterator() as $row) {
                    // Simple check to skip the header row
                    if ($row->getRowIndex() == 1) { 
                        continue;
                    }

                    $cell_iterator = $row->getCellIterator();
                    $cell_iterator->setIterateOnlyExistingCells(FALSE);

                    $client_account = trim($worksheet->getCell($column_map['comptea'] . $row->getRowIndex())->getValue());
                    // Skip row if the primary identifier (account number) is empty
                    if (empty($client_account)) {
                        continue;
                    }
                    
                    $last_name = trim($worksheet->getCell($column_map['nom'] . $row->getRowIndex())->getValue());
                    $first_name = trim($worksheet->getCell($column_map['prenom'] . $row->getRowIndex())->getValue());
                    $client_name = !empty($first_name) ? $first_name . ' ' . $last_name : $last_name;

                    $amount_str = trim($worksheet->getCell($column_map['montantvo'] . $row->getRowIndex())->getValue());
                    if (!is_numeric($amount_str)) continue; // Skip if amount is not numeric

                    $amount_from_file = (float)$amount_str;
                    $status = trim($worksheet->getCell($column_map['etat'] . $row->getRowIndex())->getValue());
                    $reference_id = trim($worksheet->getCell($column_map['reference'] . $row->getRowIndex())->getValue());

                    // Use current date for grouping, or adapt if a date column is available
                    $date_obj = new DateTime(); 
                    $month_key = $date_obj->format('Y-m');

                    $raw_transactions[] = [
                        'ccp' => $client_account,
                        'name' => !empty($client_name) ? $client_name : 'اسم غير متوفر',
                        'amount' => $amount_from_file,
                        'date_obj' => $date_obj,
                        'status' => $status,
                        'reference_id' => $reference_id,
                        'month_key' => $month_key
                    ];
                }

                // Process the collected transactions
                foreach ($raw_transactions as $tx) {
                    $client_key = preg_replace('/[^a-zA-Z0-9_-]/', '', $tx['name'] . $tx['ccp']);
                    $date_obj = $tx['date_obj'];
                    $status = strtolower($tx['status']);
                    $amount_from_file = $tx['amount'];

                    if ($date_obj) {
                        $month_key = $date_obj->format('Y-m');
                        if (!in_array($month_key, $months_in_file)) {
                            $months_in_file[] = $month_key;
                        }
                    }

                    if (!isset($results[$client_key])) {
                        $results[$client_key] = [
                            'name' => $tx['name'], 'ccp' => $tx['ccp'], 'count' => 0, 
                            'successful_count' => 0, 'failed_count' => 0, 
                            'total_paid_amount' => 0.0, 'total_failed_amount' => 0.0, 
                            'min_date' => $date_obj, 'max_date' => $date_obj, 'transactions' => []
                        ];
                    }

                    $results[$client_key]['count']++;
                    
                    if ($status === 'paid') { // Successful if status is 'Paid'
                        $results[$client_key]['successful_count']++;
                        $results[$client_key]['total_paid_amount'] += $amount_from_file;
                        $total_paid_amount += $amount_from_file;
                    } else { // Any other status is considered failed (e.g., "Pending")
                        $results[$client_key]['failed_count']++;
                        $results[$client_key]['total_failed_amount'] += $amount_from_file;
                        $total_unpaid_amount += $amount_from_file;
                    }
                    
                    if ($date_obj && $date_obj < $results[$client_key]['min_date']) $results[$client_key]['min_date'] = $date_obj;
                    if ($date_obj && $date_obj > $results[$client_key]['max_date']) $results[$client_key]['max_date'] = $date_obj;

                    $results[$client_key]['transactions'][] = [
                        'reference' => $tx['reference_id'], 
                        'status_html' => get_status_badge($tx['status']), 
                        'date' => $date_obj, 
                        'amount' => $amount_from_file, 
                        'is_failed' => ($status !== 'paid')
                    ];
                }
                
                // Final calculations
                foreach ($results as $client_data) {
                    if ($client_data['total_failed_amount'] > 0) {
                        $total_failed_clients++;
                    }
                }
                
                // Sort transactions within each client group by date
                foreach ($results as &$client_data) {
                    usort($client_data['transactions'], function($a, $b) {
                        if ($a['date'] == $b['date']) return 0;
                        return ($a['date'] < $b['date']) ? 1 : -1;
                    });
                }
                unset($client_data);

            } catch (Exception $e) {
                $error = 'خطأ أثناء معالجة الملف: ' . $e->getMessage();
            }
        }
    } else {
        $error = 'خطأ في رفع الملف. يرجى المحاولة مرة أخرى.';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>التحقق من حالة الاقتطاع (XLSX)</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2c3e50; --secondary-color: #3498db; --background-color: #f4f6f9;
            --card-bg-color: #ffffff; --text-color: #34495e; --heading-color: #2c3e50;
            --border-color: #eaecf1; --font-family: 'Cairo', sans-serif; --success-color: #27ae60;
            --danger-color: #e74c3c; --warning-color: #f39c12; --info-color: #7f8c8d;
            --success-bg: rgba(39, 174, 96, 0.1); --danger-bg: rgba(231, 76, 60, 0.1);
        }
        body { font-family: var(--font-family); background-color: var(--background-color); color: var(--text-color); margin: 0; line-height: 1.6; }
        .container { max-width: 1200px; margin: 2rem auto; padding: 0 1.5rem; }
        .card { background: var(--card-bg-color); border-radius: 12px; padding: 2.5rem; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08); border: 1px solid var(--border-color); }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
        h1 { font-size: 1.75rem; color: var(--heading-color); margin: 0; font-weight: 700; }
        .upload-form { background: #fafcfd; padding: 2rem; border-radius: 8px; border: 1px dashed #dae0e5; margin-bottom: 2rem; text-align: center; }
        .upload-form label { font-size: 1.1rem; font-weight: 500; margin-bottom: 1rem; display: block; }
        .btn { border: none; padding: 0.75rem 1.5rem; border-radius: 8px; cursor: pointer; font-family: var(--font-family); font-size: 1rem; font-weight: 500; transition: background-color 0.2s ease; }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: #34495e; }
        .btn-secondary { background-color: #7f8c8d; color: white; }
        .btn-secondary:hover { background-color: #95a5a6; }
        .summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.5rem; margin-bottom: 3rem; }
        .summary-box { background: var(--card-bg-color); padding: 1.5rem; border-radius: 8px; text-align: center; border: 1px solid var(--border-color); border-right: 5px solid; }
        .summary-box h3 { font-size: 2.25rem; margin: 0 0 0.5rem 0; font-weight: 700; }
        .summary-box p { font-size: 0.95rem; font-weight: 500; color: #7f8c8d; margin: 0; }
        .summary-box.paid { border-right-color: var(--success-color); }
        .summary-box.paid h3 { color: var(--success-color); }
        .summary-box.failed { border-right-color: var(--danger-color); }
        .summary-box.failed h3 { color: var(--danger-color); }
        .summary-box.warning { border-right-color: var(--warning-color); }
        .summary-box.warning h3 { color: var(--warning-color); }
        .alert-danger { background-color: var(--danger-bg); color: var(--danger-color); padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; border: 1px solid var(--danger-color);}
        h2.section-header { font-size: 1.5rem; color: var(--heading-color); margin-top: 3rem; margin-bottom: 1.5rem; padding-bottom: 0.75rem; border-bottom: 2px solid var(--border-color); }
        table { width: 100%; border-collapse: collapse; }
        .main-table { overflow: hidden; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        th, td { padding: 1rem 1.25rem; text-align: right; border-bottom: 1px solid var(--border-color); vertical-align: middle; }
        th { background-color: #f8f9fa; font-weight: 500; font-size: 0.9rem; text-transform: uppercase; color: #7f8c8d; }
        .client-row { cursor: pointer; }
        .client-row:hover { background-color: #f5f7fa; }
        .details-row > td { padding: 0 !important; background-color: #f8f9fa; }
        .details-wrapper { overflow: hidden; padding-left: 1.5rem; padding-right: 1.5rem; }
        .details-wrapper.hidden { display: none; }
        .details-wrapper.visible { display: block; padding-top: 1.5rem; padding-bottom: 1.5rem; }
        .reference-list { list-style: none; padding-right: 0; margin: 0; }
        .reference-list li { display: flex; justify-content: space-between; align-items: center; padding: 0.75rem; border-bottom: 1px solid var(--border-color); border-right: 4px solid transparent; }
        .reference-list li:last-child { border-bottom: none; }
        .reference-list li.transaction-successful { border-right-color: var(--success-color); background-color: var(--success-bg); }
        .reference-list li.transaction-failed { border-right-color: var(--danger-color); background-color: var(--danger-bg); }
        .reference-info { font-family: monospace; direction: ltr; text-align: left; font-size: 0.95rem; }
        .status-badge { padding: 0.3rem 0.8rem; border-radius: 20px; font-weight: 700; font-size: 0.8rem; white-space: nowrap; }
        .status-paid { background-color: var(--success-bg); color: var(--success-color); }
        .status-failed { background-color: var(--danger-bg); color: var(--danger-color); }
        .status-info { background-color: #ecf0f1; color: #7f8c8d; }
        .print-controls { display: flex; gap: 1rem; align-items: center; }
        .print-controls select { padding: 0.75rem; border-radius: 8px; border: 1px solid #ccc; background-color: white; }
        .total-paid { color: var(--success-color); }
        .total-unpaid { color: var(--danger-color); }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <header class="page-header no-print">
                <h1>التحقق من حالة الاقتطاع (XLSX)</h1>
                <?php if ($file_processed): ?>
                <div class="print-controls">
                    <button onclick="window.print()" class="btn btn-secondary">طباعة الملخص</button>
                </div>
                <?php endif; ?>
            </header>

            <div class="upload-form no-print">
                <form method="POST" action="" enctype="multipart/form-data">
                    <label for="return_file">ارفع ملف XLSX لبدء المعالجة</label>
                    <div>
                        <input type="file" name="return_file" id="return_file" accept=".xlsx" required>
                        <button type="submit" class="btn btn-primary">معالجة وعرض النتائج</button>
                    </div>
                </form>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger no-print"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($file_processed): ?>
                <div class="summary-grid">
                    <div class="summary-box warning">
                        <h3><?php echo $total_failed_clients; ?></h3><p>عملاء لديهم مبالغ فاشلة</p>
                    </div>
                    <div class="summary-box failed">
                        <h3 class="total-unpaid"><?php echo number_format($total_unpaid_amount, 2, '.', ','); ?></h3><p>إجمالي المبالغ الفاشلة (د.ج)</p>
                    </div>
                    <div class="summary-box paid">
                        <h3 class="total-paid"><?php echo number_format($total_paid_amount, 2, '.', ','); ?></h3><p>إجمالي المبالغ المدفوعة (د.ج)</p>
                    </div>
                </div>

                <div class="main-results">
                    <div class="screen-only">
                        <h2 class="section-header">النتائج الإجمالية للعملاء (اضغط لعرض التفاصيل)</h2>
                        <?php if (empty($results)): ?>
                            <p>لم يتم العثور على أي عمليات صالحة في الملف.</p>
                        <?php else: ?>
                            <table class="main-table">
                                <thead>
                                    <tr>
                                        <th>اسم العميل</th><th>رقم الحساب</th><th>الإجمالي</th><th>الناجحة</th><th>الفاشلة</th><th>مبلغ الفشل</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($results as $client_key => $rec): ?>
                                        <tr class="client-row" data-target-id="details-<?php echo htmlspecialchars($client_key); ?>">
                                            <td><?php echo htmlspecialchars($rec['name']); ?></td>
                                            <td><?php echo htmlspecialchars($rec['ccp']); ?></td>
                                            <td><?php echo $rec['count']; ?></td>
                                            <td><?php echo $rec['successful_count']; ?></td>
                                            <td><?php echo $rec['failed_count']; ?></td>
                                            <td class="<?php echo $rec['total_failed_amount'] == 0 ? 'total-paid' : 'total-unpaid'; ?>">
                                                <?php echo number_format($rec['total_failed_amount'], 2, '.', ','); ?> د.ج
                                            </td>
                                        </tr>
                                        <tr class="details-row" id="details-<?php echo htmlspecialchars($client_key); ?>">
                                            <td colspan="6">
                                                <div class="details-wrapper hidden">
                                                    <ul class="reference-list">
                                                        <?php foreach ($rec['transactions'] as $transaction): ?>
                                                            <li class="<?php echo $transaction['is_failed'] ? 'transaction-failed' : 'transaction-successful'; ?>">
                                                                <span class="reference-info">
                                                                    <?php echo htmlspecialchars($transaction['reference']); ?> - <?php echo number_format($transaction['amount'], 2); ?> DZD
                                                                </span>
                                                                <?php echo $transaction['status_html']; ?>
                                                            </li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.client-row').forEach(row => {
            row.addEventListener('click', () => {
                const detailsRow = document.getElementById(row.dataset.targetId);
                if (detailsRow) {
                    const wrapper = detailsRow.querySelector('.details-wrapper');
                    wrapper.classList.toggle('hidden');
                    wrapper.classList.toggle('visible');
                }
            });
        });
    });
    </script>
</body>
</html>