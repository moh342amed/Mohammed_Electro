<?php
$results = [];
$banned_accounts = [];
$total_paid_amount = 0.0;
$total_unpaid_amount = 0.0;
$total_failed_clients = 0;
$total_banned_clients = 0;
$error = '';
$file_processed = false;
$months_in_file = [];

function get_status_from_code($code) {
    $safe_code = htmlspecialchars($code);
    $message = '';
    $class = '';

    switch ($code) {
        case '0':
            $message = 'ناجحة (مدفوعة)';
            $class = 'status-paid';
            break;
        case '1':
            $message = 'فاشلة (الرصيد غير كافٍ)';
            $class = 'status-failed';
            break;
        case '2':
            $message = 'فاشلة (الحساب مجمد أو محظور)';
            $class = 'status-failed';
            break;
        case '5':
            $message = 'فاشلة (خطأ في رقم الحساب)';
            $class = 'status-failed';
            break;
        default:
            return null;
    }
    return '<span class="status-badge ' . $class . '">' . $message . '</span>';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['return_file'])) {
    if ($_FILES['return_file']['error'] === UPLOAD_ERR_OK) {
        $file_path = $_FILES['return_file']['tmp_name'];
        $file_handle = @fopen($file_path, 'r');

        if ($file_handle) {
            $file_processed = true;
            $raw_transactions = [];

            while (($line = fgets($file_handle)) !== false) {
                $line = trim($line);

                if (strlen($line) < 75) continue;

                $ccp_from_file = trim(substr($line, 0, 10));
                $client_name = trim(substr($line, 10, 27));
                $amount_str = trim(substr($line, 37, 14));
                
                if (!is_numeric($amount_str)) continue;
                
                $amount_from_file = (float)$amount_str;
                $date_from_file = trim(substr($line, 51, 10));
                $status_code = trim(substr($line, 71, 1));
                $reference_id_from_file = trim(substr($line, 74));
                
                $date_obj = DateTime::createFromFormat('d/m/Y', $date_from_file);
                $month_key = $date_obj ? $date_obj->format('Y-m') : 'unknown';

                $valid_codes = ['0', '1', '2', '5'];
                if (in_array($status_code, $valid_codes)) {
                    $raw_transactions[] = [
                        'ccp' => $ccp_from_file,
                        'name' => !empty($client_name) ? $client_name : 'اسم غير متوفر',
                        'amount' => $amount_from_file,
                        'date_obj' => $date_obj,
                        'status_code' => $status_code,
                        'reference_id' => $reference_id_from_file,
                        'month_key' => $month_key
                    ];
                }
            }
            fclose($file_handle);

            $unique_references = [];
            foreach ($raw_transactions as $tx) {
                $display_name = $tx['name'];
                $ccp = $tx['ccp'];
                $client_key = preg_replace('/[^a-zA-Z0-9_-]/', '', $display_name . $ccp);
                $ref_key = $client_key . '-' . $tx['month_key'] . '-' . $tx['reference_id'];
                
                if (!isset($unique_references[$ref_key]) || $tx['status_code'] === '0') {
                    $unique_references[$ref_key] = $tx;
                }
            }

            foreach ($unique_references as $tx) {
                $display_name = $tx['name'];
                $ccp = $tx['ccp'];
                $client_key = preg_replace('/[^a-zA-Z0-9_-]/', '', $display_name . $ccp);
                $date_obj = $tx['date_obj'];
                $status_code = $tx['status_code'];
                $amount_from_file = $tx['amount'];
                
                if ($date_obj) {
                    $month_key = $date_obj->format('Y-m');
                    if (!in_array($month_key, $months_in_file)) {
                        $months_in_file[] = $month_key;
                    }
                }

                if (!isset($results[$client_key])) {
                    $results[$client_key] = ['name' => $display_name, 'ccp' => $ccp, 'count' => 0, 'successful_count' => 0, 'failed_count' => 0, 'total_paid_amount' => 0.0, 'total_failed_amount' => 0.0, 'min_date' => $date_obj, 'max_date' => $date_obj, 'transactions' => []];
                }

                $results[$client_key]['count']++;
                
                if ($status_code === '0') {
                    $results[$client_key]['successful_count']++;
                    $results[$client_key]['total_paid_amount'] += $amount_from_file;
                    $total_paid_amount += $amount_from_file;
                } else {
                    $results[$client_key]['failed_count']++;
                    $results[$client_key]['total_failed_amount'] += $amount_from_file;
                    $total_unpaid_amount += $amount_from_file;
                }
                
                if ($date_obj && $date_obj < $results[$client_key]['min_date']) $results[$client_key]['min_date'] = $date_obj;
                if ($date_obj && $date_obj > $results[$client_key]['max_date']) $results[$client_key]['max_date'] = $date_obj;

                $results[$client_key]['transactions'][] = ['reference' => $tx['reference_id'], 'status_html' => get_status_from_code($status_code), 'date' => $date_obj, 'amount' => $amount_from_file, 'is_failed' => $status_code !== '0'];

                if ($status_code === '2') {
                    if (!isset($banned_accounts[$ccp])) {
                        $banned_accounts[$ccp] = ['name' => $display_name, 'ccp' => $ccp, 'total_failed_amount' => 0.0];
                    }
                    $banned_accounts[$ccp]['total_failed_amount'] += $amount_from_file;
                }
            }

            foreach ($results as $client_data) {
                if ($client_data['total_failed_amount'] > 0) {
                    $total_failed_clients++;
                }
            }
            $total_banned_clients = count($banned_accounts);

            rsort($months_in_file);

            foreach ($results as $client_key => &$client_data) {
                usort($client_data['transactions'], function($a, $b) {
                    if ($a['date'] == $b['date']) return 0;
                    return ($a['date'] < $b['date']) ? 1 : -1;
                });
            }
            unset($client_data);

        } else {
            $error = 'خطأ: لا يمكن فتح الملف المرفوع.';
        }
    } else {
        $error = 'خطأ في رفع الملف. يرجى المحاولة مرة أخرى.';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>التحقق من حالة الاقتطاع</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --background-color: #f4f6f9;
            --card-bg-color: #ffffff;
            --text-color: #34495e;
            --heading-color: #2c3e50;
            --border-color: #eaecf1;
            --font-family: 'Cairo', sans-serif;
            --success-color: #27ae60;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
            --info-color: #7f8c8d;
            --success-bg: rgba(39, 174, 96, 0.1);
            --danger-bg: rgba(231, 76, 60, 0.1);
        }
        *, *::before, *::after {
            box-sizing: border-box;
        }
        body { 
            font-family: var(--font-family); 
            background-color: var(--background-color); 
            color: var(--text-color); 
            margin: 0; 
            font-size: 16px;
            line-height: 1.6;
        }
        .container { 
            max-width: 1200px; 
            margin: 2rem auto; 
            padding: 0 1.5rem; 
        }
        .card { 
            background: var(--card-bg-color); 
            border-radius: 12px; 
            padding: 2.5rem; 
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08); 
            border: 1px solid var(--border-color); 
        }
        .page-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 2rem; 
            flex-wrap: wrap;
            gap: 1rem;
        }
        h1 { 
            font-size: 1.75rem;
            color: var(--heading-color); 
            margin: 0; 
            font-weight: 700;
        }
        .upload-form { 
            background: #fafcfd; 
            padding: 2rem; 
            border-radius: 8px; 
            border: 1px dashed #dae0e5; 
            margin-bottom: 2rem; 
            text-align: center; 
        }
        .upload-form label {
            font-size: 1.1rem;
            font-weight: 500;
            margin-bottom: 1rem;
            display: block;
        }
        .btn { 
            border: none; 
            padding: 0.75rem 1.5rem; 
            border-radius: 8px; 
            cursor: pointer; 
            font-family: var(--font-family); 
            font-size: 1rem;
            font-weight: 500;
            transition: background-color 0.2s ease;
        }
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        .btn-primary:hover {
            background-color: #34495e;
        }
        .btn-secondary {
            background-color: #7f8c8d;
            color: white;
        }
         .btn-secondary:hover {
            background-color: #95a5a6;
        }
        
        .summary-grid { 
            display: grid; 
            grid-template-columns: repeat(4, 1fr); 
            gap: 1.5rem; 
            margin-bottom: 3rem; 
        }
        .summary-box { 
            background: var(--card-bg-color); 
            padding: 1.5rem; 
            border-radius: 8px; 
            text-align: center; 
            border: 1px solid var(--border-color); 
            border-right: 5px solid; 
        }
        .summary-box h3 { 
            font-size: 2.25rem; 
            margin: 0 0 0.5rem 0; 
            font-weight: 700; 
        }
        .summary-box p { 
            font-size: 0.95rem; 
            font-weight: 500; 
            color: #7f8c8d;
            margin: 0;
        }
        .summary-box.paid { border-right-color: var(--success-color); }
        .summary-box.paid h3 { color: var(--success-color); }
        .summary-box.failed { border-right-color: var(--danger-color); }
        .summary-box.failed h3 { color: var(--danger-color); }
        .summary-box.warning { border-right-color: var(--warning-color); }
        .summary-box.warning h3 { color: var(--warning-color); }
        .summary-box.info { border-right-color: var(--info-color); }
        .summary-box.info h3 { color: var(--info-color); }

        h2.section-header { 
            font-size: 1.5rem; 
            color: var(--heading-color); 
            margin-top: 3rem; 
            margin-bottom: 1.5rem; 
            padding-bottom: 0.75rem; 
            border-bottom: 2px solid var(--border-color); 
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
        }
        .main-table {
            overflow: hidden;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }
        th, td { 
            padding: 1rem 1.25rem; 
            text-align: right; 
            border-bottom: 1px solid var(--border-color); 
            vertical-align: middle; 
        }
        th { 
            background-color: #f8f9fa; 
            font-weight: 500; 
            font-size: 0.9rem;
            text-transform: uppercase;
            color: #7f8c8d;
        }
        .main-table > tbody > tr:last-child > td {
            border-bottom: none;
        }
        
        .client-row { 
            cursor: pointer; 
        }
        .client-row:hover { background-color: #f5f7fa; }
        .details-row > td { 
            padding: 0 !important;
            background-color: #f8f9fa;
        }
        .details-wrapper {
            overflow: hidden;
            padding-left: 1.5rem;
            padding-right: 1.5rem;
        }
        .details-wrapper.hidden {
            display: none;
        }
        .details-wrapper.visible {
            display: block;
            padding-top: 1.5rem;
            padding-bottom: 1.5rem;
        }
        
        .month-header { 
            font-size: 1.1rem; 
            font-weight: 700; 
            color: var(--heading-color); 
            margin: 1.5rem 0 1rem 0; 
            padding-bottom: 0.5rem; 
            border-bottom: 1px solid var(--border-color);
        }
        .amount-group-frame { 
            border: 1px solid #eaecf1; 
            border-radius: 8px; 
            padding: 1.25rem; 
            margin-bottom: 1rem; 
            background-color: var(--card-bg-color); 
        }
        .amount-group-header { 
            font-weight: 700; 
            color: #34495e; 
            margin-bottom: 0.75rem; 
        }
        .reference-list { list-style: none; padding-right: 0; margin: 0; }
        .reference-list li { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            padding: 0.75rem; 
            border-bottom: 1px solid var(--border-color);
            border-right: 4px solid transparent;
        }
        .reference-list li:last-child { border-bottom: none; }
        .reference-list li.transaction-successful {
            border-right-color: var(--success-color);
            background-color: var(--success-bg);
        }
        .reference-list li.transaction-failed {
            border-right-color: var(--danger-color);
            background-color: var(--danger-bg);
        }
        .reference-info { font-family: monospace; direction: ltr; text-align: left; font-size: 0.95rem; }

        .banned-section { margin-top: 3rem; padding-top: 2rem; border-top: 2px solid var(--primary-color); }
        .banned-table th { background-color: var(--danger-bg); color: var(--danger-color); }

        .status-badge { padding: 0.3rem 0.8rem; border-radius: 20px; font-weight: 700; font-size: 0.8rem; white-space: nowrap; }
        .status-paid { background-color: var(--success-bg); color: var(--success-color); }
        .status-failed { background-color: var(--danger-bg); color: var(--danger-color); }

        .print-controls { display: flex; gap: 1rem; align-items: center; }
        .print-controls select { padding: 0.75rem; border-radius: 8px; border: 1px solid #ccc; background-color: white; }
        .print-only { display: none; }
        
        .total-paid { color: var(--success-color); }
        .total-unpaid { color: var(--danger-color); }
        
        @media (max-width: 992px) {
            .summary-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        @media (max-width: 576px) {
            .summary-grid {
                grid-template-columns: 1fr;
            }
        }

        @media print {
            body { margin: 0; padding: 0; background-color: #fff !important; font-size: 10pt; }
            .no-print, .screen-only { display: none !important; }
            .print-only { display: block !important; }
            .container, .card { margin: 0 !important; padding: 1cm !important; border: none !important; box-shadow: none !important; }
            h1, h2, h3, p, th, td, span { color: #000 !important; }
            table { box-shadow: none !important; border-radius: 0 !important; }

            .print-table th { font-size: 9pt; padding: 8px; }
            .print-table td { font-size: 9pt; padding: 8px; vertical-align: top; }
            .print-table td div { line-height: 1.5; }
            
            .print-only-successful .failed-transaction,
            .print-only-successful .banned-section { display: none; }
            
            .print-only-failed .successful-transaction,
            .print-only-failed .summary-box.paid { display: none; }

            .print-only-banned .main-results, 
            .print-only-banned .summary-grid { display: none; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <header class="page-header no-print">
                <h1>التحقق من حالة الاقتطاع</h1>
                <?php if ($file_processed): ?>
                <div class="print-controls">
                    <select id="print-filter">
                        <option value="all">طباعة ملخص شامل</option>
                        <option value="successful">ملخص العمليات الناجحة فقط</option>
                        <option value="failed">ملخص العمليات الفاشلة فقط</option>
                        <option value="banned">الحسابات المجمدة فقط (مفصل)</option>
                    </select>
                    <button id="print-button" class="btn btn-secondary">طباعة</button>
                </div>
                <?php endif; ?>
            </header>

            <div class="upload-form no-print">
                <form method="POST" action="" enctype="multipart/form-data">
                    <label for="return_file">ارفع ملف TXT لبدء المعالجة</label>
                    <div>
                        <input type="file" name="return_file" id="return_file" required>
                        <button type="submit" class="btn btn-primary">معالجة وعرض النتائج</button>
                    </div>
                </form>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger no-print"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($file_processed): ?>
                <div class="summary-grid">
                    <div class="summary-box info">
                        <h3><?php echo $total_banned_clients; ?></h3><p>حسابات مجمدة/محظورة</p>
                    </div>
                     <div class="summary-box warning">
                        <h3><?php echo $total_failed_clients; ?></h3><p>عملاء لديهم مبالغ فاشلة</p>
                    </div>
                    <div class="summary-box failed">
                        <h3 class="total-unpaid"><?php echo number_format($total_unpaid_amount, 2, '.', ','); ?></h3><p>إجمالي المبالغ الفاشلة (د.ج)</p>
                    </div>
                    <div class="summary-box paid">
                        <h3 class="total-paid"><?php echo number_format($total_paid_amount, 2, '.', ','); ?></h3><p>إجمالي المبالغ المدفوعة (د.ج)</p>
                    </div>
                </div>

                <div class="main-results">
                    <div class="screen-only">
                        <h2 class="section-header">النتائج الإجمالية للعملاء (اضغط لعرض التفاصيل)</h2>
                        <?php if (empty($results)): ?>
                            <p>لم يتم العثور على أي عمليات.</p>
                        <?php else: ?>
                            <table class="main-table">
                                <thead>
                                    <tr>
                                        <th>اسم العميل</th><th>رقم الحساب</th><th>الإجمالي</th><th>الناجحة</th><th>الفاشلة</th><th>مبلغ الفشل</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($results as $client_key => $rec): ?>
                                        <tr class="client-row" data-target-id="details-<?php echo htmlspecialchars($client_key); ?>">
                                            <td><?php echo htmlspecialchars($rec['name']); ?></td><td><?php echo htmlspecialchars($rec['ccp']); ?></td><td><?php echo $rec['count']; ?></td><td><?php echo $rec['successful_count']; ?></td><td><?php echo $rec['failed_count']; ?></td><td class="<?php echo $rec['total_failed_amount'] == 0 ? 'total-paid' : 'total-unpaid'; ?>"><?php echo number_format($rec['total_failed_amount'], 2, '.', ','); ?> د.ج</td>
                                        </tr>
                                        <tr class="details-row" id="details-<?php echo htmlspecialchars($client_key); ?>">
                                            <td colspan="6">
                                                <div class="details-wrapper hidden">
                                                    <?php
                                                        $grouped_transactions = [];
                                                        foreach ($rec['transactions'] as $transaction) {
                                                            $month_key = $transaction['date'] ? $transaction['date']->format('Y-m') : 'unknown';
                                                            $amount_key = number_format($transaction['amount'], 2, '.', ',');
                                                            $grouped_transactions[$month_key][$amount_key][] = $transaction;
                                                        }
                                                    ?>
                                                    <?php foreach ($grouped_transactions as $month_key => $amount_groups): ?>
                                                        <h3 class="month-header">
                                                            <?php 
                                                                setlocale(LC_TIME, 'ar_AR.utf8', 'ar.utf8', 'ar');
                                                                echo ($month_key === 'unknown') ? 'تواريخ غير معروفة' : 'شهر ' . strftime('%B %Y', strtotime($month_key . '-01'));
                                                            ?>
                                                        </h3>
                                                        <?php foreach ($amount_groups as $amount => $transactions): ?>
                                                            <div class="amount-group-frame">
                                                                <div class="amount-group-header">المبلغ: <?php echo $amount; ?> د.ج (<?php echo count($transactions); ?> عملية)</div>
                                                                <ul class="reference-list">
                                                                    <?php foreach ($transactions as $transaction): ?>
                                                                        <li class="<?php echo $transaction['is_failed'] ? 'transaction-failed' : 'transaction-successful'; ?>">
                                                                            <span class="reference-info"><?php echo htmlspecialchars($transaction['reference']); ?></span>
                                                                            <?php echo $transaction['status_html']; ?>
                                                                        </li>
                                                                    <?php endforeach; ?>
                                                                </ul>
                                                            </div>
                                                        <?php endforeach; ?>
                                                    <?php endforeach; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>

                    <div class="print-only">
                        <h2 class="section-header">ملخص العمليات</h2>
                        <table class="print-table">
                           <thead>
                                <tr>
                                    <th>العميل</th><th>رقم الحساب</th><th>العمليات الناجحة</th><th>العمليات الفاشلة</th><th>فترة العمليات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($results as $rec): ?>
                                    <tr class="successful-transaction">
                                        <td><?php echo htmlspecialchars($rec['name']); ?></td>
                                        <td><?php echo htmlspecialchars($rec['ccp']); ?></td>
                                        <td><div><?php echo $rec['successful_count']; ?> عملية</div><div><?php echo number_format($rec['total_paid_amount'], 2, '.', ','); ?> د.ج</div></td>
                                        <td></td>
                                        <td>
                                            <?php if($rec['min_date'] && $rec['max_date']): ?>
                                                <?php if($rec['min_date']->format('Y-m-d') == $rec['max_date']->format('Y-m-d')): ?>
                                                    في <?php echo $rec['min_date']->format('d/m/Y'); ?>
                                                <?php else: ?>
                                                    من <?php echo $rec['min_date']->format('d/m/Y'); ?> إلى <?php echo $rec['max_date']->format('d/m/Y'); ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr class="failed-transaction">
                                        <td><?php echo htmlspecialchars($rec['name']); ?></td>
                                        <td><?php echo htmlspecialchars($rec['ccp']); ?></td>
                                        <td></td>
                                        <td><div><?php echo $rec['failed_count']; ?> عملية</div><div><?php echo number_format($rec['total_failed_amount'], 2, '.', ','); ?> د.ج</div></td>
                                        <td>
                                            <?php if($rec['min_date'] && $rec['max_date']): ?>
                                                <?php if($rec['min_date']->format('Y-m-d') == $rec['max_date']->format('Y-m-d')): ?>
                                                    في <?php echo $rec['min_date']->format('d/m/Y'); ?>
                                                <?php else: ?>
                                                    من <?php echo $rec['min_date']->format('d/m/Y'); ?> إلى <?php echo $rec['max_date']->format('d/m/Y'); ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <?php if (!empty($banned_accounts)): ?>
                    <div class="banned-section">
                        <h2 class="section-header">الحسابات المجمدة أو المحظورة</h2>
                        <table class="banned-table">
                             <thead><tr><th>اسم العميل</th><th>رقم الحساب</th><th>مجموع المبالغ الفاشلة</th></tr></thead>
                            <tbody>
                                <?php foreach ($banned_accounts as $account): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($account['name']); ?></td><td><?php echo htmlspecialchars($account['ccp']); ?></td><td><?php echo number_format($account['total_failed_amount'], 2, '.', ','); ?> د.ج</td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.client-row').forEach(row => {
            row.addEventListener('click', () => {
                const detailsRow = document.getElementById(row.dataset.targetId);
                if (detailsRow) {
                    const wrapper = detailsRow.querySelector('.details-wrapper');
                    if (wrapper.classList.contains('hidden')) {
                        wrapper.classList.remove('hidden');
                        wrapper.classList.add('visible');
                    } else {
                        wrapper.classList.remove('visible');
                        wrapper.classList.add('hidden');
                    }
                }
            });
        });

        const printButton = document.getElementById('print-button');
        if (printButton) {
            printButton.addEventListener('click', () => {
                const filter = document.getElementById('print-filter').value;
                document.body.className = '';
                
                if (filter === 'successful') {
                    document.body.classList.add('print-only-successful');
                } else if (filter === 'failed') {
                    document.body.classList.add('print-only-failed');
                } else if (filter === 'banned') {
                    document.body.classList.add('print-only-banned');
                }
                
                window.print();
            });
        }
    });
    </script>
</body>
</html>