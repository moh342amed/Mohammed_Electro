<?php
require_once 'config.php';
requireLogin();

// Get branch info
$branch = getBranchInfo($pdo, $_SESSION['branch_id']);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Using a modern font from Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <title>نظام إدارة العملاء - <?php echo htmlspecialchars($branch['name']); ?></title>
    <style>
        :root {
            --primary-color: #161332ff;
            --secondary-color: #d1d1f7;
            --background-color: #f0f2f5;
            --card-bg-color: rgba(255, 255, 255, 0.6);
            --text-color: #333;
            --header-text-color: #ffffff;
            --shadow-color: rgba(106, 90, 249, 0.2);
            --success-color: #20c997;
            --error-color: #e45858;
            --font-family: 'Cairo', sans-serif;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: var(--font-family);
            background-color: var(--background-color);
            line-height: 1.6;
            color: var(--text-color);
            background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        /* Entrance Animation */
        @keyframes fadeInSlideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #8A2BE2 100%);
            color: var(--header-text-color);
            padding: 1.5rem 2rem;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        
        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .header h1 {
            font-size: 1.8rem;
            font-weight: 700;
        }
        
        .branch-info {
            font-size: 1rem;
            opacity: 0.9;
        }
        
        .logout-btn {
            background: rgba(255, 255, 255, 0.15);
            color: var(--header-text-color);
            padding: 0.6rem 1.2rem;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        
        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }
        
        .card {
            background: var(--card-bg-color);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 30px var(--shadow-color);
            border: 1px solid rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: fadeInSlideUp 0.5s ease-out forwards;
        }

        .card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 35px var(--shadow-color);
        }
        
        .card h3 {
            color: var(--text-color);
            margin-bottom: 1.5rem;
            font-size: 1.3rem;
            font-weight: 700;
            border-bottom: 3px solid var(--primary-color);
            padding-bottom: 0.75rem;
        }
        
        .search-form {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .form-group {
            flex-grow: 1;
        }
        
        .form-group input {
            width: 100%;
            padding: 0.8rem 1rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            font-family: var(--font-family);
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px var(--secondary-color);
        }
        
        .btn {
            background: var(--primary-color);
            color: white;
            padding: 0.8rem 1.8rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
            font-weight: 500;
            font-size: 1rem;
        }
        
        .btn:hover {
            background: #5848e8;
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(106, 90, 249, 0.4);
        }
        
        .quick-actions {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .quick-actions a {
            text-align: center;
            padding: 1rem;
            background: transparent;
            color: var(--primary-color);
            text-decoration: none;
            border-radius: 8px;
            border: 2px solid var(--primary-color);
            transition: all 0.3s ease;
            font-size: 1.1rem;
            font-weight: 500;
        }
        
        .quick-actions a:hover {
            background: var(--primary-color);
            color: white;
            transform: translateY(-3px);
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }
            .search-form {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <div>
                <h1>نظام إدارة العملاء</h1>
                <div class="branch-info">
                    <?php echo htmlspecialchars($branch['name']); ?> - <?php echo htmlspecialchars($branch['location']); ?>
                </div>
            </div>
            <a href="logout.php" class="logout-btn">تسجيل الخروج</a>
        </div>
    </header>
    
    <div class="container">
        <div class="dashboard-grid">
            <div class="card" style="animation-delay: 0.1s;">
                <h3>البحث عن العملاء</h3>
                <form class="search-form" action="search.php" method="GET">
                    <div class="form-group">
                        <input type="text" id="search_term" name="search_term" placeholder="ابحث بالاسم، الهاتف، رقم الحساب...">
                    </div>
                    <button type="submit" class="btn">بحث</button>
                </form>
            </div>
            
            <div class="card" style="animation-delay: 0.2s;">
                <h3>الإجراءات السريعة</h3>
                <div class="quick-actions">
                    <a href="add_customer.php">إضافة عميل جديد</a>
                    <a href="ccp_automation.php">انشاء وثيقة جديدة</a>
                    <a href="transactions.php">عرض العمليات</a>
                    <?php if ($branch['username'] === 'ElOued'): ?>
                        <a href="delinquent_payments.php" class="btn">عرض تقرير المتأخرات</a>
                        <a href="inventory.php">لوحة تحكم المخزون</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>