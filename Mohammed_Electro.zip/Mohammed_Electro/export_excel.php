<?php
require_once 'config.php';
requireLogin();

require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Cell\DataType;

$filter_year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
$filter_month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');

try {
    // --- MODIFICATION START ---
    // The query now selects transactions based on THEIR START DATE, not their sub-transaction dates.
    // This is the core of the requested change.
    $sql = "SELECT t.*, c.first_name, c.last_name 
            FROM transactions t 
            LEFT JOIN customers c ON t.customer_id = c.id 
            WHERE t.status = 'confirmed' 
            AND t.start_date IS NOT NULL
            AND YEAR(t.start_date) = ? 
            AND MONTH(t.start_date) = ?";
    // --- MODIFICATION END ---
            
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$filter_year, $filter_month]);
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($transactions)) {
        header("Content-Type: text/html; charset=utf-8");
        die('<script>alert("لا توجد عمليات جديدة بدأت في الشهر المحدد للتصدير."); window.history.back();</script>');
    }

    $transaction_ids = array_column($transactions, 'id');
    
    // Get the sub-transactions for the selected month that belong to the transactions found above.
    $in_query = implode(',', array_fill(0, count($transaction_ids), '?'));
    $sub_sql = "SELECT * FROM sub_transactions 
                WHERE transaction_id IN ($in_query) 
                AND YEAR(deduction_date) = ? 
                AND MONTH(deduction_date) = ? 
                ORDER BY transaction_id, sub_reference_id";
                
    $stmt_sub = $pdo->prepare($sub_sql);
    $params = array_merge($transaction_ids, [$filter_year, $filter_month]);
    $stmt_sub->execute($params);
    $sub_transactions_all = $stmt_sub->fetchAll(PDO::FETCH_ASSOC);

    if (empty($sub_transactions_all)) {
        header("Content-Type: text/html; charset=utf-8");
        die('<script>alert("لا توجد اقتطاعات مجدولة لهذا الشهر للعمليات الجديدة."); window.history.back();</script>');
    }
    
    $transaction_map = [];
    foreach($transactions as $tx) {
        $transaction_map[$tx['id']] = $tx;
    }

    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $spreadsheet->getDefaultStyle()->getFont()->setName('Arial')->setSize(10);

    // Set Column Dimensions
    $sheet->getColumnDimension('A')->setWidth(15);
    $sheet->getColumnDimension('B')->setWidth(5);
    $sheet->getColumnDimension('C')->setWidth(20);
    $sheet->getColumnDimension('D')->setWidth(20);
    $sheet->getColumnDimension('E')->setWidth(15);
    $sheet->getColumnDimension('F')->setWidth(12);
    $sheet->getColumnDimension('G')->setWidth(5);
    $sheet->getColumnDimension('H')->setWidth(15);
    $sheet->getColumnDimension('I')->setWidth(15);
    $sheet->getColumnDimension('J')->setWidth(15);
    $sheet->getColumnDimension('K')->setWidth(10);
    $sheet->getColumnDimension('L')->setWidth(12);
    $sheet->getColumnDimension('M')->setWidth(10);
    $sheet->getColumnDimension('N')->setWidth(30);

    // Set Headers
    $headers = ['CompteA', 'CLE', 'NOM', 'PRENOM', 'MontantVO', 'CompteB', 'CLE', 'DateDebut', 'DateFin', 'DateCreation', 'MoisTraite', 'Nbrecheance', 'JourPrel', 'Reference'];
    $sheet->fromArray($headers, NULL, 'A1');

    // Fill data rows
    $row_num = 2;
    foreach ($sub_transactions_all as $sub) {
        if (!isset($transaction_map[$sub['transaction_id']])) continue;
        $tx = $transaction_map[$sub['transaction_id']];

        $nom = strtoupper($tx['nom'] ?: $tx['last_name']);
        $prenom = strtoupper($tx['prenom'] ?: $tx['first_name']);
        
        $sheet->setCellValue('A'.$row_num, (float)$tx['ccp_account']);
        $sheet->setCellValue('B'.$row_num, strtoupper($tx['ccp_key']));
        $sheet->setCellValue('C'.$row_num, $nom);
        $sheet->setCellValue('D'.$row_num, $prenom);
        $sheet->setCellValue('E'.$row_num, (float)$sub['monthly_deduction_amount']);
        $sheet->setCellValue('F'.$row_num, (float)'21008203');
        $sheet->setCellValue('G'.$row_num, (int)'86');
        $sheet->setCellValue('H'.$row_num, $tx['start_date'] ? Date::PHPToExcel(strtotime($tx['start_date'])) : null);
        $sheet->setCellValue('I'.$row_num, $tx['end_date'] ? Date::PHPToExcel(strtotime($tx['end_date'])) : null);
        $sheet->setCellValue('J'.$row_num, Date::PHPToExcel(strtotime($tx['creation_date']))); // Using creation_date from DB
        $sheet->getCell('K' . $row_num)->setValueExplicit(0, DataType::TYPE_NUMERIC);
        $sheet->setCellValue('L'.$row_num, (int)$tx['installment_months']);
        $sheet->setCellValue('M'.$row_num, (int)'30');
        $sheet->setCellValue('N'.$row_num, strtoupper($sub['sub_reference_id']));

        $row_num++;
    }
    
    // Define style array
    $styleArray = [
        'font' => ['bold' => true],
        'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
        'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['argb' => 'FF000000']]],
    ];

    // Apply styles
    $sheet->getStyle("A1:N" . ($row_num - 1))->applyFromArray($styleArray);
    $sheet->getStyle('A2:A' . ($row_num - 1))->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_NUMBER);
    $sheet->getStyle('E2:E' . ($row_num - 1))->getNumberFormat()->setFormatCode('#,##0.00');
    $sheet->getStyle('F2:F' . ($row_num - 1))->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_NUMBER);
    $sheet->getStyle('G2:G' . ($row_num - 1))->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_NUMBER);
    $sheet->getStyle('H2:J' . ($row_num - 1))->getNumberFormat()->setFormatCode('dd-mm-yyyy');
    $sheet->getStyle('K2:M' . ($row_num - 1))->getNumberFormat()->setFormatCode('0');

    // Output the file
    $filename = "Export_New_Deductions_" . $filter_year . "_" . str_pad($filter_month, 2, '0', STR_PAD_LEFT) . ".xlsx";
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');
    
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit();

} catch (Exception $e) {
    die('Error exporting to Excel: ' . $e->getMessage());
}
?>