<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مستخرج الحسابات المحظورة</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #161332;
            --secondary-color: #6a5af9;
            --background-color: #f0f2f5;
            --card-bg-color: rgba(255, 255, 255, 0.8);
            --text-color: #333;
            --header-text-color: #ffffff;
            --shadow-color: rgba(22, 19, 50, 0.15);
            --font-family: 'Cairo', sans-serif;
            --status-failed-bg: #f8d7da; 
            --status-failed-text: #58151c;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: var(--font-family); background-color: var(--background-color); line-height: 1.6; color: var(--text-color); background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); }
        .header { background: var(--primary-color); color: var(--header-text-color); padding: 1rem 1.5rem; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); }
        .header-content { max-width: 900px; margin: 0 auto; text-align: center; }
        .header h1 { font-size: 1.8rem; }
        .container { max-width: 900px; margin: 2rem auto; padding: 0 1rem; }
        .card { background: var(--card-bg-color); border-radius: 15px; padding: 2.5rem; box-shadow: 0 10px 30px var(--shadow-color); border: 1px solid rgba(255, 255, 255, 0.8); backdrop-filter: blur(10px); }
        .page-header { margin-bottom: 2rem; text-align: center; }
        .page-header p { font-size: 1.1rem; color: #555; }
        .upload-section { text-align: center; margin-bottom: 2rem; }
        .file-input {
            border: 2px dashed var(--secondary-color);
            padding: 2rem;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .file-input:hover {
            background-color: rgba(106, 90, 249, 0.05);
        }
        .file-input input[type="file"] {
            display: none;
        }
        .file-input label {
            font-weight: 700;
            color: var(--primary-color);
            font-size: 1.2rem;
        }
        #status-message {
            margin-top: 1rem;
            font-weight: 500;
            font-size: 1rem;
        }
        .table-responsive { overflow-x: auto; margin-top: 1rem; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 1rem; text-align: right; border-bottom: 1px solid #ddd; }
        th { background-color: rgba(22, 19, 50, 0.05); font-weight: 700; }
        tbody tr:hover { background-color: rgba(230, 230, 250, 0.7); }
        .no-results td { text-align: center; padding: 2rem; font-size: 1.1rem; color: #666; }
        .highlight {
            background-color: var(--status-failed-bg);
            color: var(--status-failed-text);
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1>أداة استخراج الحسابات المحظورة</h1>
        </div>
    </header>
    
    <div class="container">
        <div class="card">
            <div class="page-header">
                <p>اختر ملف التسديد النصي (.txt) لعرض قائمة العملاء الذين لديهم حسابات محظورة (الحالة رقم 2).</p>
            </div>

            <div class="upload-section">
                <label for="fileInput" class="file-input">
                    <span>انقر هنا لاختيار ملف</span>
                </label>
                <input type="file" id="fileInput" accept=".txt, text/plain">
                <p id="status-message">في انتظار اختيار ملف...</p>
            </div>

            <div class="table-responsive">
                 <table>
                    <thead>
                        <tr>
                            <th>اسم العميل</th>
                            <th>رقم حساب CCP</th>
                        </tr>
                    </thead>
                    <tbody id="results-table-body">
                        <tr class="no-results">
                            <td colspan="2">لم يتم عرض أي نتائج بعد.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const fileInput = document.getElementById('fileInput');
        const resultsBody = document.getElementById('results-table-body');
        const statusMessage = document.getElementById('status-message');

        fileInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (!file) {
                statusMessage.textContent = 'لم يتم اختيار أي ملف.';
                return;
            }

            statusMessage.textContent = `جاري معالجة الملف: ${file.name}...`;
            resultsBody.innerHTML = ''; // Clear previous results

            const reader = new FileReader();

            reader.onload = function(e) {
                const lines = e.target.result.split('\n');
                const bannedAccounts = {}; // Use an object to store unique accounts

                lines.forEach(line => {
                    // Line must be at least 72 characters long to have a status code
                    if (line.length < 72) {
                        return;
                    }

                    // The status code is the 72nd character (index 71)
                    const statusCode = line.substring(71, 72).trim();

                    if (statusCode === '2') {
                        // Based on standard formats, parse the beginning of the line
                        // Adjust these indexes if the bank's return file format differs
                        const ccpAccount = line.substring(0, 10).trim();
                        // Assume name is in a fixed-width block after the CCP
                        const clientName = line.substring(10, 40).trim().replace(/\s\s+/g, ' ');

                        if (clientName && ccpAccount) {
                            // Store by CCP to ensure each banned account appears only once
                            bannedAccounts[ccpAccount] = { name: clientName, ccp: ccpAccount };
                        }
                    }
                });

                // Convert the unique accounts object back to an array
                const resultsArray = Object.values(bannedAccounts);
                displayResults(resultsArray);
            };

            reader.onerror = function() {
                statusMessage.textContent = 'حدث خطأ أثناء قراءة الملف.';
                resultsBody.innerHTML = '<tr class="no-results"><td colspan="2">فشلت قراءة الملف.</td></tr>';
            };

            reader.readAsText(file, 'ISO-8859-1'); // Use a common encoding for such files
        });

        function displayResults(accounts) {
            if (accounts.length === 0) {
                statusMessage.textContent = 'اكتملت المعالجة. لم يتم العثور على أي حسابات محظورة (الحالة 2).';
                resultsBody.innerHTML = '<tr class="no-results"><td colspan="2">لا توجد نتائج.</td></tr>';
                return;
            }

            statusMessage.textContent = `تم العثور على ${accounts.length} حساب محظور:`;
            
            accounts.forEach(acc => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td class="highlight">${acc.name}</td>
                    <td class="highlight">${acc.ccp}</td>
                `;
                resultsBody.appendChild(row);
            });
        }
    });
    </script>
</body>
</html>