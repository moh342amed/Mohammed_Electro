<?php
require_once 'config.php';

// FIX: Set the correct timezone for all date operations in this script
date_default_timezone_set('Africa/Algiers');

requireLogin();
$branch = getBranchInfo($pdo, $_SESSION['branch_id']);
if ($branch['username'] !== 'ElOued') {
    die('Access Denied: This page is for the main branch only.');
}

// --- DATE FILTERING (Now timezone-aware) ---
$period = $_GET['period'] ?? 'month';
$start_date_input = $_GET['start_date'] ?? '';
$end_date_input = $_GET['end_date'] ?? '';

if ($period === 'today') {
    $start_date = date('Y-m-d');
    $end_date = date('Y-m-d');
} elseif ($period === 'week') {
    $start_date = date('Y-m-d', strtotime('monday this week'));
    $end_date = date('Y-m-d', strtotime('sunday this week'));
} elseif ($period === 'month') {
    $start_date = date('Y-m-01');
    $end_date = date('Y-m-t');
} elseif ($period === 'year') {
    $start_date = date('Y-01-01');
    $end_date = date('Y-12-31');
} else { // This handles the 'custom' case
    // If custom dates are provided via the form, use them.
    // Otherwise, default to the current month.
    $start_date = !empty($start_date_input) ? $start_date_input : date('Y-m-01');
    $end_date = !empty($end_date_input) ? $end_date_input : date('Y-m-t');
    
    // If we used the fallback dates, ensure the 'period' variable is not misleadingly 'custom'
    if (empty($start_date_input) && empty($end_date_input) && $period === 'custom') {
        $period = 'month';
    }
}

// --- DATA FETCHING ---

// 1. Sales Ranking by Branch
$ranking_sql = "
    SELECT 
        b.name as branch_name,
        b.id as branch_id,
        COALESCE(SUM(tp.quantity), 0) as items_sold,
        COALESCE(SUM(tp.quantity * tp.sale_price), 0) as total_revenue
    FROM branches b
    LEFT JOIN transactions t ON b.id = t.branch_id AND DATE(t.creation_date) BETWEEN ? AND ?
    LEFT JOIN transaction_products tp ON t.id = tp.transaction_id
    GROUP BY b.id, b.name
    ORDER BY total_revenue DESC
";
$ranking_stmt = $pdo->prepare($ranking_sql);
$ranking_stmt->execute([$start_date, $end_date]);
$sales_ranking = $ranking_stmt->fetchAll(PDO::FETCH_ASSOC);

// 2. Branch-Specific Inventory
$stock_sql = "SELECT b.name as branch_name, p.name as product_name, bs.quantity 
              FROM branch_stock bs
              JOIN branches b ON bs.branch_id = b.id
              JOIN products p ON bs.product_id = p.id
              WHERE bs.quantity > 0
              ORDER BY b.name, p.name";
$stock_data_raw = $pdo->query($stock_sql)->fetchAll(PDO::FETCH_ASSOC);
$branch_inventory = [];
foreach($stock_data_raw as $row) {
    $branch_inventory[$row['branch_name']][] = $row;
}

// 3. Total Stock for each product across all branches
$total_stock_sql = "
    SELECT 
        p.name as product_name, 
        SUM(bs.quantity) as total_quantity
    FROM branch_stock bs
    JOIN products p ON bs.product_id = p.id
    GROUP BY p.id, p.name
    HAVING SUM(bs.quantity) > 0
    ORDER BY p.name ASC
";
$total_product_stock = $pdo->query($total_stock_sql)->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم المخزون</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #161332ff;
            --secondary-color: #d1d1f7;
            --background-color: #f0f2f5;
            --card-bg-color: rgba(255, 255, 255, 0.6);
            --text-color: #333;
            --header-text-color: #ffffff;
            --shadow-color: rgba(106, 90, 249, 0.2);
            --font-family: 'Cairo', sans-serif;
            --success-color: #28a745;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: var(--font-family);
            background-color: var(--background-color);
            line-height: 1.6;
            color: var(--text-color);
            background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        .header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #8A2BE2 100%);
            color: var(--header-text-color);
            padding: 1.5rem 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .header-content {
            max-width: 1600px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header-content a {
            color: var(--header-text-color);
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: background 0.3s ease;
        }
        .header-content a:hover {
            background: rgba(255, 255, 255, 0.15);
        }
        .container { max-width: 1600px; margin: 2rem auto; padding: 0 2rem; }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .page-header h1 { color: var(--primary-color); font-size: 2.2rem; }
        .header-actions { display: flex; gap: 1rem; }
        .btn {
            padding: 0.75rem 1.5rem;
            color: #fff;
            text-decoration: none;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        .btn-primary { background: var(--primary-color); }
        .btn-secondary { background: var(--success-color); }
        .card {
            background: var(--card-bg-color);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 30px var(--shadow-color);
            border: 1px solid rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            margin-bottom: 2.5rem;
        }
        .filter-bar { display: flex; flex-wrap: wrap; align-items: flex-end; gap: 1.5rem; }
        .filter-bar .form-group { display: flex; flex-direction: column; }
        .filter-bar label { margin-bottom: 0.5rem; font-size: 0.9rem; font-weight: 500; }
        .filter-bar input, .filter-bar select {
            padding: 0.7rem 1rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-family: var(--font-family);
            font-size: 1rem;
        }
        .filter-bar .period-buttons { display: flex; gap: 0.5rem; }
        .filter-bar .period-buttons a {
            padding: 0.7rem 1rem;
            background-color: #fff;
            border: 2px solid #ddd;
            text-decoration: none;
            color: var(--text-color);
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .filter-bar .period-buttons a.active {
            background-color: var(--primary-color);
            color: #fff;
            border-color: var(--primary-color);
            font-weight: 700;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .section-title { font-size: 1.8rem; color: var(--primary-color); margin-bottom: 1.5rem; padding-bottom: 0.5rem; border-bottom: 3px solid var(--primary-color); }
        .table-responsive { overflow-x: auto; }
        .ranking-table { width: 100%; border-collapse: collapse; }
        .ranking-table th, .ranking-table td { padding: 1rem 1.25rem; text-align: right; border-bottom: 1px solid #ddd; vertical-align: middle; }
        .ranking-table th { background: rgba(22, 19, 50, 0.05); font-size: 1rem; }
        .ranking-table tbody tr.branch-row:hover { background-color: rgba(230, 230, 250, 0.7); }
        .ranking-table tbody tr.branch-row { cursor: pointer; }
        .rank-badge {
            font-size: 1.2rem;
            font-weight: 700;
            color: #fff;
            background-color: #6c757d;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .rank-1 { background: #ffc107; color: #000; }
        .rank-2 { background: #ced4da; color: #000; }
        .rank-3 { background: #cd7f32; }
        
        .sales-details-row td { padding: 0; }
        .details-container {
            background-color: #f8f9fa;
            padding: 0 2.5rem;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.5s ease-in-out, padding 0.5s ease-in-out;
        }
        .details-container.details-open {
            padding: 1.5rem 2.5rem;
            max-height: 1000px;
        }
        .details-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }
        .details-table th, .details-table td { padding: 0.75rem 1rem; border-bottom: 1px solid #e9ecef; }
        .details-table th { background-color: #e2e3e5; font-weight: 600; }
        .details-table tr:last-child td { border-bottom: none; }

        .inventory-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 1.5rem; }
        .inventory-card { background: #fff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease; }
        .inventory-card:hover { transform: translateY(-5px); box-shadow: 0 8px 25px rgba(0,0,0,0.12); }
        .inventory-card h3 { background: var(--primary-color); color: #fff; padding: 1rem 1.5rem; margin: 0; font-size: 1.2rem; }
        .inventory-card table { width: 100%; border-collapse: collapse; }
        .inventory-card th, .inventory-card td { padding: 0.75rem 1.5rem; text-align: right; border-bottom: 1px solid #eee; }
        .inventory-card tr:last-child td { border-bottom: none; }

        .total-stock-display { padding: 1rem 1.5rem; text-align: center; }
        .total-stock-display span { display: block; font-size: 0.9rem; color: #6c757d; }
        .total-stock-display strong { font-size: 2rem; color: var(--primary-color); font-weight: 700; }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1>لوحة تحكم المخزون</h1>
            <a href="index.php">العودة للرئيسية</a>
        </div>
    </header>

    <div class="container">
        <div class="page-header">
            <div class="header-actions">
                <a href="manage_stock_purchase.php" class="btn btn-primary">إضافة دفعة مخزون جديدة</a>
                <a href="manage_products.php" class="btn btn-secondary">إدارة أنواع المنتجات</a>
            </div>
        </div>
        
        <div class="card">
            <form method="GET">
                <div class="filter-bar">
                    <div class="form-group period-buttons">
                        <label>تحديد سريع للفترة</label>
                        <div class="period-buttons">
                            <a href="?period=today" class="<?php if($period == 'today') echo 'active'; ?>">اليوم</a>
                            <a href="?period=week" class="<?php if($period == 'week') echo 'active'; ?>">هذا الأسبوع</a>
                            <a href="?period=month" class="<?php if($period == 'month') echo 'active'; ?>">هذا الشهر</a>
                            <a href="?period=year" class="<?php if($period == 'year') echo 'active'; ?>">هذه السنة</a>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="start_date">من تاريخ</label>
                        <input type="date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>" onchange="document.querySelector('input[name=period]').value='custom'">
                    </div>
                    <div class="form-group">
                        <label for="end_date">إلى تاريخ</label>
                        <input type="date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>" onchange="document.querySelector('input[name=period]').value='custom'">
                    </div>
                    <div class="form-group">
                        <label> </label>
                        <button type="submit" class="btn btn-primary">تطبيق الفلتر</button>
                        <input type="hidden" name="period" value="<?php echo htmlspecialchars($period); ?>">
                    </div>
                </div>
            </form>
        </div>

        <div class="card">
            <h2 class="section-title">ترتيب الفروع حسب المبيعات (<?php echo date('d M Y', strtotime($start_date)) . ' - ' . date('d M Y', strtotime($end_date)); ?>)</h2>
            <div class="table-responsive">
                <table class="ranking-table">
                    <thead>
                        <tr>
                            <th>الترتيب</th>
                            <th>الفرع</th>
                            <th>عدد القطع المباعة</th>
                            <th>إجمالي الإيرادات</th>
                        </tr>
                    </thead>
                    <tbody id="sales-ranking-body">
                        <?php if (empty($sales_ranking) || array_sum(array_column($sales_ranking, 'items_sold')) == 0): ?>
                            <tr><td colspan="4" style="text-align: center; padding: 2rem;">لا توجد بيانات مبيعات في الفترة المحددة.</td></tr>
                        <?php else: ?>
                            <?php foreach ($sales_ranking as $index => $rank_data): $rank = $index + 1; ?>
                            <tr class="branch-row" data-branch-name="<?php echo htmlspecialchars($rank_data['branch_name']); ?>">
                                <td><span class="rank-badge rank-<?php echo $rank; ?>"><?php echo $rank; ?></span></td>
                                <td><strong><?php echo htmlspecialchars($rank_data['branch_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($rank_data['items_sold']); ?> قطعة</td>
                                <td style="font-weight: bold;"><?php echo number_format($rank_data['total_revenue'], 2); ?> د.ج</td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card">
            <h2 class="section-title">إجمالي المخزون حسب المنتج (كل الفروع)</h2>
            <div class="inventory-grid">
                <?php if(empty($total_product_stock)): ?>
                    <p style="text-align: center; grid-column: 1 / -1; padding: 1rem;">لا يوجد مخزون مسجل لأي منتج حالياً.</p>
                <?php else: ?>
                    <?php foreach($total_product_stock as $item): ?>
                    <div class="inventory-card">
                        <h3><?php echo htmlspecialchars($item['product_name']); ?></h3>
                        <div class="total-stock-display">
                            <span>الكمية الإجمالية المتاحة</span>
                            <strong><?php echo htmlspecialchars($item['total_quantity']); ?></strong>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <h2 class="section-title">المخزون الحالي في الفروع</h2>
        <div class="inventory-grid">
            <?php if(empty($branch_inventory)): ?>
                <div class="card"><p style="text-align: center;">لا يوجد مخزون مسجل في أي فرع حالياً.</p></div>
            <?php else: ?>
                <?php foreach($branch_inventory as $branch_name => $stock_items): ?>
                <div class="inventory-card">
                    <h3><?php echo htmlspecialchars($branch_name); ?></h3>
                    <table>
                        <thead><tr><th>المنتج</th><th style="text-align: center;">الكمية المتاحة</th></tr></thead>
                        <tbody>
                        <?php foreach($stock_items as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                <td style="text-align: center;"><strong><?php echo htmlspecialchars($item['quantity']); ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tableBody = document.getElementById('sales-ranking-body');
    const startDate = '<?php echo $start_date; ?>';
    const endDate = '<?php echo $end_date; ?>';

    tableBody.addEventListener('click', async function(event) {
        const clickedRow = event.target.closest('.branch-row');
        if (!clickedRow) return;

        const branchName = clickedRow.dataset.branchName;
        const existingDetailsRow = clickedRow.nextElementSibling;

        if (existingDetailsRow && existingDetailsRow.classList.contains('sales-details-row')) {
            const container = existingDetailsRow.querySelector('.details-container');
            container.classList.remove('details-open');
            container.addEventListener('transitionend', () => {
                existingDetailsRow.remove();
            }, { once: true });
            return;
        }

        document.querySelectorAll('.sales-details-row').forEach(row => {
            const container = row.querySelector('.details-container');
            container.classList.remove('details-open');
            container.addEventListener('transitionend', () => {
                row.remove();
            }, { once: true });
        });

        try {
            const response = await fetch(`api_get_branch_sales_details.php?branch=${encodeURIComponent(branchName)}&start=${startDate}&end=${endDate}`);
            if (!response.ok) throw new Error('Network response was not ok');
            const salesDetails = await response.json();

            const detailsRow = document.createElement('tr');
            detailsRow.classList.add('sales-details-row');

            let detailsHtml = '<td colspan="4"><div class="details-container">';

            if (salesDetails.length > 0) {
                detailsHtml += `
                    <table class="details-table">
                        <thead>
                            <tr>
                                <th>المنتج</th>
                                <th style="text-align: center;">الكمية</th>
                                <th>سعر البيع</th>
                                <th>العميل</th>
                            </tr>
                        </thead>
                        <tbody>`;
                salesDetails.forEach(sale => {
                    const customerName = `${sale.first_name} ${sale.last_name}`;
                    const salePrice = parseFloat(sale.sale_price).toLocaleString('fr-FR', { style: 'currency', currency: 'DZD' });
                    detailsHtml += `
                        <tr>
                            <td>${sale.product_name}</td>
                            <td style="text-align: center;">${sale.quantity}</td>
                            <td>${salePrice}</td>
                            <td>${customerName}</td>
                        </tr>`;
                });
                detailsHtml += '</tbody></table>';
            } else {
                detailsHtml += '<p style="text-align:center; padding: 1rem;">لا توجد تفاصيل مبيعات لهذا الفرع في الفترة المحددة.</p>';
            }

            detailsHtml += '</div></td>';
            detailsRow.innerHTML = detailsHtml;
            clickedRow.after(detailsRow);

            setTimeout(() => {
                const newContainer = detailsRow.querySelector('.details-container');
                newContainer.classList.add('details-open');
            }, 10);

        } catch (error) {
            console.error('Failed to fetch sales details:', error);
        }
    });
});
</script>
</body>
</html>