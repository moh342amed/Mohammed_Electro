<?php
require_once 'config.php';
requireLogin();
$branch = getBranchInfo($pdo, $_SESSION['branch_id']);
if ($branch['username'] !== 'ElOued') {
    die('Access Denied: This page is for the main branch only.');
}

$products = $pdo->query("SELECT id, name FROM products ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$branches = $pdo->query("SELECT id, name FROM branches ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

$all_purchases_stmt = $pdo->query("SELECT id, purchase_date, supplier FROM stock_purchases ORDER BY purchase_date DESC, id DESC");
$all_purchases = $all_purchases_stmt->fetchAll(PDO::FETCH_ASSOC);

$edit_mode = false;
$purchase_data = [
    'id' => null,
    'purchase_date' => date('Y-m-d'),
    'supplier' => '',
    'products' => []
];

if (isset($_GET['success'])) {
    $message = "تم حفظ دفعة المخزون بنجاح.";
}

if (isset($_GET['purchase_id'])) {
    $edit_mode = true;
    $purchase_id = (int)$_GET['purchase_id'];

    $stmt = $pdo->prepare("SELECT * FROM stock_purchases WHERE id = ?");
    $stmt->execute([$purchase_id]);
    $purchase = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($purchase) {
        $purchase_data['id'] = $purchase['id'];
        $purchase_data['purchase_date'] = $purchase['purchase_date'];
        $purchase_data['supplier'] = $purchase['supplier'];

        $stmt = $pdo->prepare("SELECT * FROM stock_distribution WHERE purchase_id = ?");
        $stmt->execute([$purchase_id]);
        $distributions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $products_in_purchase = [];
        foreach ($distributions as $dist) {
            $products_in_purchase[$dist['product_id']]['distributions'][$dist['branch_id']] = [
                'quantity' => $dist['quantity'],
                'price' => $dist['cash_selling_price']
            ];
        }
        $purchase_data['products'] = $products_in_purchase;
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $purchase_date = $_POST['purchase_date'];
    $supplier = $_POST['supplier'];
    $posted_products = $_POST['products'] ?? [];
    $purchase_id_to_edit = isset($_POST['purchase_id']) ? (int)$_POST['purchase_id'] : null;

    $pdo->beginTransaction();
    try {
        if ($purchase_id_to_edit) {
            $stmt = $pdo->prepare("UPDATE stock_purchases SET purchase_date = ?, supplier = ? WHERE id = ?");
            $stmt->execute([$purchase_date, $supplier, $purchase_id_to_edit]);

            $old_dist_stmt = $pdo->prepare("SELECT branch_id, product_id, quantity FROM stock_distribution WHERE purchase_id = ?");
            $old_dist_stmt->execute([$purchase_id_to_edit]);
            $old_distributions = $old_dist_stmt->fetchAll(PDO::FETCH_ASSOC);

            $reverse_stock_stmt = $pdo->prepare("UPDATE branch_stock SET quantity = quantity - ? WHERE branch_id = ? AND product_id = ?");
            foreach ($old_distributions as $dist) {
                $reverse_stock_stmt->execute([$dist['quantity'], $dist['branch_id'], $dist['product_id']]);
            }
            
            $delete_stmt = $pdo->prepare("DELETE FROM stock_distribution WHERE purchase_id = ?");
            $delete_stmt->execute([$purchase_id_to_edit]);
            
            $purchase_id = $purchase_id_to_edit;
        } else {
            $stmt = $pdo->prepare("INSERT INTO stock_purchases (purchase_date, supplier) VALUES (?, ?)");
            $stmt->execute([$purchase_date, $supplier]);
            $purchase_id = $pdo->lastInsertId();
        }

        $dist_stmt = $pdo->prepare("INSERT INTO stock_distribution (purchase_id, product_id, branch_id, quantity, cash_selling_price) VALUES (?, ?, ?, ?, ?)");
        $stock_stmt = $pdo->prepare("INSERT INTO branch_stock (branch_id, product_id, quantity) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)");
        
        foreach ($posted_products as $p) {
            $product_id = (int)$p['id'];
            foreach ($p['distribution'] as $branch_id => $dist_data) {
                $quantity = (int)($dist_data['quantity'] ?? 0);
                $price = (float)($dist_data['price'] ?? 0);

                if ($quantity > 0) {
                    $dist_stmt->execute([$purchase_id, $product_id, (int)$branch_id, $quantity, $price]);
                    $stock_stmt->execute([(int)$branch_id, $product_id, $quantity]);
                }
            }
        }
        
        $pdo->commit();
        
        if ($purchase_id_to_edit) {
             header("Location: manage_stock_purchase.php?purchase_id=" . $purchase_id_to_edit . "&success_edit=1");
        } else {
             header("Location: manage_stock_purchase.php?success=1");
        }
        exit;

    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "فشل العملية: " . $e->getMessage();
    }
}

if (isset($_GET['success_edit'])) {
    $message = "تم تحديث دفعة المخزون بنجاح.";
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $edit_mode ? 'تعديل' : 'إدارة'; ?> دفعات المخزون</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #161332ff;
            --secondary-color: #d1d1f7;
            --background-color: #f0f2f5;
            --card-bg-color: rgba(255, 255, 255, 0.6);
            --text-color: #333;
            --header-text-color: #ffffff;
            --shadow-color: rgba(106, 90, 249, 0.2);
            --font-family: 'Cairo', sans-serif;
            --success-color: #28a745;
            --error-color: #dc3545;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: var(--font-family);
            background-color: var(--background-color);
            line-height: 1.6;
            color: var(--text-color);
            background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        .header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #8A2BE2 100%);
            color: var(--header-text-color);
            padding: 1.5rem 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .header-content { max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; }
        .header-content a { color: var(--header-text-color); text-decoration: none; font-weight: 500; padding: 0.5rem 1rem; border-radius: 8px; transition: background 0.3s ease; }
        .header-content a:hover { background: rgba(255, 255, 255, 0.15); }
        .container { max-width: 1200px; margin: 2rem auto; padding: 0 2rem; }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; }
        .page-header h1 { color: var(--primary-color); }
        .card { background: var(--card-bg-color); border-radius: 15px; padding: 2.5rem; box-shadow: 0 10px 30px var(--shadow-color); border: 1px solid rgba(255, 255, 255, 0.8); backdrop-filter: blur(10px); }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; margin-bottom: .5rem; font-weight: 500; font-size: 0.9rem; color: #444; }
        input, select { width: 100%; padding: 0.8rem 1rem; border: 2px solid #ddd; border-radius: 8px; font-size: 1rem; font-family: var(--font-family); transition: border-color 0.3s ease, box-shadow 0.3s ease; }
        input:focus, select:focus { outline: none; border-color: var(--primary-color); box-shadow: 0 0 0 3px var(--secondary-color); }
        input[readonly] { background-color: #e9ecef; cursor: not-allowed; font-weight: bold; color: var(--primary-color); }
        .btn { padding: 0.8rem 1.5rem; color: #fff; text-decoration: none; border: none; border-radius: 8px; cursor: pointer; font-size: 1rem; font-weight: 500; transition: all 0.3s ease; }
        .btn:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        .btn-primary { background: var(--primary-color); }
        .btn-secondary { background: #6c757d; }
        .btn-add { background: var(--success-color); }
        .btn-remove { background: var(--error-color); padding: 0.5rem; width: 45px; height: 45px; font-size: 1.5rem; line-height: 1; }
        .alert { padding: 1rem; margin-bottom: 1.5rem; border-radius: 8px; border-left: 5px solid; }
        .alert.success { background: #d4edda; color: #155724; border-color: #155724; }
        .alert.error { background: #f8d7da; color: #721c24; border-color: #721c24; }
        .product-entry-row { background: rgba(255,255,255,0.5); border: 2px solid #e0e0e0; padding: 1.5rem; border-radius: 12px; margin-bottom: 1.5rem; }
        .product-main-fields { display: grid; grid-template-columns: 1fr auto; gap: 1rem; align-items: flex-end; }
        .distribution-fields { margin-top: 1.5rem; padding-top: 1.5rem; border-top: 2px dashed var(--secondary-color); }
        .distribution-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; font-weight: bold; }
        .dist-total-display { background-color: var(--secondary-color); color: var(--primary-color); padding: 0.25rem 0.75rem; border-radius: 6px; font-size: 0.9rem; }
        .distribution-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1.5rem; }
        .branch-dist-group { display: flex; gap: 0.5rem; align-items: center; }
        .branch-dist-group .form-group { flex: 1; }
        .form-actions { margin-top: 2rem; display: flex; justify-content: space-between; align-items: center; }
        .table-responsive { overflow-x: auto; margin-top: 1.5rem; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 0.8rem 1rem; text-align: right; border-bottom: 1px solid #ddd; }
        th { background-color: rgba(22, 19, 50, 0.05); font-weight: 700; }
        tbody tr:hover { background-color: #f5f5f5; }
        .btn-edit { background-color: #0d6efd; padding: 0.4rem 0.8rem; font-size: 0.9rem; }
        tr.editing { background-color: var(--secondary-color) !important; font-weight: bold; }
        tr.editing td { color: var(--primary-color); }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1><?php echo $edit_mode ? 'تعديل' : 'إدارة'; ?> دفعات المخزون</h1>
            <a href="inventory.php">العودة للوحة التحكم</a>
        </div>
    </header>

    <div class="container">
        <div class="card">
            <h2><?php echo $edit_mode ? 'تعديل دفعة موجودة' : 'إضافة دفعة جديدة'; ?></h2>
            <p style="margin-bottom: 2rem; color: #555;"><?php echo $edit_mode ? 'قم بتعديل بيانات الدفعة أدناه. سيتم عكس الكميات القديمة وإضافة الكميات الجديدة للمخزون.' : 'أدخل بيانات دفعة الشراء الجديدة لتوزيعها على الفروع.'; ?></p>

            <?php if(isset($message)): ?><div class="alert success"><?php echo $message; ?></div><?php endif; ?>
            <?php if(isset($error)): ?><div class="alert error"><?php echo $error; ?></div><?php endif; ?>

            <form method="POST" action="manage_stock_purchase.php<?php echo $edit_mode ? '?purchase_id=' . $purchase_data['id'] : ''; ?>">
                <?php if ($edit_mode): ?>
                    <input type="hidden" name="purchase_id" value="<?php echo $purchase_data['id']; ?>">
                <?php endif; ?>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                    <div class="form-group">
                        <label for="purchase_date">تاريخ الشراء</label>
                        <input type="date" name="purchase_date" required value="<?php echo htmlspecialchars($purchase_data['purchase_date']); ?>">
                    </div>
                    <div class="form-group">
                        <label for="supplier">المورد (اختياري)</label>
                        <input type="text" name="supplier" placeholder="اسم المورد" value="<?php echo htmlspecialchars($purchase_data['supplier']); ?>">
                    </div>
                </div>
                
                <hr style="margin: 1rem 0 2rem; border: 0; border-top: 1px solid var(--secondary-color);">

                <div id="products-container">
                </div>

                <div class="form-actions">
                    <button type="button" id="add-product-row" class="btn btn-add">+ إضافة منتج آخر للدفعة</button>
                    <button type="submit" class="btn btn-primary"><?php echo $edit_mode ? 'تحديث' : 'حفظ'; ?> الدفعة</button>
                </div>
            </form>
        </div>
        
        <div class="card" style="margin-top: 2rem;">
            <h2>سجل دفعات المخزون</h2>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>رقم الدفعة</th>
                            <th>تاريخ الشراء</th>
                            <th>المورد</th>
                            <th>إجراء</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($all_purchases)): ?>
                            <tr><td colspan="4" style="text-align: center; padding: 2rem;">لم يتم إضافة أي دفعات بعد.</td></tr>
                        <?php else: ?>
                            <?php foreach ($all_purchases as $p): ?>
                                <tr class="<?php echo ($edit_mode && $purchase_data['id'] == $p['id']) ? 'editing' : ''; ?>">
                                    <td><?php echo $p['id']; ?></td>
                                    <td><?php echo htmlspecialchars($p['purchase_date']); ?></td>
                                    <td><?php echo htmlspecialchars($p['supplier'] ?: 'N/A'); ?></td>
                                    <td>
                                        <a href="manage_stock_purchase.php?purchase_id=<?php echo $p['id']; ?>" class="btn btn-edit">تعديل</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <template id="product-row-template">
        <div class="product-entry-row">
            <div class="product-main-fields">
                <div class="form-group">
                    <label>المنتج</label>
                    <select class="product-select" name="products[__INDEX__][id]" required>
                        <option value="">-- اختر --</option>
                        <?php foreach($products as $product): ?>
                            <option value="<?php echo $product['id']; ?>"><?php echo htmlspecialchars($product['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="button" class="btn btn-remove" title="إزالة هذا المنتج" onclick="this.closest('.product-entry-row').remove()">×</button>
            </div>
            <div class="distribution-fields">
                <div class="distribution-header">
                    <label>توزيع هذا المنتج (الكمية والسعر لكل فرع):</label>
                    <span class="dist-total-display">المجموع: 0</span>
                </div>
                <div class="distribution-grid">
                    <?php foreach($branches as $b): ?>
                    <div class="form-group">
                        <label><?php echo htmlspecialchars($b['name']); ?></label>
                        <div class="branch-dist-group">
                           <div class="form-group">
                             <input type="number" class="distribution-input-quantity" name="products[__INDEX__][distribution][<?php echo $b['id']; ?>][quantity]" min="0" value="0" placeholder="الكمية">
                           </div>
                           <div class="form-group">
                             <input type="number" step="0.01" name="products[__INDEX__][distribution][<?php echo $b['id']; ?>][price]" min="0" value="0.00" placeholder="سعر البيع">
                           </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </template>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        let productIndex = 0;
        const container = document.getElementById('products-container');
        const template = document.getElementById('product-row-template');
        const isEditMode = <?php echo json_encode($edit_mode); ?>;
        const purchaseData = <?php echo json_encode($purchase_data['products']); ?>;

        function addRow(productId = null, distributions = null) {
            const clone = template.content.cloneNode(true);
            const newRowHtml = clone.firstElementChild.outerHTML.replace(/__INDEX__/g, productIndex);
            container.insertAdjacentHTML('beforeend', newRowHtml);
            
            const newRowNode = container.lastElementChild;

            if (productId) {
                newRowNode.querySelector('.product-select').value = productId;
            }
            if (distributions) {
                for (const branchId in distributions) {
                    const distData = distributions[branchId];
                    const quantityInput = newRowNode.querySelector(`input[name="products[${productIndex}][distribution][${branchId}][quantity]"]`);
                    const priceInput = newRowNode.querySelector(`input[name="products[${productIndex}][distribution][${branchId}][price]"]`);
                    if (quantityInput) quantityInput.value = distData.quantity;
                    if (priceInput) priceInput.value = distData.price;
                }
            }
            
            updateTotals(newRowNode);
            productIndex++;
            return newRowNode;
        }

        function updateTotals(productRow) {
            const quantityInputs = productRow.querySelectorAll('.distribution-input-quantity');
            let total = 0;
            quantityInputs.forEach(input => {
                total += parseInt(input.value, 10) || 0;
            });
            productRow.querySelector('.dist-total-display').textContent = `المجموع: ${total}`;
        }

        container.addEventListener('input', function(event) {
            if (event.target.classList.contains('distribution-input-quantity')) {
                const productRow = event.target.closest('.product-entry-row');
                updateTotals(productRow);
            }
        });

        document.getElementById('add-product-row').addEventListener('click', () => addRow());
        
        if (isEditMode) {
            if (Object.keys(purchaseData).length > 0) {
                for (const productId in purchaseData) {
                    addRow(productId, purchaseData[productId].distributions);
                }
            } else {
                 addRow();
            }
        } else {
            addRow();
        }
    });
    </script>
</body>
</html>