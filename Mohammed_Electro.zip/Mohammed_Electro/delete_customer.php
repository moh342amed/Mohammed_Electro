<?php
require_once 'config.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['customer_id'])) {
    $_SESSION['error'] = 'طلب غير صالح.';
    header('Location: search.php');
    exit();
}

$customer_id = (int)$_POST['customer_id'];

if ($customer_id <= 0) {
    $_SESSION['error'] = 'معرف عميل غير صالح.';
    header('Location: search.php');
    exit();
}

$pdo->beginTransaction();

try {
    // Step 1: Get all transaction IDs for the customer
    $stmt_get_tx = $pdo->prepare("SELECT id FROM transactions WHERE customer_id = ?");
    $stmt_get_tx->execute([$customer_id]);
    $transaction_ids = $stmt_get_tx->fetchAll(PDO::FETCH_COLUMN);

    if (!empty($transaction_ids)) {
        // Create placeholders for the IN clause
        $placeholders = implode(',', array_fill(0, count($transaction_ids), '?'));

        // Step 2: Delete from payment_history
        $stmt_del_history = $pdo->prepare("
            DELETE FROM payment_history 
            WHERE sub_transaction_id IN (
                SELECT id FROM sub_transactions WHERE transaction_id IN ($placeholders)
            )
        ");
        $stmt_del_history->execute($transaction_ids);

        // Step 3: Delete from sub_transactions
        $stmt_del_subs = $pdo->prepare("DELETE FROM sub_transactions WHERE transaction_id IN ($placeholders)");
        $stmt_del_subs->execute($transaction_ids);

        // Step 4: Delete from transactions
        $stmt_del_txs = $pdo->prepare("DELETE FROM transactions WHERE id IN ($placeholders)");
        $stmt_del_txs->execute($transaction_ids);
    }
    
    // Step 5: Delete the customer
    $stmt_del_customer = $pdo->prepare("DELETE FROM customers WHERE id = ?");
    $stmt_del_customer->execute([$customer_id]);
    
    // Check if the customer was actually deleted
    if ($stmt_del_customer->rowCount() > 0) {
        $_SESSION['message'] = 'تم حذف العميل وكل سجلاته المرتبطة بنجاح.';
    } else {
        throw new Exception('لم يتم العثور على العميل للحذف.');
    }
    
    $pdo->commit();

} catch (Exception $e) {
    $pdo->rollBack();
    $_SESSION['error'] = 'حدث خطأ أثناء الحذف: ' . $e->getMessage();
}

header('Location: search.php');
exit();