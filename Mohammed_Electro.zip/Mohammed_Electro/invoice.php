<?php
require_once 'config.php';
requireLogin();

// 1. Validate the transaction ID from the URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die('Identifiant de transaction invalide.');
}
$transaction_id = (int)$_GET['id'];

// 2. Fetch all required data in a single query
$sql = "SELECT 
            t.id as transaction_id,
            t.amount,
            t.installment_months,
            t.deductions_per_month,
            t.created_at,
            t.confirmed_at,
            t.ccp_account,
            t.ccp_key,
            COALESCE(c.first_name, t.prenom) as first_name,
            COALESCE(c.last_name, t.nom) as last_name,
            COALESCE(c.national_id, t.national_id) as national_id,
            c.address,
            b.name as branch_name,
            b.location as branch_location
        FROM transactions t
        LEFT JOIN customers c ON t.customer_id = c.id
        JOIN branches b ON t.branch_id = b.id
        WHERE t.id = ? AND t.status = 'confirmed'";

$stmt = $pdo->prepare($sql);
$stmt->execute([$transaction_id]);
$invoice = $stmt->fetch(PDO::FETCH_ASSOC);

// 3. If no confirmed transaction is found, exit gracefully
if (!$invoice) {
    die('Facture introuvable pour cette transaction confirmée.');
}

// 4. Prepare data for display
$customer_full_name = htmlspecialchars($invoice['first_name'] . ' ' . $invoice['last_name']);
$invoice_date = date("d/m/Y", strtotime($invoice['confirmed_at'] ?: $invoice['created_at']));
$monthly_payment = ($invoice['amount'] && $invoice['installment_months']) 
    ? number_format($invoice['amount'] / $invoice['installment_months'], 2, ',', ' ') 
    : 'N/A';
$total_amount_formatted = number_format($invoice['amount'], 2, ',', ' ');
?>
<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facture N° #<?php echo htmlspecialchars($invoice['transaction_id']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            direction: ltr;
        }
        .invoice-box {
            max-width: 800px;
            margin: auto;
            padding: 30px;
            border: 1px solid #eee;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
            font-size: 16px;
            line-height: 24px;
            color: #555;
            background-color: #fff;
        }
        .invoice-header {
            border-bottom: 2px solid #161332;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        .company-details p {
            margin: 0;
            font-size: 0.9em;
        }
        .company-details h1 {
            margin: 0 0 10px 0;
            font-size: 1.8rem;
            color: #161332;
        }
        .invoice-main-title {
            text-align: center;
            margin-bottom: 30px;
        }
        .invoice-main-title h2 {
            margin: 0;
            font-size: 2.8rem;
            font-weight: 700;
            color: #333;
        }
        .invoice-main-title p {
            margin: 5px 0 0 0;
            font-size: 1em;
        }
        .details-grid {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
            text-align: left;
        }
        .details-grid div {
            flex: 1;
        }
        .details-grid h3 {
            color: #161332;
            margin-bottom: 10px;
            border-bottom: 1px solid #eee;
            padding-bottom: 5px;
        }
        .details-grid p {
            margin: 0 0 5px 0;
        }
        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }
        .invoice-table thead tr {
            background-color: #161332;
            color: #fff;
        }
        .invoice-table th, .invoice-table td {
            padding: 12px 15px;
        }
        .invoice-table th:last-child, .invoice-table td:last-child {
             text-align: right;
        }
        .invoice-table tbody tr {
            border-bottom: 1px solid #eee;
        }
        .invoice-table tbody tr:last-child {
            border-bottom: 2px solid #161332;
        }
        .invoice-table tfoot td {
            padding-top: 15px;
            font-weight: bold;
            font-size: 1.2em;
            text-align: right;
        }
        .invoice-footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            color: #777;
            font-size: 0.9em;
        }
        .print-button-container {
            text-align: center;
            margin: 20px 0;
        }
        .print-button {
            padding: 10px 25px;
            font-size: 16px;
            font-family: 'Cairo', sans-serif;
            background-color: #198754;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .print-button:hover {
            background-color: #157347;
        }

        @media print {
            /* --- START: NEW CODE BLOCK TO REMOVE BROWSER FOOTER --- */
            @page {
                size: auto;
                margin: 0; 
            }
            /* --- END: NEW CODE BLOCK --- */

            body {
                background-color: #fff;
                padding: 1cm; /* Add a clean margin for printing */
            }
            .invoice-box {
                box-shadow: none;
                border: none;
                padding: 0;
                width: 100%;
                max-width: 100%;
            }
            .print-button-container {
                display: none;
            }
        }
    </style>
</head>
<body>

    <div class="print-button-container">
        <button onclick="window.print()" class="print-button">Imprimer la Facture</button>
    </div>

    <div class="invoice-box">
        <div class="invoice-header">
            <div class="company-details">
                <h1>ETS GHILANI MOHAMMED TAHAR</h1>
                <p><strong>Registre Commerce (RCN):</strong> 39/07-2758649A20</p>
                <p><strong>Numéro Identité Fiscale (NIF):</strong> 19139010331915803904</p>
            </div>
        </div>

        <div class="invoice-main-title">
            <h2>FACTURE</h2>
            <p><strong>Facture N°:</strong> #<?php echo htmlspecialchars($invoice['transaction_id']); ?></p>
            <p><strong>Date d'émission:</strong> <?php echo $invoice_date; ?></p>
        </div>

        <div class="details-grid">
            <div class="from-details">
                <h3>De :</h3>
                <p><strong><?php echo htmlspecialchars($invoice['branch_name']); ?></strong></p>
                <p><?php echo htmlspecialchars($invoice['branch_location']); ?></p>
            </div>
            <div class="to-details">
                <h3>À :</h3>
                <p><strong><?php echo $customer_full_name; ?></strong></p>
                <p><strong>N° d'identification national:</strong> <?php echo htmlspecialchars($invoice['national_id']); ?></p>
                <p><strong>Compte CCP:</strong> <?php echo htmlspecialchars($invoice['ccp_account']); ?></p>
                <?php if ($invoice['address']): ?>
                    <p><?php echo nl2br(htmlspecialchars($invoice['address'])); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <table class="invoice-table">
            <thead>
                <tr>
                    <th>Description</th>
                    <th>Durée</th>
                    <th>Montant Mensuel</th>
                    <th>Sous-total</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Achat par facilité de paiement via prélèvement CCP</td>
                    <td><?php echo htmlspecialchars($invoice['installment_months']); ?> mois</td>
                    <td><?php echo $monthly_payment; ?> DA</td>
                    <td><?php echo $total_amount_formatted; ?> DA</td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3">Montant Total</td>
                    <td><?php echo $total_amount_formatted; ?> DA</td>
                </tr>
            </tfoot>
        </table>

        <div class="invoice-footer">
            <p>Nous vous remercions de votre confiance.</p>
        </div>
    </div>

</body>
</html>