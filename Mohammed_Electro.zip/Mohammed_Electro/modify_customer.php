<?php
require_once 'config.php';
requireLogin();

$customer_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$message = '';
$error = '';

if (!$customer_id) {
    header('Location: search.php');
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
$stmt->execute([$customer_id]);
$customer = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$customer) {
    header('Location: search.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = sanitizeInput($_POST['first_name']);
    $last_name = sanitizeInput($_POST['last_name']);
    $national_id = sanitizeInput($_POST['national_id']);
    $ccp_account = sanitizeInput($_POST['ccp_account']);
    $ccp_key = sanitizeInput($_POST['ccp_key']);
    $phone = sanitizeInput($_POST['phone']);
    $address = sanitizeInput($_POST['address']);

    $stmt = $pdo->prepare("SELECT id FROM customers WHERE (ccp_account = ? OR phone = ? OR national_id = ?) AND id != ?");
    $stmt->execute([$ccp_account, $phone, $national_id, $customer_id]);

    if ($stmt->fetch()) {
        $error = 'عميل آخر بنفس رقم الحساب البريدي، الهاتف، أو رقم التعريف الوطني موجود مسبقاً.';
    } else {
        $sql = "UPDATE customers SET 
                    first_name = ?, 
                    last_name = ?, 
                    national_id = ?, 
                    ccp_account = ?, 
                    ccp_key = ?, 
                    phone = ?, 
                    address = ? 
                WHERE id = ?";
        
        $stmt = $pdo->prepare($sql);

        if ($stmt->execute([$first_name, $last_name, $national_id, $ccp_account, $ccp_key, $phone, $address, $customer_id])) {
            $message = 'تم تحديث بيانات العميل بنجاح.';
            $stmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
            $stmt->execute([$customer_id]);
            $customer = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $error = 'حدث خطأ أثناء تحديث بيانات العميل.';
        }
    }
}

$branch = getBranchInfo($pdo, $_SESSION['branch_id']);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل العميل - <?php echo htmlspecialchars($branch['name']); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #161332ff;
            --secondary-color: #d1d1f7;
            --background-color: #f0f2f5;
            --card-bg-color: rgba(255, 255, 255, 0.65);
            --text-color: #333;
            --header-text-color: #ffffff;
            --shadow-color: rgba(106, 90, 249, 0.2);
            --success-color: #20c997;
            --error-color: #e45858;
            --font-family: 'Cairo', sans-serif;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: var(--font-family);
            background-color: var(--background-color);
            line-height: 1.6;
            color: var(--text-color);
            background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        .header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #8A2BE2 100%);
            color: var(--header-text-color);
            padding: 1.5rem 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            position: sticky; top: 0; z-index: 1000;
        }
        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .nav-links { display: flex; gap: 1rem; }
        .nav-links a {
            color: var(--header-text-color);
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: background 0.3s ease;
            font-weight: 500;
        }
        .nav-links a:hover, .nav-links a.active { background: rgba(255, 255, 255, 0.15); }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        @keyframes fadeInSlideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .card {
            background: var(--card-bg-color);
            border-radius: 15px;
            padding: 2.5rem;
            box-shadow: 0 10px 30px var(--shadow-color);
            border: 1px solid rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            animation: fadeInSlideUp 0.6s ease-out forwards;
            margin-bottom: 2rem;
        }
        .card h3 {
            color: var(--text-color);
            margin-bottom: 2rem;
            font-size: 1.6rem;
            font-weight: 700;
            padding-bottom: 0.75rem;
            border-bottom: 3px solid var(--primary-color);
            display: inline-block;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem 2rem;
        }
        .form-group { margin-bottom: 0.5rem; }
        .form-group.full-width { grid-column: 1 / -1; }
        .form-group label {
            display: block;
            margin-bottom: 0.6rem;
            font-weight: 500;
            font-size: 1rem;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 0.8rem 1rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            font-family: var(--font-family);
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .form-group input:focus, .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px var(--secondary-color);
        }
        .form-group textarea { resize: vertical; min-height: 120px; }
        @keyframes alert-fade-in {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .alert {
            grid-column: 1 / -1;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            font-weight: 500;
            border-left: 5px solid;
            animation: alert-fade-in 0.4s ease forwards;
        }
        .alert-success { background: rgba(32, 201, 151, 0.1); border-color: var(--success-color); color: #0b5f43; }
        .alert-error { background: rgba(228, 88, 88, 0.1); border-color: var(--error-color); color: #8b2828; }
        .form-actions { 
            grid-column: 1 / -1;
            display: flex; 
            gap: 1rem; 
            margin-top: 2rem; 
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .form-actions .delete-form { margin-right: auto; }
        .btn {
            padding: 0.8rem 2rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.1rem;
            font-weight: 700;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary { background: var(--primary-color); color: white; }
        .btn-primary:hover {
            background: #5848e8;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(106, 90, 249, 0.4);
        }
        .btn-secondary { background: #f1f1f1; color: #555; border: 2px solid #ddd; }
        .btn-secondary:hover { background: #e7e7e7; border-color: #ccc; }
        .btn-danger { background: var(--error-color); color: white; }
        .btn-danger:hover { background: #c82333; }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1><?php echo htmlspecialchars($branch['name']); ?></h1>
            <nav class="nav-links">
                <a href="index.php">الرئيسية</a>
                <a href="search.php">البحث</a>
                <a href="add_customer.php">إضافة عميل</a>
                <a href="ccp_automation.php">إنشاء وثيقة</a>
                <a href="transactions.php">العمليات</a>
                <a href="delinquent_payments.php" class="btn">عرض تقرير المتأخرات</a>
                <a href="inventory.php">لوحة تحكم المخزون</a>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <div class="card">
            <h3>تعديل بيانات العميل: <?php echo htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']); ?></h3>
            
            <form method="POST">
                <div class="form-grid">
                    <?php if ($message): ?>
                        <div class="alert alert-success"><?php echo $message; ?></div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-error"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="first_name">الاسم الأول *</label>
                        <input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($customer['first_name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="last_name">اللقب *</label>
                        <input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($customer['last_name']); ?>" required>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="national_id">رقم التعريف الوطني *</label>
                        <input type="text" id="national_id" name="national_id" value="<?php echo htmlspecialchars($customer['national_id']); ?>" placeholder="أدخل 18 رقماً" maxlength="18" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="ccp_account">رقم الحساب البريدي الجاري *</label>
                        <input type="text" id="ccp_account" name="ccp_account" value="<?php echo htmlspecialchars($customer['ccp_account']); ?>" placeholder="10 أرقام بدون المفتاح" maxlength="10" required>
                    </div>

                    <div class="form-group">
                        <label for="ccp_key">المفتاح (Cle) *</label>
                        <input type="text" id="ccp_key" name="ccp_key" value="<?php echo htmlspecialchars($customer['ccp_key']); ?>" placeholder="رقمان" maxlength="2" required>
                    </div>

                    <div class="form-group full-width">
                        <label for="phone">رقم الهاتف *</label>
                        <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($customer['phone']); ?>" required>
                    </div>

                    <div class="form-group full-width">
                        <label for="address">العنوان</label>
                        <textarea id="address" name="address" placeholder="العنوان الكامل للعميل"><?php echo htmlspecialchars($customer['address']); ?></textarea>
                    </div>
                
                    <div class="form-actions">
                        <form class="delete-form" method="POST" action="delete_customer.php" onsubmit="return confirm('هل أنت متأكد من حذف هذا العميل وكل عملياته بشكل دائم؟ هذا الإجراء لا يمكن التراجع عنه.');">
                            <input type="hidden" name="customer_id" value="<?php echo $customer_id; ?>">
                            <button type="submit" class="btn btn-danger">حذف العميل</button>
                        </form>
                        <div>
                            <a href="search.php" class="btn btn-secondary">العودة للبحث</a>
                            <button type="submit" class="btn btn-primary">حفظ التغييرات</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>