<?php
require_once 'config.php';
requireLogin();

$branch = getBranchInfo($pdo, $_SESSION['branch_id']);
if ($branch['username'] !== 'ElOued') {
    header('Location: transactions.php');
    exit();
}

$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);
$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);

$revision_messages = $_SESSION['revision_messages'] ?? [];
unset($_SESSION['revision_messages']);
$forward_payment_messages = $_SESSION['forward_payment_messages'] ?? [];
unset($_SESSION['forward_payment_messages']);
$excess_payment_messages = $_SESSION['excess_payment_messages'] ?? [];
unset($_SESSION['excess_payment_messages']);

$filter_year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
$filter_month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');
$filter_status = $_GET['status'] ?? 'all';
$search_query = trim($_GET['search'] ?? '');
$filter_branch = $_GET['branch'] ?? '';

$report_date = date('F Y', mktime(0, 0, 0, $filter_month, 1, $filter_year));

$processed_records = [];
$unmatched_records = [];
$missing_records = [];
$stats = ['paid' => 0, 'failed' => 0, 'unmatched' => 0, 'missing' => 0];
$branches = [];

try {
    $stmt_branches = $pdo->prepare("SELECT id, name FROM branches ORDER BY name");
    $stmt_branches->execute();
    $branches = $stmt_branches->fetchAll(PDO::FETCH_ASSOC);

    $search_conditions = [];
    $search_params = [$filter_year, $filter_month];
    
    if (!empty($search_query)) {
        $search_conditions[] = "(t.nom LIKE ? OR t.prenom LIKE ? OR c.first_name LIKE ? OR c.last_name LIKE ? OR t.ccp_account LIKE ? OR ph.reference_id_from_file LIKE ?)";
        $search_term = "%{$search_query}%";
        array_push($search_params, ...array_fill(0, 6, $search_term));
    }
    
    if (!empty($filter_branch)) {
        $search_conditions[] = "b.id = ?";
        $search_params[] = $filter_branch;
    }

    $where_clause = !empty($search_conditions) ? " AND " . implode(" AND ", $search_conditions) : "";

    if (in_array($filter_status, ['all', 'paid', 'failed'])) {
        $status_filter = '';
        if ($filter_status === 'paid') $status_filter = " AND ph.status_code_from_file = '0'";
        elseif ($filter_status === 'failed') $status_filter = " AND ph.status_code_from_file != '0' AND ph.status_code_from_file != '-1'";

        $stmt_processed = $pdo->prepare("SELECT ph.*, st.monthly_deduction_amount, t.nom, t.prenom, t.ccp_account, c.first_name, c.last_name, b.name as branch_name FROM payment_history ph JOIN sub_transactions st ON ph.sub_transaction_id = st.id JOIN transactions t ON st.transaction_id = t.id LEFT JOIN customers c ON t.customer_id = c.id JOIN branches b ON t.branch_id = b.id WHERE ph.batch_year = ? AND ph.batch_month = ? AND ph.status = 'processed' {$status_filter} {$where_clause} ORDER BY ph.status_code_from_file, t.nom");
        $stmt_processed->execute($search_params);
        $processed_records = $stmt_processed->fetchAll(PDO::FETCH_ASSOC);
    }

    if (in_array($filter_status, ['all', 'unmatched'])) {
        $unmatched_params = [$filter_year, $filter_month];
        $unmatched_where = !empty($search_query) ? "AND (reference_id_from_file LIKE ?)" : "";
        if (!empty($search_query)) $unmatched_params[] = "%{$search_query}%";
        
        $stmt_unmatched = $pdo->prepare("SELECT * FROM payment_history WHERE batch_year = ? AND batch_month = ? AND status = 'unmatched' {$unmatched_where}");
        $stmt_unmatched->execute($unmatched_params);
        $unmatched_records = $stmt_unmatched->fetchAll(PDO::FETCH_ASSOC);
    }

    if (in_array($filter_status, ['all', 'missing'])) {
        $stmt_missing = $pdo->prepare("SELECT ph.reference_id_from_file, st.monthly_deduction_amount, t.nom, t.prenom, t.ccp_account, c.first_name, c.last_name, b.name as branch_name FROM payment_history ph JOIN sub_transactions st ON ph.sub_transaction_id = st.id JOIN transactions t ON st.transaction_id = t.id LEFT JOIN customers c ON t.customer_id = c.id JOIN branches b ON t.branch_id = b.id WHERE ph.batch_year = ? AND ph.batch_month = ? AND ph.status = 'missing' {$where_clause} ORDER BY t.nom");
        $stmt_missing->execute($search_params);
        $missing_records = $stmt_missing->fetchAll(PDO::FETCH_ASSOC);
    }
    
    $stmt_all_stats = $pdo->prepare("SELECT SUM(CASE WHEN status = 'processed' AND status_code_from_file = '0' THEN 1 ELSE 0 END) as paid, SUM(CASE WHEN status = 'processed' AND status_code_from_file != '0' AND status_code_from_file != '-1' THEN 1 ELSE 0 END) as failed, SUM(CASE WHEN status = 'missing' THEN 1 ELSE 0 END) as missing, SUM(CASE WHEN status = 'unmatched' THEN 1 ELSE 0 END) as unmatched FROM payment_history WHERE batch_year = ? AND batch_month = ?");
    $stmt_all_stats->execute([$filter_year, $filter_month]);
    $all_stats = $stmt_all_stats->fetch(PDO::FETCH_ASSOC);
    if ($all_stats) $stats = array_map('intval', $all_stats);

} catch (Exception $e) {
    $error = 'خطأ في جلب بيانات التقرير: ' . $e->getMessage();
}

function get_status_from_code($code) {
    $safe_code = htmlspecialchars($code);
    if ($code === '0') return '<span class="status-badge status-paid">ناجحة (مدفوعة)</span>';
    if ($code === '-1') return '<span class="status-badge status-missing">مفقودة من الملف</span>';
    $message = ['1' => 'فاشلة (الرصيد غير كافٍ)', '2' => 'فاشلة (الحساب مجمد أو محظور)', '5' => 'فاشلة (خطأ في رقم الحساب)'][$code] ?? 'فاشلة (رمز: ' . $safe_code . ')';
    return '<span class="status-badge status-failed">' . $message . '</span>';
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقرير معالجة التسديد - <?php echo $report_date; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #161332; 
            --secondary-color: #6a5af9; 
            --background-color: #f0f2f5;
            --card-bg-color: #ffffff; 
            --text-color: #333; 
            --header-text-color: #ffffff;
            --shadow-color: rgba(22, 19, 50, 0.1); 
            --font-family: 'Cairo', sans-serif;
            --status-paid-bg: #d1e7dd; 
            --status-paid-text: #0f5132;
            --status-failed-bg: #f8d7da; 
            --status-failed-text: #58151c;
            --status-missing-bg: #fff3cd; 
            --status-missing-text: #664d03;
            --status-unmatched-bg: #cfe2ff; 
            --status-unmatched-text: #052c65;
            --border-color: #e9ecef;
            --revision-bg: #e7f3ff;
            --revision-border: #0d6efd;
            --revision-text: #0c63e4;
        }
        body { 
            font-family: var(--font-family); 
            background-color: var(--background-color); 
            color: var(--text-color); 
            margin: 0; 
        }
        .header { 
            background: var(--primary-color); 
            color: var(--header-text-color); 
            padding: 1rem 2rem;
        }
        .header-content { 
            max-width: 1400px; 
            margin: 0 auto; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        .header-content h1 {
            font-size: 1.5rem;
            margin: 0;
        }
        .nav-links a { 
            color: var(--header-text-color); 
            text-decoration: none; 
            padding: 0.5rem 1rem; 
            transition: background-color 0.2s ease; 
            font-weight: 500;
            border-radius: 6px;
        }
        .nav-links a:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        .container { 
            max-width: 1400px; 
            margin: 2rem auto; 
            padding: 0 2rem; 
        }
        .card { 
            background: var(--card-bg-color); 
            border-radius: 15px; 
            padding: 2.5rem; 
            box-shadow: 0 10px 30px var(--shadow-color); 
            border: 1px solid var(--border-color);
        }
        .page-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 2rem; 
            flex-wrap: wrap; 
            gap: 1rem;
        }
        .page-header h2 { 
            font-size: 1.8rem; 
            color: var(--primary-color); 
            margin: 0; 
        }
        .page-header .actions {
            display: flex;
            gap: 0.5rem;
        }
        .section-header { 
            font-size: 1.5rem; 
            margin-top: 2.5rem; 
            margin-bottom: 1.5rem; 
            padding-bottom: 0.5rem; 
            border-bottom: 2px solid var(--secondary-color); 
            color: var(--primary-color);
        }
        .alert { 
            padding: 1rem 1.5rem; 
            border-radius: 8px; 
            margin-bottom: 1.5rem; 
            border: 1px solid transparent;
            border-left-width: 5px;
        }
        .alert.success { 
            background-color: var(--status-paid-bg); 
            color: var(--status-paid-text); 
            border-color: #198754; 
        }
        .alert.error { 
            background-color: var(--status-failed-bg); 
            color: var(--status-failed-text); 
            border-color: #dc3545; 
        }
        .revision-section {
            background-color: var(--revision-bg);
            border: 1px solid var(--revision-border);
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1rem;
        }
        .revision-section h3 {
            color: var(--revision-text);
            margin-top: 0;
            margin-bottom: 1rem;
            font-size: 1.3rem;
        }
        .revision-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .revision-list li {
            padding: 0.5rem 0;
            border-bottom: 1px solid rgba(13, 110, 253, 0.2);
        }
        .revision-list li:last-child {
            border-bottom: none;
        }
        .revision-section.forward {
            background-color: var(--status-paid-bg);
            border-color: var(--status-paid-text);
        }
        .revision-section.forward h3 {
            color: var(--status-paid-text);
        }
        .revision-section.forward .revision-list li {
            color: var(--status-paid-text);
            border-color: rgba(15, 81, 50, 0.2);
        }
        .table-responsive { overflow-x: auto; }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 1rem; 
            background-color: var(--card-bg-color);
        }
        th, td { 
            padding: 1rem; 
            text-align: right; 
            border-bottom: 1px solid var(--border-color); 
            vertical-align: middle;
        }
        th { 
            background-color: #f8f9fa; 
            font-weight: bold; 
            color: var(--primary-color);
        }
        tr:last-child td {
            border-bottom: none;
        }
        tbody tr:hover {
            background-color: #f8f9fa;
        }
        .status-badge { 
            padding: 0.3rem 0.8rem; 
            border-radius: 20px; 
            font-size: 0.85rem; 
            font-weight: 700;
            white-space: nowrap;
        }
        .status-paid { background-color: var(--status-paid-bg); color: var(--status-paid-text); }
        .status-failed { background-color: var(--status-failed-bg); color: var(--status-failed-text); }
        .status-missing { background-color: var(--status-missing-bg); color: var(--status-missing-text); }
        .status-unmatched { background-color: var(--status-unmatched-bg); color: var(--status-unmatched-text); }
        .stats-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
            gap: 1.5rem; 
            margin-bottom: 2rem; 
        }
        .stat-box { 
            background: #fdfdff; 
            padding: 1.5rem; 
            border-radius: 8px; 
            text-align: center; 
            border: 1px solid var(--border-color);
            border-left-width: 5px;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .stat-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px var(--shadow-color);
        }
        .stat-box h3 { 
            font-size: 2.2rem;
            margin: 0 0 0.25rem 0; 
            color: var(--primary-color);
        }
        .stat-box p { 
            margin: 0; 
            font-size: 1rem; 
            font-weight: 500; 
            color: #6c757d;
        }
        .stat-box.paid { border-left-color: #198754; }
        .stat-box.failed { border-left-color: #dc3545; }
        .stat-box.unmatched { border-left-color: #0d6efd; }
        .stat-box.missing { border-left-color: #ffc107; }
        .btn { 
            border: none; 
            padding: 0.6rem 1.2rem; 
            border-radius: 6px; 
            cursor: pointer; 
            text-decoration: none; 
            display: inline-block; 
            color: white; 
            background-color: var(--primary-color); 
            margin: 0;
            font-family: var(--font-family);
            transition: background-color 0.2s ease;
        }
        .btn:hover {
            background-color: #2c2a4a;
        }
        .btn.secondary { 
            background-color: var(--secondary-color); 
        }
        .btn.secondary:hover {
            background-color: #5548d9;
        }
        .filters-section { 
            background: #f8f9fa; 
            padding: 1.5rem; 
            border-radius: 8px; 
            margin-bottom: 2rem;
            border: 1px solid var(--border-color);
        }
        .filters-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
            gap: 1.5rem; 
            align-items: end; 
        }
        .form-group { 
            display: flex; 
            flex-direction: column; 
        }
        .form-group label { 
            font-weight: 500; 
            margin-bottom: 0.5rem; 
        }
        .form-group input, .form-group select { 
            padding: 0.6rem;
            border: 1px solid #ddd; 
            border-radius: 4px; 
            font-family: var(--font-family); 
        }
        .filter-actions { 
            display: flex; 
            gap: 0.5rem; 
            align-items: end;
        }
        
        @media print {
            .no-print { display: none !important; }
            body { 
                margin: 0; 
                background-color: #fff !important; 
                color: #000 !important;
            }
            .container { margin: 0; padding: 0; }
            .card { 
                box-shadow: none !important; 
                border: none !important; 
                padding: 0.5rem; 
            }
            th, .status-badge {
                -webkit-print-color-adjust: exact;
                color-adjust: exact;
            }
            @page { 
                size: A4;
                margin: 1cm; 
            }
        }
    </style>
</head>
<body>
    <header class="header no-print">
        <div class="header-content">
            <h1>تقرير معالجة التسديد</h1>
            <nav class="nav-links"><a href="transactions.php">العودة إلى العمليات</a></nav>
        </div>
    </header>

    <div class="container">
        <div class="card">
            <div class="page-header">
                <h2>نتائج المعالجة لشهر: <?php echo htmlspecialchars($report_date); ?></h2>
                <div class="actions no-print">
                    <a href="transactions.php?year=<?php echo $filter_year; ?>&month=<?php echo $filter_month; ?>" class="btn">عرض صفحة العمليات</a>
                    <button onclick="window.print()" class="btn secondary">طباعة</button>
                </div>
            </div>

            <?php if ($message): ?><div class="alert success no-print"><?php echo nl2br(htmlspecialchars($message)); ?></div><?php endif; ?>
            <?php if ($error): ?><div class="alert error no-print"><?php echo nl2br(htmlspecialchars($error)); ?></div><?php endif; ?>

            <?php if (!empty($excess_payment_messages)): ?>
            <div class="revision-section extra-alert no-print">
                <h3>تنبيهات مبالغ فائضة (للمراجعة الفورية)</h3>
                <ul class="revision-list">
                    <?php foreach ($excess_payment_messages as $msg): ?>
                        <li><?php echo htmlspecialchars($msg); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <?php if (!empty($revision_messages)): ?>
            <div class="revision-section no-print">
                <h3>تسديدات مراجعة - الأشهر السابقة المُسدَّدة تلقائياً</h3>
                <ul class="revision-list">
                    <?php foreach ($revision_messages as $msg): ?>
                        <li><?php echo htmlspecialchars($msg); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <?php if (!empty($forward_payment_messages)): ?>
            <div class="revision-section forward no-print">
                <h3>تسديدات مقدمة - الأقساط المستقبلية المسددة تلقائياً</h3>
                <ul class="revision-list">
                    <?php foreach ($forward_payment_messages as $msg): ?>
                        <li><?php echo htmlspecialchars($msg); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            
            <div class="filters-section no-print">
                <form method="GET" action="">
                    <input type="hidden" name="year" value="<?php echo $filter_year; ?>">
                    <input type="hidden" name="month" value="<?php echo $filter_month; ?>">
                    <div class="filters-grid">
                        <div class="form-group">
                            <label for="status">نوع العملية:</label>
                            <select name="status" id="status">
                                <option value="all" <?php echo $filter_status === 'all' ? 'selected' : ''; ?>>جميع العمليات</option>
                                <option value="paid" <?php echo $filter_status === 'paid' ? 'selected' : ''; ?>>العمليات الناجحة فقط</option>
                                <option value="failed" <?php echo $filter_status === 'failed' ? 'selected' : ''; ?>>العمليات الفاشلة فقط</option>
                                <option value="missing" <?php echo $filter_status === 'missing' ? 'selected' : ''; ?>>العمليات المفقودة فقط</option>
                                <option value="unmatched" <?php echo $filter_status === 'unmatched' ? 'selected' : ''; ?>>العمليات غير المطابقة فقط</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="branch">الفرع:</label>
                            <select name="branch" id="branch">
                                <option value="">جميع الفروع</option>
                                <?php foreach ($branches as $branch_item): ?>
                                    <option value="<?php echo $branch_item['id']; ?>" <?php echo $filter_branch == $branch_item['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($branch_item['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="search">البحث (الاسم، المرجع، CCP):</label>
                            <input type="text" name="search" id="search" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="ابحث...">
                        </div>
                        <div class="filter-actions">
                            <button type="submit" class="btn">تطبيق الفلاتر</button>
                            <a href="?year=<?php echo $filter_year; ?>&month=<?php echo $filter_month; ?>" class="btn secondary">إعادة تعيين</a>
                        </div>
                    </div>
                </form>
            </div>

            <div class="stats-grid">
                <div class="stat-box paid"><h3><?php echo $stats['paid'] ?? 0; ?></h3><p>عمليات ناجحة</p></div>
                <div class="stat-box failed"><h3><?php echo $stats['failed'] ?? 0; ?></h3><p>عمليات فاشلة</p></div>
                <div class="stat-box missing"><h3><?php echo $stats['missing'] ?? 0; ?></h3><p>عمليات مفقودة</p></div>
                <div class="stat-box unmatched"><h3><?php echo $stats['unmatched'] ?? 0; ?></h3><p>عمليات غير مطابقة</p></div>
            </div>

            <?php if (in_array($filter_status, ['all', 'paid', 'failed'])): ?>
            <h3 class="section-header">العمليات المعالجة (الناجحة والفاشلة)</h3>
            <div class="table-responsive">
                <table>
                    <thead><tr><th>العميل / الحساب</th><th>الفرع</th><th>المبلغ</th><th>المرجع في الملف</th><th>الحالة</th></tr></thead>
                    <tbody>
                        <?php if (empty($processed_records)): ?>
                            <tr><td colspan="5" style="text-align:center;">لا توجد عمليات معالجة تطابق هذا الفلتر.</td></tr>
                        <?php else: foreach ($processed_records as $rec): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars(trim(($rec['first_name'] ?? '') . ' ' . ($rec['last_name'] ?? '')) ?: trim(($rec['prenom'] ?? '') . ' ' . ($rec['nom'] ?? ''))); ?></strong><br><small><?php echo htmlspecialchars($rec['ccp_account']); ?></small></td>
                                <td><?php echo htmlspecialchars($rec['branch_name']); ?></td>
                                <td><?php echo number_format($rec['monthly_deduction_amount'], 2); ?> د.ج</td>
                                <td><?php echo htmlspecialchars($rec['reference_id_from_file']); ?></td>
                                <td><?php echo get_status_from_code($rec['status_code_from_file']); ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

            <?php if (in_array($filter_status, ['all', 'missing'])): ?>
            <h3 class="section-header">العمليات المفقودة</h3>
            <div class="table-responsive">
                <table>
                     <thead><tr><th>العميل / الحساب</th><th>الفرع</th><th>المبلغ المتوقع</th><th>المرجع المتوقع</th></tr></thead>
                    <tbody>
                        <?php if (empty($missing_records)): ?>
                            <tr><td colspan="4" style="text-align:center;">لا توجد عمليات مفقودة تطابق هذا الفلتر.</td></tr>
                        <?php else: foreach ($missing_records as $rec): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars(trim(($rec['first_name'] ?? '') . ' ' . ($rec['last_name'] ?? '')) ?: trim(($rec['prenom'] ?? '') . ' ' . ($rec['nom'] ?? ''))); ?></strong><br><small><?php echo htmlspecialchars($rec['ccp_account']); ?></small></td>
                                <td><?php echo htmlspecialchars($rec['branch_name']); ?></td>
                                <td><?php echo number_format($rec['monthly_deduction_amount'], 2); ?> د.ج</td>
                                <td><?php echo htmlspecialchars($rec['reference_id_from_file']); ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
            
            <?php if (in_array($filter_status, ['all', 'unmatched'])): ?>
            <h3 class="section-header">العمليات غير المطابقة</h3>
            <div class="table-responsive">
                <table>
                     <thead><tr><th>المرجع في الملف</th><th>رمز الحالة</th><th class="no-print">السطر الكامل من الملف</th></tr></thead>
                    <tbody>
                        <?php if (empty($unmatched_records)): ?>
                            <tr><td colspan="3" style="text-align:center;">لا توجد عمليات غير مطابقة تطابق هذا الفلتر.</td></tr>
                        <?php else: foreach ($unmatched_records as $rec): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($rec['reference_id_from_file']); ?></td>
                                <td><?php echo htmlspecialchars($rec['status_code_from_file']); ?></td>
                                <td class="no-print" style="font-family: monospace; text-align:left; direction:ltr;"><?php echo htmlspecialchars($rec['line_from_file'] ?? ''); ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>