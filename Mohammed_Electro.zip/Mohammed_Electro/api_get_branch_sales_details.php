<?php
require_once 'config.php';
requireLogin();

header('Content-Type: application/json');

$branch_name = $_GET['branch'] ?? null;
$start_date = $_GET['start'] ?? null;
$end_date = $_GET['end'] ?? null;

if (!$branch_name || !$start_date || !$end_date) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required parameters.']);
    exit;
}

$sql = "
    SELECT 
        p.name as product_name,
        tp.quantity,
        tp.sale_price,
        c.first_name,
        c.last_name
    FROM transaction_products tp
    JOIN transactions t ON tp.transaction_id = t.id
    JOIN products p ON tp.product_id = p.id
    JOIN customers c ON t.customer_id = c.id
    JOIN branches b ON t.branch_id = b.id
    WHERE 
        b.name = ? 
        AND DATE(t.creation_date) BETWEEN ? AND ?
    ORDER BY t.creation_date DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$branch_name, $start_date, $end_date]);
$details = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($details);
?>