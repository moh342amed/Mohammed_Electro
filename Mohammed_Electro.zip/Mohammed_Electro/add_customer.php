<?php
require_once 'config.php';
requireLogin();

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize all inputs
    $first_name = sanitizeInput($_POST['first_name']);
    $last_name = sanitizeInput($_POST['last_name']);
    $national_id = sanitizeInput($_POST['national_id']);
    $ccp_account = sanitizeInput($_POST['ccp_account']);
    $ccp_key = sanitizeInput($_POST['ccp_key']);
    $phone = sanitizeInput($_POST['phone']);
    $address = sanitizeInput($_POST['address']);

    // Check if customer already exists by a unique identifier
    $stmt = $pdo->prepare("SELECT id FROM customers WHERE ccp_account = ? OR phone = ? OR national_id = ?");
    $stmt->execute([$ccp_account, $phone, $national_id]);

    if ($stmt->fetch()) {
        $error = 'عميل بنفس رقم الحساب البريدي، الهاتف، أو رقم التعريف الوطني موجود مسبقاً';
    } else {
        // Insert new customer with all fields
        $sql = "INSERT INTO customers (first_name, last_name, national_id, ccp_account, ccp_key, phone, address) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);

        if ($stmt->execute([$first_name, $last_name, $national_id, $ccp_account, $ccp_key, $phone, $address])) {
            $message = 'تم إضافة العميل بنجاح';
            // Clear form fields after successful submission
            $_POST = [];
        } else {
            $error = 'حدث خطأ أثناء إضافة العميل. يرجى مراجعة البيانات المدخلة.';
        }
    }
}

$branch = getBranchInfo($pdo, $_SESSION['branch_id']);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة عميل جديد - <?php echo htmlspecialchars($branch['name']); ?></title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-color: #161332ff;
            --secondary-color: #d1d1f7;
            --background-color: #f0f2f5;
            --card-bg-color: rgba(255, 255, 255, 0.6);
            --text-color: #333;
            --header-text-color: #ffffff;
            --shadow-color: rgba(106, 90, 249, 0.2);
            --border-color: #dee2e6;
            --success-color: #20c997;
            --error-color: #e45858;
            --font-family: 'Cairo', sans-serif;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: var(--font-family);
            background-color: var(--background-color);
            color: var(--text-color);
            line-height: 1.6;
            background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        
        @keyframes fadeInSlideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #8A2BE2 100%);
            color: var(--header-text-color);
            padding: 1.5rem 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .header h1 {
            font-size: 1.8rem;
            font-weight: 700;
        }

        .logout-btn {
            background: rgba(255, 255, 255, 0.15);
            color: var(--header-text-color);
            padding: 0.6rem 1.2rem;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        
        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 2rem;
            width: 100%;
            flex-grow: 1;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 2rem;
        }
        
        .card {
            background: var(--card-bg-color);
            border-radius: 15px;
            padding: 2.5rem;
            box-shadow: 0 10px 30px var(--shadow-color);
            border: 1px solid rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            animation: fadeInSlideUp 0.6s ease-out forwards;
        }

        .actions-card h3 {
            color: var(--text-color);
            margin-bottom: 1.5rem;
            font-size: 1.3rem;
            font-weight: 700;
            border-bottom: 3px solid var(--primary-color);
            padding-bottom: 0.75rem;
        }
        
        .quick-actions {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .quick-actions a {
            text-align: center;
            padding: 1rem;
            background: transparent;
            color: var(--primary-color);
            text-decoration: none;
            border-radius: 8px;
            border: 2px solid var(--primary-color);
            transition: all 0.3s ease;
            font-size: 1.1rem;
            font-weight: 500;
        }
        
        .quick-actions a:hover, .quick-actions a.active {
            background: var(--primary-color);
            color: white;
            transform: translateY(-3px);
        }
        
        .form-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .form-header h2 {
            color: var(--primary-color);
            font-weight: 700;
            font-size: 1.5rem;
            border-bottom: 3px solid var(--primary-color);
            padding-bottom: 0.75rem;
            margin-bottom: 0.5rem;
        }

        .form-header p {
            color: #555;
            font-size: 0.95rem;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .full-width {
            grid-column: 1 / -1;
        }

        .form-group label {
            font-weight: 500;
            font-size: 0.9rem;
            color: #444;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 0.8rem 1rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            font-family: var(--font-family);
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }

        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px var(--secondary-color);
        }

        @keyframes alert-fade-in {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .alert {
            grid-column: 1 / -1;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-size: 1rem;
            font-weight: 500;
            border: none;
            border-left: 5px solid;
            animation: alert-fade-in 0.4s ease forwards;
        }
        
        .alert-success {
            background: rgba(32, 201, 151, 0.1);
            border-color: var(--success-color);
            color: #0b5f43;
        }
        
        .alert-error {
            background: rgba(228, 88, 88, 0.1);
            border-color: var(--error-color);
            color: #8b2828;
        }

        .form-actions {
            grid-column: 1 / -1;
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
            justify-content: flex-end;
        }
        
        .btn {
            padding: 0.8rem 2rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.1rem;
            font-weight: 700;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: #5848e8;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(106, 90, 249, 0.4);
        }

        .btn-secondary {
            background: #f1f1f1;
            color: #555;
            border: 2px solid #ddd;
        }

        .btn-secondary:hover {
            background: #e7e7e7;
            border-color: #ccc;
        }
        
        @media (max-width: 992px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .header-content { flex-direction: column; text-align: center; gap: 1rem; }
            .form-grid { grid-template-columns: 1fr; }
            .container { padding: 0 1rem; }
            .card { padding: 2rem 1.5rem; }
            .form-actions { flex-direction: column-reverse; gap: 0.75rem; }
            .btn { width: 100%; }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1>نظام إدارة الفروع</h1>
            <a href="logout.php" class="logout-btn">تسجيل الخروج</a>
        </div>
    </header>

    <div class="container">
        <div class="dashboard-grid">
            <aside class="actions-card" style="animation-delay: 0.1s;">
                <h3>إجراءات سريعة</h3>
                <nav class="quick-actions">
                    <a href="index.php">الرئيسية</a>
                    <a href="add_customer.php" class="active">إضافة عميل جديد</a>
                    <a href="ccp_automation.php">إنشاء وثيقة جديدة</a>
                    <a href="transactions.php">عرض العمليات</a>
                    <?php if ($branch['username'] === 'ElOued'): ?>
                        <a href="delinquent_payments.php" class="btn">عرض تقرير المتأخرات</a>
                        <a href="inventory.php">لوحة تحكم المخزون</a>
                    <?php endif; ?>
                </nav>
            </aside>

            <main class="card" style="animation-delay: 0.2s;">
                <div class="form-header">
                    <h2>إنشاء ملف عميل جديد</h2>
                    <p>يرجى تعبئة جميع الحقول المطلوبة لإنشاء سجل عميل جديد.</p>
                </div>
                <form method="POST" id="addCustomerForm">
                    <div class="form-grid">
                        <?php if ($message): ?>
                            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
                        <?php endif; ?>
                        
                        <?php if ($error): ?>
                            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="first_name">الاسم الأول *</label>
                            <input type="text" id="first_name" name="first_name" placeholder="مثال: أمين" required>
                        </div>
                        <div class="form-group">
                            <label for="last_name">اللقب *</label>
                            <input type="text" id="last_name" name="last_name" placeholder="مثال: منصوري" required>
                        </div>
                        
                        <div class="form-group full-width">
                            <label for="national_id">رقم التعريف الوطني *</label>
                            <input type="text" id="national_id" name="national_id" placeholder="أدخل 18 رقماً" maxlength="18" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="ccp_account">رقم الحساب البريدي الجاري *</label>
                            <input type="text" id="ccp_account" name="ccp_account" placeholder="10 أرقام بدون المفتاح" maxlength="10" required>
                        </div>

                        <div class="form-group">
                            <label for="ccp_key">المفتاح (Cle) *</label>
                            <input type="text" id="ccp_key" name="ccp_key" placeholder="رقمان" maxlength="2" required>
                        </div>

                        <div class="form-group full-width">
                            <label for="phone">رقم الهاتف *</label>
                            <input type="tel" id="phone" name="phone" placeholder="صيغة دولية أو محلية" required>
                        </div>

                        <div class="form-group full-width">
                            <label for="address">العنوان</label>
                            <textarea id="address" name="address" placeholder="العنوان الكامل للعميل (اختياري)"></textarea>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">إضافة العميل</button>
                            <a href="index.php" class="btn btn-secondary">إلغاء</a>
                        </div>
                    </div>
                </form>
            </main>
        </div>
    </div>
    
    <script>
        // Simple client-side validation feedback
        document.getElementById('addCustomerForm').addEventListener('submit', function(event) {
            const inputs = this.querySelectorAll('input[required]');
            let allValid = true;
            inputs.forEach(input => {
                if (!input.value.trim()) {
                    allValid = false;
                    input.style.borderColor = 'var(--error-color)';
                } else {
                    input.style.borderColor = '#ddd'; // Reset border color
                }
            });

            if (!allValid) {
                // The native browser validation will show messages for required fields.
                // This is just a visual indicator.
                console.log('Please fill all required fields.');
            }
        });
    </script>
</body>
</html>