<?php
require_once 'config.php';
requireLogin();

// The duplicate function was here. It has been removed.

$search_term = isset($_GET['search_term']) ? sanitizeInput($_GET['search_term']) : '';
$customers = [];

if ($search_term) {
    // 1. Fetch customers matching the search term
    $stmt = $pdo->prepare("
        SELECT * FROM customers 
        WHERE ccp_account LIKE ? 
        OR phone LIKE ? 
        OR first_name LIKE ? 
        OR last_name LIKE ?
        OR CONCAT(first_name, ' ', last_name) LIKE ?
    ");
    $search_pattern = "%$search_term%";
    $stmt->execute([$search_pattern, $search_pattern, $search_pattern, $search_pattern, $search_pattern]);
    $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($customers)) {
        // Get all customer IDs for efficient querying
        $customer_ids = array_column($customers, 'id');
        $in_placeholders = implode(',', array_fill(0, count($customer_ids), '?'));
        
        // 2. Check for Delinquency for ALL found customers in ONE query
        $first_day_of_current_month = date('Y-m-01');
        $delinquency_sql = "
            SELECT t.customer_id FROM transactions t
            JOIN sub_transactions st ON t.id = st.transaction_id
            WHERE t.customer_id IN ($in_placeholders)
            AND t.status = 'confirmed' AND st.payment_status = 'unpaid' AND st.deduction_date < ?
            GROUP BY t.customer_id
            HAVING COUNT(DISTINCT DATE_FORMAT(st.deduction_date, '%Y-%m')) >= 3
        ";
        $stmt_delinquent = $pdo->prepare($delinquency_sql);
        $stmt_delinquent->execute(array_merge($customer_ids, [$first_day_of_current_month]));
        $delinquent_customer_ids = $stmt_delinquent->fetchAll(PDO::FETCH_COLUMN, 0);

        // 3. Get Active Transaction Counts for ALL found customers in ONE query
        $active_trans_sql = "
            SELECT customer_id, COUNT(id) as open_transactions_count
            FROM transactions
            WHERE customer_id IN ($in_placeholders)
            AND status = 'confirmed'
            AND (end_date IS NULL OR end_date >= CURDATE())
            GROUP BY customer_id
        ";
        $stmt_active = $pdo->prepare($active_trans_sql);
        $stmt_active->execute($customer_ids);
        $active_counts = $stmt_active->fetchAll(PDO::FETCH_KEY_PAIR);

        // 4. Map the results back to the customers array
        foreach ($customers as &$customer) {
            $customer['is_delinquent'] = in_array($customer['id'], $delinquent_customer_ids);
            $customer['open_transactions_count'] = $active_counts[$customer['id']] ?? 0;
        }
        unset($customer);
    }
}

$branch = getBranchInfo($pdo, $_SESSION['branch_id']);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <!-- The rest of your HTML file remains exactly the same as before -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>البحث عن العملاء - <?php echo htmlspecialchars($branch['name']); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #161332;
            --secondary-color: #6a5af9;
            --background-color: #f0f2f5;
            --card-bg-color: rgba(255, 255, 255, 0.65);
            --text-color: #333;
            --header-text-color: #ffffff;
            --shadow-color: rgba(22, 19, 50, 0.15);
            --error-color: #dc3545;
            --warning-bg-color: #fff3cd;
            --warning-text-color: #664d03;
            --warning-border-color: #ffeeba;
            --info-bg-color: #cfe2ff;
            --info-text-color: #052c65;
            --info-border-color: #b6d4fe;
            --font-family: 'Cairo', sans-serif;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: var(--font-family);
            background-color: var(--background-color);
            line-height: 1.6;
            color: var(--text-color);
            background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        .header {
            background: var(--primary-color);
            color: var(--header-text-color);
            padding: 1.5rem 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .header-content { max-width: 1400px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; }
        .nav-links { display: flex; gap: 1rem; }
        .nav-links a {
            color: var(--header-text-color); text-decoration: none; padding: 0.5rem 1rem; border-radius: 8px;
            transition: background 0.3s ease; font-weight: 500;
        }
        .nav-links a:hover, .nav-links a.active { background: rgba(255, 255, 255, 0.1); }
        .container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; }
        .search-container { display: flex; justify-content: center; align-items: center; padding: 2rem 0; }
        .input__container {
            position: relative; background: rgba(255, 255, 255, 0.8); padding: 12px 20px;
            display: flex; align-items: center; gap: 8px; border-radius: 25px;
            width: 100%; max-width: 500px; transition: transform 400ms; box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .shadow__input {
            content: ""; position: absolute; width: 100%; height: 100%; left: 0; bottom: 0; z-index: -1;
            filter: blur(35px); border-radius: 25px; background-color: var(--secondary-color);
        }
        .input__button__shadow {
            cursor: pointer; border: none; background: none; transition: transform 400ms, background 400ms;
            display: flex; align-items: center; border-radius: 12px; padding: 5px;
        }
        .input__button__shadow svg { fill: var(--primary-color); }
        .input__button__shadow:hover { background: rgba(106, 90, 249, 0.1); }
        .input__search {
            width: 100%; outline: none; border: none; background: transparent; padding: 8px;
            font-family: var(--font-family); font-size: 1.1rem; color: #333;
        }
        @keyframes fadeInSlideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        .card {
            background: var(--card-bg-color); border-radius: 15px; padding: 2rem;
            box-shadow: 0 10px 30px var(--shadow-color); border: 1px solid rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
            animation: fadeInSlideUp 0.6s ease-out forwards; margin-bottom: 2rem;
        }
        .results-header { margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 1px solid #ddd; }
        .results-header h3 { font-size: 1.6rem; font-weight: 700; }
        .results-header p { color: #555; }
        .customer-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 1.5rem; }
        .customer-card {
            background: #fff; padding: 1.5rem; border-radius: 12px; border: 1px solid #e0e0e0;
            transition: transform 0.3s, box-shadow 0.3s; display: flex; flex-direction: column;
        }
        .customer-card:hover { transform: translateY(-5px); box-shadow: 0 8px 25px rgba(0,0,0,0.08); }
        .customer-card h4 { font-size: 1.25rem; color: var(--primary-color); margin-bottom: 1rem; }
        .customer-info { flex-grow: 1; }
        .customer-card p { margin-bottom: 0.5rem; color: #444; font-size: 0.95rem; }
        .customer-card strong { color: #111; font-weight: 500; }
        .card-actions { margin-top: 1.5rem; display: flex; gap: 0.5rem; }
        .btn {
            font-size: 0.9rem; padding: 0.6rem 1.3rem;
            color: white; text-decoration: none; border-radius: 8px; display: inline-block;
            transition: all 0.3s ease; border: none; cursor: pointer;
        }
        .btn-edit { background: var(--primary-color); }
        .btn-edit:hover { background: #3c357e; transform: translateY(-2px); }
        .btn-delete { background: var(--error-color); }
        .btn-delete:hover { background: #c82333; transform: translateY(-2px); }
        .no-results { text-align: center; padding: 3rem; }
        .no-results h4 { font-size: 1.5rem; margin-bottom: 0.5rem; }
        .no-results p { color: #666; font-size: 1.1rem; }
        .alert-box {
            margin-top: 1rem;
            padding: 0.75rem 1rem;
            border: 1px solid transparent;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.9rem;
            text-align: center;
        }
        .alert-delinquency {
            background-color: var(--warning-bg-color);
            color: var(--warning-text-color);
            border-color: var(--warning-border-color);
        }
        .alert-info {
            background-color: var(--info-bg-color);
            color: var(--info-text-color);
            border-color: var(--info-border-color);
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1>نظام إدارة العملاء</h1>
            <nav class="nav-links">
                <a href="index.php">الرئيسية</a>
                <a href="add_customer.php">إضافة عميل</a>
                <a href="ccp_automation.php">إنشاء وثيقة</a>
                <a href="transactions.php">عرض العمليات</a>
                <a href="delinquent_payments.php">تقرير المتأخرات</a>
                <a href="inventory.php">لوحة تحكم المخزون</a>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <form method="GET" class="search-container">
            <div class="input__container">
                <div class="shadow__input"></div>
                <input type="text" name="search_term" class="input__search" value="<?php echo htmlspecialchars($search_term); ?>" placeholder="ابحث عن عميل..." required>
                <button class="input__button__shadow" type="submit">
                    <svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" height="20px" width="20px"><path d="M4 9a5 5 0 1110 0A5 5 0 014 9zm5-7a7 7 0 104.2 12.6.999.999 0 00.093.107l3 3a1 1 0 001.414-1.414l-3-3a.999.999 0 00-.107-.093A7 7 0 009 2z" fill-rule="evenodd" fill="#17202A"></path></svg>
                </button>
            </div>
        </form>
        
        <?php if ($search_term): ?>
            <?php if (empty($customers)): ?>
                <div class="card"><div class="no-results"><h4>لا توجد نتائج</h4><p>لم يتم العثور على أي عميل يطابق البحث: "<?php echo htmlspecialchars($search_term); ?>"</p></div></div>
            <?php else: ?>
                <div class="card" style="animation-delay: 100ms;">
                    <div class="results-header"><h3>نتائج البحث</h3><p>تم العثور على <strong><?php echo count($customers); ?></strong> عميل</p></div>
                    <div class="customer-grid">
                        <?php foreach ($customers as $index => $customer): ?>
                            <div class="customer-card" style="animation-delay: <?php echo $index * 100; ?>ms;">
                                <div class="customer-info">
                                    <h4><?php echo htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']); ?></h4>
                                    <p><strong>رقم الحساب:</strong> <?php echo htmlspecialchars($customer['ccp_account']); ?></p>
                                    <p><strong>الهاتف:</strong> <?php echo htmlspecialchars($customer['phone']); ?></p>
                                    <p><strong>العنوان:</strong> <?php echo htmlspecialchars($customer['address'] ?: 'غير محدد'); ?></p>
                                </div>
                                
                                <div>
                                    <?php if ($customer['open_transactions_count'] > 0): ?>
                                        <div class="alert-box alert-info">
                                            لدى هذا العميل <strong><?php echo $customer['open_transactions_count']; ?></strong> معاملات جارية حالياً.
                                        </div>
                                    <?php endif; ?>

                                    <?php if ($customer['is_delinquent']): ?>
                                        <div class="alert-box alert-delinquency">
                                            <strong>تنبيه:</strong> هذا العميل لديه مشاكل في السداد.
                                        </div>
                                    <?php endif; ?>

                                    <div class="card-actions">
                                        <a href="modify_customer.php?id=<?php echo $customer['id']; ?>" class="btn btn-edit">تعديل</a>
                                        <form method="POST" action="delete_customer.php" onsubmit="return confirm('هل أنت متأكد من حذف هذا العميل وكل عملياته بشكل دائم؟ هذا الإجراء لا يمكن التراجع عنه.');" style="display: inline;">
                                            <input type="hidden" name="customer_id" value="<?php echo $customer['id']; ?>">
                                            <button type="submit" class="btn btn-delete">حذف</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>