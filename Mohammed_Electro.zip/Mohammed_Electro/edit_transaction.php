<?php
require_once 'config.php';
requireLogin();

$branch = getBranchInfo($pdo, $_SESSION['branch_id']);

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = 'معرف عملية غير صالح.';
    header("Location: transactions.php");
    exit();
}
$transaction_id = (int)$_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo->beginTransaction();
    try {
        $montant = filter_var($_POST['montant'], FILTER_SANITIZE_NUMBER_INT) . '.' . str_pad(filter_var($_POST['montant_decimal'], FILTER_SANITIZE_NUMBER_INT) ?: '0', 2, '0', STR_PAD_LEFT);
        
        $sql_transaction = "UPDATE transactions SET
            creation_date = ?, start_date = ?, end_date = ?, amount = ?, installment_months = ?,
            deductions_per_month = ? WHERE id = ?";
        $stmt_transaction = $pdo->prepare($sql_transaction);
        $stmt_transaction->execute([
            $_POST['creation_date'], $_POST['start_date'] ?: null, $_POST['end_date'] ?: null,
            $montant, $_POST['installment_months'] ?: null, $_POST['deductions_per_month'] ?: null,
            $transaction_id
        ]);
        
        $pdo->prepare("DELETE FROM transaction_products WHERE transaction_id = ?")->execute([$transaction_id]);
        
        if (isset($_POST['products'])) {
            $sql_products = "INSERT INTO transaction_products (transaction_id, product_id, quantity, sale_price) VALUES (?, ?, ?, ?)";
            $stmt_products = $pdo->prepare($sql_products);
            foreach ($_POST['products'] as $product) {
                if (!empty($product['id']) && !empty($product['quantity']) && !empty($product['price'])) {
                    $stmt_products->execute([ $transaction_id, $product['id'], $product['quantity'], $product['price'] ]);
                }
            }
        }
        
        $pdo->commit();
        $_SESSION['message'] = 'تم تحديث العملية بنجاح.';
        header("Location: transactions.php?open_tx=" . $transaction_id);
        exit();

    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = 'فشل تحديث العملية: ' . $e->getMessage();
        header("Location: edit_transaction.php?id=" . $transaction_id);
        exit();
    }
}

$sql = "SELECT t.*, c.phone, c.address FROM transactions t LEFT JOIN customers c ON t.customer_id = c.id WHERE t.id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$transaction_id]);
$transaction = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$transaction) {
    $_SESSION['error'] = 'لا يمكن العثور على العملية.';
    header("Location: transactions.php");
    exit();
}

$stmt_products = $pdo->prepare("SELECT product_id, quantity, sale_price FROM transaction_products WHERE transaction_id = ?");
$stmt_products->execute([$transaction_id]);
$transaction_products = $stmt_products->fetchAll(PDO::FETCH_ASSOC);

$available_products = $pdo->query("SELECT id, name FROM products ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل العملية #<?php echo $transaction_id; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/pdf-lib/dist/pdf-lib.min.js"></script>
    <style>
        :root {
            --primary-color: #161332ff; --secondary-color: #d1d1f7; --background-color: #f0f2f5;
            --card-bg-color: rgba(255, 255, 255, 0.6); --text-color: #333; --header-text-color: #ffffff;
            --shadow-color: rgba(106, 90, 249, 0.2); --font-family: 'Cairo', sans-serif; --error-color: #dc3545;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: var(--font-family); background-color: var(--background-color); color: var(--text-color); line-height: 1.6; background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); display: flex; flex-direction: column; min-height: 100vh; }
        .header { background: linear-gradient(135deg, var(--primary-color) 0%, #8A2BE2 100%); color: var(--header-text-color); padding: 1.5rem 2rem; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); position: sticky; top: 0; z-index: 1000; }
        .header-content { max-width: 1400px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 1.8rem; }
        .logout-btn { background: rgba(255, 255, 255, 0.15); color: var(--header-text-color); padding: 0.6rem 1.2rem; border: 1px solid rgba(255, 255, 255, 0.3); border-radius: 8px; text-decoration: none; transition: all 0.3s ease; }
        .container { max-width: 1400px; margin: 2rem auto; padding: 0 2rem; width: 100%; flex-grow: 1; }
        .dashboard-grid { display: grid; grid-template-columns: 300px 1fr; gap: 2rem; }
        .card { background: var(--card-bg-color); border-radius: 15px; padding: 2.5rem; box-shadow: 0 10px 30px var(--shadow-color); border: 1px solid rgba(255, 255, 255, 0.8); backdrop-filter: blur(10px); }
        .actions-card h3 { color: var(--text-color); margin-bottom: 1.5rem; border-bottom: 3px solid var(--primary-color); padding-bottom: 0.75rem; }
        .quick-actions { display: flex; flex-direction: column; gap: 1rem; }
        .quick-actions a { text-align: center; padding: 1rem; background: transparent; color: var(--primary-color); text-decoration: none; border-radius: 8px; border: 2px solid var(--primary-color); transition: all 0.3s ease; }
        .quick-actions a:hover, .quick-actions a.active { background: var(--primary-color); color: white; }
        .form-header { text-align: center; margin-bottom: 2rem; }
        .form-header h2 { color: var(--primary-color); font-size: 1.5rem; border-bottom: 3px solid var(--primary-color); padding-bottom: 0.75rem; }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
        .form-group { display: flex; flex-direction: column; gap: 0.5rem; }
        .full-width { grid-column: 1 / -1; }
        .form-group label { font-weight: 500; }
        .form-group input, .form-group select { width: 100%; padding: 0.8rem 1rem; border: 2px solid #ddd; border-radius: 8px; font-size: 1rem; font-family: var(--font-family); transition: border-color 0.3s ease, box-shadow 0.3s ease; }
        .form-group input:focus, .form-group select:focus { outline: none; border-color: var(--primary-color); box-shadow: 0 0 0 3px var(--secondary-color); }
        .form-group input.uppercase { text-transform: uppercase; }
        input[readonly] { background-color: #e9ecef; cursor: not-allowed; }
        fieldset { border: 2px solid var(--primary-color); border-radius: 8px; padding: 1.5rem; margin-top: 1rem; grid-column: 1 / -1; background: rgba(240, 242, 245, 0.5); }
        legend { font-weight: 700; color: var(--primary-color); padding: 0 0.75rem; margin-right: 1rem; }
        .btn-group { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 2rem; }
        .btn { padding: 0.9rem 1.5rem; border: none; border-radius: 8px; cursor: pointer; text-decoration: none; font-size: 1.1rem; font-weight: 700; transition: all 0.3s ease; text-align: center; }
        .btn-primary { background: var(--primary-color); color: white; }
        .calc-display { font-size: 1.2rem; font-weight: bold; text-align: center; padding: 0.5rem; border-radius: 6px; }
        .calc-green { color: #198754; background-color: #d1e7dd; }
        .calc-blue { color: #0d6efd; background-color: #cfe2ff; }
        .calc-red { color: #dc3545; background-color: #f8d7da; }
        .product-row { display: grid; grid-template-columns: 3fr 1fr 1fr auto; gap: 1rem; align-items: flex-end; margin-bottom: 1rem; }
        .btn-remove-product { background-color: var(--error-color); color: white; border: none; padding: 0; width: 45px; height: 45px; font-size: 1.5rem; line-height: 1; border-radius: 8px; cursor: pointer; }
        @media (max-width: 992px) { .dashboard-grid { grid-template-columns: 1fr; } }
        @media (max-width: 768px) { .form-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1>تعديل العملية #<?php echo $transaction_id; ?></h1>
            <a href="transactions.php" class="logout-btn">العودة للعمليات</a>
        </div>
    </header>

    <div class="container">
        <div class="dashboard-grid">
            <aside class="actions-card card">
                <h3>إجراءات سريعة</h3>
                <nav class="quick-actions">
                     <a href="index.php">الرئيسية</a>
                     <a href="add_customer.php">إضافة عميل</a>
                     <a href="ccp_automation.php">إنشاء وثيقة</a>
                     <a href="transactions.php" class="active">العمليات</a>
                     <?php if ($branch['username'] === 'ElOued'): ?>
                        <a href="delinquent_payments.php">تقرير المتأخرات</a>
                        <a href="inventory.php">لوحة تحكم المخزون</a>
                    <?php endif; ?>
                </nav>
            </aside>

            <main class="card">
                <div class="form-header">
                    <h2>نموذج تعديل وثيقة</h2>
                    <p>يمكنك تحديث جميع تفاصيل العملية والعميل أدناه.</p>
                </div>
                
                <form id="editForm" method="POST" action="edit_transaction.php?id=<?php echo $transaction_id; ?>">
                    <div class="form-grid">
                        <input type="hidden" id="customer_id" name="customer_id" value="<?php echo htmlspecialchars($transaction['customer_id']); ?>">
                        
                        <div class="form-group"><label for="prenom">الإسم الشخصي (PRENOM)</label><input type="text" id="prenom" name="prenom" value="<?php echo htmlspecialchars($transaction['prenom']); ?>" readonly></div>
                        <div class="form-group"><label for="nom">اللقب (NOM)</label><input type="text" id="nom" name="nom" value="<?php echo htmlspecialchars($transaction['nom']); ?>" readonly></div>
                        <div class="form-group full-width"><label for="identifiant">رقم التعريف الوطني</label><input type="text" id="identifiant" name="identifiant" value="<?php echo htmlspecialchars($transaction['national_id']); ?>" readonly></div>
                        <div class="form-group"><label for="ccp">رقم حساب CCP للخصم</label><input type="text" id="ccp" name="ccp" value="<?php echo htmlspecialchars($transaction['ccp_account']); ?>" readonly></div>
                        <div class="form-group"><label for="cle">المفتاح (CLE)</label><input type="text" id="cle" name="cle" value="<?php echo htmlspecialchars($transaction['ccp_key']); ?>" readonly></div>
                        <div class="form-group"><label for="phone">رقم الهاتف</label><input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($transaction['phone']); ?>" readonly></div>
                        <div class="form-group"><label for="address">العنوان</label><input type="text" id="address" name="address" value="<?php echo htmlspecialchars($transaction['address']); ?>" readonly></div>

                        <fieldset>
                            <legend>المنتجات</legend>
                            <div id="products-container"></div>
                            <button type="button" id="add-product-btn" class="btn" style="background: #6c757d; font-size: 0.9rem; padding: 0.5rem 1rem; margin-top: 1rem;">+ إضافة منتج</button>
                            <div class="form-group" style="margin-top: 1.5rem; border-top: 2px solid var(--secondary-color); padding-top: 1.5rem;">
                                <label>إجمالي سعر البيع نقداً</label>
                                <input type="text" id="total_cash_price" readonly style="font-weight: bold; font-size: 1.2rem; text-align: center; color: var(--primary-color);">
                            </div>
                        </fieldset>

                        <fieldset><legend>تفاصيل التقسيط والسحب</legend>
                            <div class="form-grid" style="grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-top: 1rem;">
                                <div class="form-group">
                                    <label for="installment_months">عدد أشهر التقسيط</label>
                                    <select id="installment_months" name="installment_months">
                                        <option value="">-- اختر مدة --</option>
                                        <option value="4">4 أشهر</option><option value="6">6 أشهر</option><option value="8">8 أشهر</option>
                                        <option value="10">10 أشهر</option><option value="12">12 شهر</option><option value="15">15 شهر</option>
                                        <option value="20">20 شهر</option><option value="24">24 شهر</option>
                                    </select>
                                </div>
                                <div class="form-group"><label for="deductions_per_month">عدد الخصومات في الشهر</label><select id="deductions_per_month" name="deductions_per_month"><option value="">-- اختر --</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></div>
                                <div class="form-group"><label for="creation_date">تاريخ إنشاء العملية</label><input type="date" id="creation_date" name="creation_date" required></div>
                                <div class="form-group"><label for="start_date">تاريخ بداية السحب</label><input type="date" id="start_date" name="start_date"></div>
                                <div class="form-group full-width"><label for="end_date">تاريخ نهاية السحب</label><input type="date" id="end_date" name="end_date"></div>
                            </div>
                        </fieldset>
                        
                        <fieldset>
                            <legend>مبلغ التقسيط</legend>
                            <div class="form-grid" style="grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-top: 1rem;">
                                <div class="form-group"><label for="monthly_amount_input">القسط الشهري المقترح</label><input type="number" id="monthly_amount_input"></div>
                                <div class="form-group"><label for="montant">المبلغ الإجمالي للتقسيط</label><input type="number" id="montant" name="montant"><input type="hidden" id="montant_decimal" name="montant_decimal"></div>
                                <div class="form-group" style="display: none;"><label for="profit_percentage">نسبة الفائدة (%)</label><input type="number" id="profit_percentage" step="0.1" readonly></div>
                                <div class="form-group"><label>مبلغ الخصم الواحد المحسوب</label><div id="perDeductionAmountDisplay" class="calc-display">0.00 د.ج</div></div>
                            </div>
                        </fieldset>
                    </div>
                    
                    <div class="form-group full-width btn-group">
                        <button type="submit" class="btn btn-primary">حفظ التغييرات</button>
                        <button type="button" id="printDocBtn" class="btn" style="background-color: #0dcaf0; color: white;">طباعة وثيقة الخصم</button>
                        <button type="button" id="printT1Btn" class="btn" style="background-color: #28a745; color: white;">طباعة التزام وتسديد</button>
                    </div>
                </form>
            </main>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const transactionData = <?php echo json_encode($transaction); ?>;
    const transactionProductsData = <?php echo json_encode($transaction_products); ?>;
    const availableProductsData = <?php echo json_encode($available_products); ?>;

    const form = document.getElementById('editForm');
    const totalEl = document.getElementById('montant');
    const totalDecimalEl = document.getElementById('montant_decimal');
    const monthlyAmountEl = document.getElementById('monthly_amount_input');
    const monthsEl = document.getElementById('installment_months');
    const deductionsEl = document.getElementById('deductions_per_month');
    const perDeductionDisplay = document.getElementById('perDeductionAmountDisplay');
    const totalCashPriceEl = document.getElementById('total_cash_price');
    const profitPercentageEl = document.getElementById('profit_percentage');
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');
    const addProductBtn = document.getElementById('add-product-btn');
    const productsContainer = document.getElementById('products-container');
    
    const profitMap = { 4: 27, 6: 45, 8: 60, 10: 64, 12: 78, 15: 90, 20: 106, 24: 121 };
    let totalCashPrice = 0;
    let lastEditedField = 'total'; 
    let productRowCounter = 0;
    let lastDateInput = null;

    function populateForm() {
        for (const key in transactionData) {
            const el = form.querySelector(`[name="${key}"]`);
            if (el) { el.value = transactionData[key] || ''; }
        }
        
        transactionProductsData.forEach(p => {
            addProductRow(p.product_id, p.quantity, p.sale_price);
        });

        calculateCashPrice(false); 
        updateCalculations('total');
    }
    
    function updateCalculations(source) {
        if (source) lastEditedField = source;

        const months = parseInt(monthsEl.value) || 0;
        const deductions = parseInt(deductionsEl.value) || 0;
        let monthlyAmount = parseFloat(monthlyAmountEl.value) || 0;
        let totalAmount = parseFloat(totalEl.value) || 0;
        
        if (lastEditedField === 'months') {
            const profitPercentage = profitMap[months] || 0;
            totalAmount = totalCashPrice > 0 ? totalCashPrice * (1 + (profitPercentage / 100)) : 0;
        } else if (lastEditedField === 'monthly') {
            totalAmount = (monthlyAmount > 0 && months > 0) ? monthlyAmount * months : 0;
        }

        if (totalAmount > 0 && months > 0 && deductions > 0) {
            let perDeductionAmount = totalAmount / months / deductions;
            const isAlreadyGreen = Math.round((perDeductionAmount * 100) % 100) === 0 && Math.floor(perDeductionAmount) % 10 === 0;
            if (!isAlreadyGreen) {
                const targetPerDeduction = Math.ceil(perDeductionAmount / 10) * 10;
                totalAmount = targetPerDeduction * months * deductions;
            }
        }

        monthlyAmount = (totalAmount > 0 && months > 0) ? totalAmount / months : 0;
        const profitPercentage = (totalCashPrice > 0 && totalAmount >= totalCashPrice) ? ((totalAmount / totalCashPrice) - 1) * 100 : 0;
        
        totalEl.value = totalAmount > 0 ? totalAmount.toFixed(0) : '';
        monthlyAmountEl.value = monthlyAmount > 0 ? monthlyAmount.toFixed(2) : '';
        profitPercentageEl.value = profitPercentage >= 0 ? profitPercentage.toFixed(1) : '0.0';
        
        const [integerPart, decimalPart] = totalAmount.toFixed(2).split('.');
        totalDecimalEl.value = decimalPart || '00';
        
        const finalPerDeductionAmount = (totalAmount > 0 && months > 0 && deductions > 0) ? (totalAmount / months / deductions) : 0;
        perDeductionDisplay.textContent = finalPerDeductionAmount.toFixed(2) + ' د.ج';
        
        perDeductionDisplay.className = 'calc-display';
        if (finalPerDeductionAmount > 0) {
            const cents = Math.round((finalPerDeductionAmount * 100) % 100);
            const ones = Math.floor(finalPerDeductionAmount) % 10;
            if (cents > 0) perDeductionDisplay.classList.add('calc-red');
            else if (ones !== 0) perDeductionDisplay.classList.add('calc-blue');
            else perDeductionDisplay.classList.add('calc-green');
        }
    }

    function calculateCashPrice(recalculate = true) {
        let currentTotal = 0;
        productsContainer.querySelectorAll('.product-row').forEach(row => {
            const quantity = parseFloat(row.querySelector('input[name*="[quantity]"]').value) || 0;
            const price = parseFloat(row.querySelector('input[name*="[price]"]').value) || 0;
            currentTotal += quantity * price;
        });
        totalCashPrice = currentTotal;
        totalCashPriceEl.value = totalCashPrice.toFixed(2) + ' د.ج';
        if (recalculate) {
            updateCalculations('months');
        }
    }

    function updateDates() {
        const months = parseInt(monthsEl.value) || 0;
        const startDate = startDateInput.value ? new Date(startDateInput.value) : null;
        if (!startDate || isNaN(startDate.getTime())) { endDateInput.value = ''; return; }
        if ((lastDateInput === 'duration' || lastDateInput === 'start') && months > 0) {
            const newEndDate = new Date(startDate.getTime());
            newEndDate.setMonth(newEndDate.getMonth() + months - 1);
            endDateInput.value = newEndDate.toISOString().split('T')[0];
        } else if (lastDateInput === 'end' && months > 0) {
            const endDate = endDateInput.value ? new Date(endDateInput.value) : null;
            if (endDate && !isNaN(endDate.getTime())) {
                const newStartDate = new Date(endDate.getTime());
                newStartDate.setMonth(newStartDate.getMonth() - (months - 1));
                startDateInput.value = newStartDate.toISOString().split('T')[0];
            }
        }
    }
    
    function createProductRow() {
        productRowCounter++;
        const row = document.createElement('div');
        row.className = 'product-row';
        
        const productSelect = document.createElement('select');
        productSelect.name = `products[${productRowCounter}][id]`;
        productSelect.required = true;
        let optionsHtml = '<option value="">-- اختر منتج --</option>';
        availableProductsData.forEach(p => {
            optionsHtml += `<option value="${p.id}">${p.name}</option>`;
        });
        productSelect.innerHTML = optionsHtml;
        
        const quantityInput = document.createElement('input');
        quantityInput.type = 'number';
        quantityInput.name = `products[${productRowCounter}][quantity]`;
        quantityInput.min = 1;
        quantityInput.required = true;

        const priceInput = document.createElement('input');
        priceInput.type = 'number';
        priceInput.name = `products[${productRowCounter}][price]`;
        priceInput.step = '0.01';
        priceInput.required = true;

        const removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'btn btn-remove-product';
        removeBtn.textContent = '×';
        removeBtn.onclick = () => { row.remove(); calculateCashPrice(); };
        
        row.innerHTML = `
            <div class="form-group"><label>المنتج</label>${productSelect.outerHTML}</div>
            <div class="form-group"><label>الكمية</label>${quantityInput.outerHTML}</div>
            <div class="form-group"><label>سعر البيع</label>${priceInput.outerHTML}</div>
        `;
        row.appendChild(removeBtn);
        return row;
    }

    function addProductRow(productId, quantity, price) {
        const newRow = createProductRow();
        const select = newRow.querySelector('select');
        const qtyInput = newRow.querySelector('input[name*="[quantity]"]');
        const priceInput = newRow.querySelector('input[name*="[price]"]');
        
        if (productId) select.value = productId;
        if (quantity) qtyInput.value = quantity;
        if (price) priceInput.value = price;
        
        productsContainer.appendChild(newRow);
    }

    monthlyAmountEl.addEventListener('input', () => updateCalculations('monthly'));
    totalEl.addEventListener('input', () => updateCalculations('total'));
    deductionsEl.addEventListener('input', () => updateCalculations(lastEditedField));
    monthsEl.addEventListener('input', () => { lastDateInput = 'duration'; updateDates(); updateCalculations('months'); });
    startDateInput.addEventListener('input', () => { lastDateInput = 'start'; updateDates(); });
    endDateInput.addEventListener('input', () => { lastDateInput = 'end'; updateDates(); });
    addProductBtn.addEventListener('click', () => addProductRow());
    productsContainer.addEventListener('input', (e) => {
        if (e.target.matches('input[name*="[quantity]"], input[name*="[price]"]')) {
            calculateCashPrice();
        }
    });

    populateForm();

    document.getElementById('printDocBtn').addEventListener('click', async () => await fillDocPDF());
    document.getElementById('printT1Btn').addEventListener('click', async () => await fillT1PDF());

    async function fillDocPDF() {
        const { PDFDocument } = PDFLib;
        const nom = document.getElementById('nom').value.toUpperCase();
        const prenom = document.getElementById('prenom').value.toUpperCase();
        const identifiant = document.getElementById('identifiant').value.toUpperCase();
        const ccp = document.getElementById('ccp').value;
        const cle = document.getElementById('cle').value;
        const startDate = document.getElementById('start_date').value;
        const endDate = document.getElementById('end_date').value;
        
        let debut_jour = '  ', debut_mois = '  ', debut_annee = '    ';
        if (startDate) { const sd = new Date(startDate); debut_jour = String(sd.getUTCDate()).padStart(2, '0'); debut_mois = String(sd.getUTCMonth() + 1).padStart(2, '0'); debut_annee = String(sd.getUTCFullYear()); }
        let fin_jour = '  ', fin_mois = '  ', fin_annee = '    ';
        if (endDate) { const ed = new Date(endDate); fin_jour = String(ed.getUTCDate()).padStart(2, '0'); fin_mois = String(ed.getUTCMonth() + 1).padStart(2, '0'); fin_annee = String(ed.getUTCFullYear()); }
        
        const nom_prenom = `${nom} ${prenom}`;
        let montantForPdf = '       ', montantDecimalForPdf = '  ';
        const totalAmount = parseFloat(`${totalEl.value || '0'}.${totalDecimalEl.value || '00'}`);
        const months = parseInt(monthsEl.value, 10);
        const deductions = parseInt(deductionsEl.value, 10);
        if (totalAmount > 0 && months > 0 && deductions > 0) {
            const perDeductionAmount = totalAmount / months / deductions;
            const [integerPart, decimalPart] = perDeductionAmount.toFixed(2).split('.');
            montantForPdf = integerPart.padStart(7, '0');
            montantDecimalForPdf = (decimalPart || '00').padEnd(2, '0');
        }
        
        try {
            const url = 'template_form08.pdf';
            const existingPdfBytes = await fetch(url).then(res => res.arrayBuffer());
            const pdfDoc = await PDFDocument.load(existingPdfBytes);
            const form = pdfDoc.getForm();
            const fillField = (fieldName, value) => { try { form.getTextField(fieldName).setText(value); } catch (e) { console.warn(`Could not fill field: ${fieldName}`); }};
            const fillFieldsSequentially = (start, end, text) => { for (let i = 0; i <= (end - start); i++) { fillField(`Text Box ${start + i}`, text[i] || ' '); }};
            fillFieldsSequentially(1, 25, nom_prenom); fillFieldsSequentially(26, 43, identifiant); fillFieldsSequentially(44, 53, ccp);
            fillFieldsSequentially(54, 55, cle); fillFieldsSequentially(56, 57, debut_jour); fillFieldsSequentially(58, 59, debut_mois);
            fillFieldsSequentially(60, 63, debut_annee); fillFieldsSequentially(64, 65, fin_jour); fillFieldsSequentially(66, 67, fin_mois);
            fillFieldsSequentially(68, 71, fin_annee); fillFieldsSequentially(72, 78, montantForPdf); fillFieldsSequentially(79, 80, montantDecimalForPdf);
            fillFieldsSequentially(81, 94, nom); fillFieldsSequentially(95, 108, prenom); fillFieldsSequentially(109, 118, ccp);
            fillFieldsSequentially(119, 120, cle); fillFieldsSequentially(121, 122, debut_jour); fillFieldsSequentially(123, 124, debut_mois);
            fillFieldsSequentially(125, 128, debut_annee); fillFieldsSequentially(129, 130, fin_jour); fillFieldsSequentially(131, 132, fin_mois);
            fillFieldsSequentially(133, 136, fin_annee); fillFieldsSequentially(137, 143, montantForPdf); fillFieldsSequentially(144, 145, montantDecimalForPdf);
            const monthsValue = monthsEl.value;
            const paddedMonths = monthsValue.trim() === '' ? '  ' : monthsValue.padStart(2, '0');
            fillField('Text Box 2001', paddedMonths[0] || ' '); fillField('Text Box 2002', paddedMonths[1] || ' ');
            fillField('Text Box 2003', paddedMonths[0] || ' '); fillField('Text Box 2004', paddedMonths[1] || ' ');
            const pdfBytes = await pdfDoc.save();
            const blob = new Blob([pdfBytes], { type: 'application/pdf' });
            window.open(URL.createObjectURL(blob), '_blank');
        } catch (error) { console.error("PDF creation error:", error); alert(`فشل إنشاء ملف PDF.`); }
    }
    
    async function fillT1PDF() {
        const { PDFDocument } = PDFLib;
        const nom = document.getElementById('nom').value.toUpperCase();
        const prenom = document.getElementById('prenom').value.toUpperCase();
        const fullName = `${nom} ${prenom}`;
        const identifiant = document.getElementById('identifiant').value.toUpperCase();
        const ccp = document.getElementById('ccp').value;
        const cle = document.getElementById('cle').value;
        const fullCCP = `${ccp} / ${cle}`;
        try {
            const url = 't1.pdf'; 
            const existingPdfBytes = await fetch(url).then(res => res.arrayBuffer());
            const pdfDoc = await PDFDocument.load(existingPdfBytes);
            const form = pdfDoc.getForm();
            const fillField = (fieldName, value) => { try { form.getTextField(fieldName).setText(value); } catch (e) { console.error(`Could not fill field: ${fieldName}`); }};
            fillField('Text Box 1', fullName); fillField('Text Box 2', identifiant); fillField('Text Box 6', fullCCP);
            const pdfBytes = await pdfDoc.save();
            const blob = new Blob([pdfBytes], { type: 'application/pdf' });
            window.open(URL.createObjectURL(blob), '_blank');
        } catch (error) { console.error("T1 PDF creation error:", error); alert(`فشل إنشاء ملف T1 PDF.`); }
    }
});
</script>
</body>
</html>