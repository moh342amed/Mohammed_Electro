<?php
require_once 'config.php';
requireLogin();

header('Content-Type: application/json');

$term = isset($_GET['term']) ? trim($_GET['term']) : '';
$response = ['status' => 'error', 'customers' => []];

if (strlen($term) > 1) {
    try {
        // --- CORRECTED LINE ---
        // Added `phone` and `address` to the columns being selected
        $stmt = $pdo->prepare("
            SELECT id, first_name, last_name, national_id, ccp_account, ccp_key, phone, address 
            FROM customers 
            WHERE first_name LIKE ? 
            OR last_name LIKE ?
            OR CONCAT(first_name, ' ', last_name) LIKE ?
            OR ccp_account LIKE ?
            OR phone LIKE ?
            OR national_id LIKE ?
            ORDER BY first_name, last_name
            LIMIT 10
        ");
        
        $searchTerm = "%{$term}%";
        $stmt->execute([$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $response['status'] = 'success';
        $response['customers'] = $customers;

    } catch (Exception $e) {
        $response['message'] = 'Database query failed.';
    }
}

echo json_encode($response);