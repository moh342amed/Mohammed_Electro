<?php
require_once 'config.php';
requireLogin();

$page_title = 'تقرير المتأخرات';

$filter_branch = $_GET['branch'] ?? '';
$search_query = trim($_GET['search'] ?? '');

$delinquent_records = [];
$branches = [];

try {
    $stmt_branches = $pdo->prepare("SELECT id, name FROM branches ORDER BY name");
    $stmt_branches->execute();
    $branches = $stmt_branches->fetchAll(PDO::FETCH_ASSOC);

    $params = [];
    $where_conditions = [];

    $where_conditions[] = "t.status = 'confirmed'";
    $where_conditions[] = "st.payment_status = 'unpaid'";

    if (!empty($filter_branch)) {
        $where_conditions[] = "t.branch_id = ?";
        $params[] = $filter_branch;
    }

    if (!empty($search_query)) {
        $where_conditions[] = "(t.nom LIKE ? OR t.prenom LIKE ? OR t.ccp_account LIKE ? OR c.first_name LIKE ? OR c.last_name LIKE ?)";
        $search_term = "%{$search_query}%";
        array_push($params, $search_term, $search_term, $search_term, $search_term, $search_term);
    }

    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
    
    $first_day_of_current_month = date('Y-m-01');
    $params[] = $first_day_of_current_month;

    $sql = "
        SELECT
            t.id as transaction_id,
            t.nom,
            t.prenom,
            t.ccp_account,
            c.first_name,
            c.last_name,
            b.name as branch_name,
            SUM(st.monthly_deduction_amount) as total_unpaid_amount,
            COUNT(DISTINCT DATE_FORMAT(st.deduction_date, '%Y-%m')) as past_unpaid_months_count,
            COUNT(st.id) as unpaid_references_count
        FROM
            transactions t
        JOIN
            sub_transactions st ON t.id = st.transaction_id
        JOIN
            branches b ON t.branch_id = b.id
        LEFT JOIN
            customers c ON t.customer_id = c.id
        {$where_clause}
            AND st.deduction_date < ?
        GROUP BY
            t.id
        HAVING
            past_unpaid_months_count >= 3
        ORDER BY
            past_unpaid_months_count DESC, total_unpaid_amount DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $delinquent_records = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $error = 'خطأ في جلب بيانات المتأخرات: ' . $e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #161332;
            --secondary-color: #6a5af9;
            --background-color: #f0f2f5;
            --card-bg-color: rgba(255, 255, 255, 0.7);
            --text-color: #333;
            --header-text-color: #ffffff;
            --shadow-color: rgba(22, 19, 50, 0.15);
            --font-family: 'Cairo', sans-serif;
            --error-color: #dc3545;
            --info-color: #0dcaf0;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: var(--font-family); background-color: var(--background-color); line-height: 1.6; color: var(--text-color); background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); }
        .header { background: var(--primary-color); color: var(--header-text-color); padding: 1rem 1.5rem; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); }
        .header-content { max-width: 1400px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; }
        .header h1 { font-size: 1.5rem; }
        .nav-links { display: flex; gap: 0.5rem; }
        .nav-links a { color: var(--header-text-color); text-decoration: none; padding: 0.5rem 1rem; border-radius: 8px; transition: background 0.3s ease; font-weight: 500; }
        .nav-links a:hover, .nav-links a.active { background: rgba(255, 255, 255, 0.1); }
        .container { max-width: 1400px; margin: 2rem auto; padding: 0 1rem; }
        .card { background: var(--card-bg-color); border-radius: 15px; padding: 2rem; box-shadow: 0 10px 30px var(--shadow-color); border: 1px solid rgba(255, 255, 255, 0.8); backdrop-filter: blur(10px); }
        .page-header { margin-bottom: 2rem; border-bottom: 2px solid var(--primary-color); padding-bottom: 1rem; }
        .page-header h2 { font-size: 1.8rem; font-weight: 700; color: var(--primary-color); }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 1rem; text-align: right; border-bottom: 1px solid #ddd; }
        th { background-color: rgba(22, 19, 50, 0.05); font-weight: 700; color: #333; }
        tbody tr:hover { background-color: rgba(230, 230, 250, 0.7); }
        .btn { border: none; padding: 0.6rem 1.2rem; border-radius: 8px; cursor: pointer; transition: all 0.2s; text-decoration: none; display: inline-block; font-family: var(--font-family); font-size: 0.9rem; font-weight: 500; color: white; }
        .btn-primary { background-color: var(--primary-color); }
        .btn-info { background-color: var(--info-color); }
        .btn-info:hover { background-color: #0b9ab8; }
        .filter-section { background-color: rgba(22, 19, 50, 0.03); padding: 1.5rem; border-radius: 8px; margin-bottom: 2rem; }
        .filters-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.5rem; align-items: end; }
        .form-group { display: flex; flex-direction: column; }
        .form-group label { margin-bottom: 0.5rem; font-weight: 500; font-size: 0.9rem; }
        .form-group input, .form-group select { padding: 0.7rem; border: 1px solid #ccc; border-radius: 6px; font-size: 1rem; font-family: var(--font-family); }
        .delinquency-details { white-space: nowrap; }
        .alert.error { padding: 1rem; border-radius: 8px; margin-bottom: 1rem; background-color: #f8d7da; color: #58151c; border-left: 5px solid #dc3545; }
        @media (max-width: 768px) {
            .header-content { flex-direction: column; gap: 1rem; }
            .nav-links { flex-direction: column; align-items: center; width: 100%; }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1><?php echo $page_title; ?></h1>
            <nav class="nav-links">
                <a href="index.php">الرئيسية</a>
                <a href="add_customer.php">إضافة عميل</a>
                <a href="ccp_automation.php">إنشاء وثيقة</a>
                <a href="transactions.php">العمليات</a>
                <a href="delinquent_payments.php" class="active">تقرير المتأخرات</a>
                <a href="logout.php">تسجيل الخروج</a>
            </nav>
        </div>
    </header>

    <div class="container">
        <div class="card">
            <div class="page-header">
                <h2>العملاء المتأخرون عن السداد (3 أشهر سابقة أو أكثر)</h2>
            </div>

            <?php if (isset($error)): ?><div class="alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

            <div class="filter-section">
                <form method="GET" action="">
                    <div class="filters-grid">
                        <div class="form-group">
                            <label for="branch">تصفية حسب الفرع:</label>
                            <select name="branch" id="branch">
                                <option value="">جميع الفروع</option>
                                <?php foreach ($branches as $branch_item): ?>
                                    <option value="<?php echo $branch_item['id']; ?>" <?php echo $filter_branch == $branch_item['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($branch_item['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="search">بحث (الاسم، اللقب، CCP):</label>
                            <input type="text" name="search" id="search" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="أدخل للبحث...">
                        </div>
                        <div class="filter-actions">
                            <button type="submit" class="btn btn-primary">تطبيق</button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>العميل</th>
                            <th>حساب CCP</th>
                            <th>الفرع</th>
                            <th>الأشهر المتأخرة</th>
                            <th>الاقتطاعات غير المدفوعة</th>
                            <th>إجمالي المبلغ المتأخر</th>
                            <th>إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($delinquent_records)): ?>
                            <tr>
                                <td colspan="7" style="text-align:center; padding: 2rem;">لا يوجد عملاء متأخرون يطابقون معايير البحث.</td>
                            </tr>
                        <?php else: foreach ($delinquent_records as $rec): ?>
                            <tr>
                                <td><?php echo htmlspecialchars(trim(($rec['first_name'] ?? '') . ' ' . ($rec['last_name'] ?? '')) ?: trim(($rec['prenom'] ?? '') . ' ' . ($rec['nom'] ?? ''))); ?></td>
                                <td><?php echo htmlspecialchars($rec['ccp_account']); ?></td>
                                <td><?php echo htmlspecialchars($rec['branch_name']); ?></td>
                                <td class="delinquency-details"><strong><?php echo htmlspecialchars($rec['past_unpaid_months_count']); ?></strong> أشهر</td>
                                <td class="delinquency-details" style="color: #c82333;"><strong><?php echo htmlspecialchars($rec['unpaid_references_count']); ?></strong> اقتطاع</td>
                                <td style="font-weight: bold; color: var(--error-color);"><?php echo number_format($rec['total_unpaid_amount'], 2); ?> د.ج</td>
                                <td>
                                    <a href="transactions.php?search=<?php echo urlencode($rec['ccp_account']); ?>&open_tx=<?php echo $rec['transaction_id']; ?>" class="btn btn-info" title="عرض تفاصيل عمليات هذا العميل">عرض التفاصيل</a>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>