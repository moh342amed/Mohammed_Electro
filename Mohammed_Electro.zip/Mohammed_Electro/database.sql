-- Create database
CREATE DATABASE IF NOT EXISTS branch_system;
USE branch_system;

-- Branches table
CREATE TABLE branches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Customers table
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ccp_account VARCHAR(50) UNIQUE,
    phone VARCHAR(20),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ccp (ccp_account),
    INDEX idx_phone (phone),
    INDEX idx_name (first_name, last_name)
);

-- Transactions table
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    branch_id INT NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    paid_amount DECIMAL(10,2) DEFAULT 0,
    installment_amount DECIMAL(10,2) NOT NULL,
    payment_status ENUM('excellent', 'good', 'late', 'problem') DEFAULT 'good',
    transaction_date DATE NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (branch_id) REFERENCES branches(id),
    INDEX idx_customer (customer_id),
    INDEX idx_branch (branch_id),
    INDEX idx_date (transaction_date)
);

-- Insert sample branches
INSERT INTO branches (name, location, username, password) VALUES
('فرع الوادي', 'الوادي', 'elwad', MD5('elwad123')),
('فرع بشار', 'بشار', 'bechar', MD5('bechar123')),
('فرع باتنة', 'باتنة', 'batna', MD5('batna123')),
('فرع بسكرة', 'بسكرة', 'biskra', MD5('biskra123')),
('فرع الجزائر', 'الجزائر', 'alger', MD5('alger123')),
('فرع العلمة', 'العلمة', 'alma', MD5('alma123')),
('فرع قالمة', 'قالمة', 'guelma', MD5('guelma123'));

-- Insert sample customers
INSERT INTO customers (ccp_account, phone, first_name, last_name, address) VALUES
('1234567890', '0555123456', 'محمد', 'بن علي', 'الوادي، الجزائر'),
('0987654321', '0666789123', 'فاطمة', 'حمدي', 'بشار، الجزائر'),
('1122334455', '0777456789', 'أحمد', 'مرادي', 'باتنة، الجزائر');

-- Insert sample transactions
INSERT INTO transactions (customer_id, branch_id, product_name, total_amount, paid_amount, installment_amount, payment_status, transaction_date, notes) VALUES
(1, 1, 'ثلاجة سامسونج 400 لتر', 80000.00, 20000.00, 10000.00, 'excellent', '2024-01-15', 'عميل ممتاز، دفع في الوقت المحدد'),
(2, 2, 'غسالة LG 7 كيلو', 60000.00, 15000.00, 7500.00, 'good', '2024-02-20', 'عميل جيد'),
(3, 3, 'تكييف كونسيل 1.5 حصان', 45000.00, 10000.00, 5000.00, 'late', '2024-03-10', 'تأخير في السداد مرتين');