<?php
require_once 'config.php';
requireLogin();

$branch = getBranchInfo($pdo, $_SESSION['branch_id']);
$is_admin_branch = ($branch['username'] === 'ElOued');

$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);
$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);

if ($is_admin_branch && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return_to_pending_id'])) {
    $transaction_id = (int)$_POST['return_to_pending_id'];
    $pdo->beginTransaction();
    try {
        $pdo->prepare("DELETE FROM payment_history WHERE sub_transaction_id IN (SELECT id FROM sub_transactions WHERE transaction_id = ?)")->execute([$transaction_id]);
        $pdo->prepare("DELETE FROM sub_transactions WHERE transaction_id = ?")->execute([$transaction_id]);
        $pdo->prepare("UPDATE transactions SET status = 'pending', confirmed_at = NULL WHERE id = ? AND status = 'confirmed'")->execute([$transaction_id]);
        $pdo->commit();
        $_SESSION['message'] = 'تم إرجاع العملية إلى حالة "قيد الانتظار" بنجاح.';
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = 'خطأ في إرجاع العملية: ' . $e->getMessage();
    }
    header("Location: " . $_SERVER['HTTP_REFERER']);
    exit();
}

if ($is_admin_branch && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_transaction_id'])) {
    $transaction_id = (int)$_POST['confirm_transaction_id'];
    $pdo->beginTransaction();
    try {
        $stmt_fetch = $pdo->prepare("SELECT t.*, c.first_name, c.last_name FROM transactions t LEFT JOIN customers c ON t.customer_id = c.id WHERE t.id = ? AND t.status = 'pending' FOR UPDATE");
        $stmt_fetch->execute([$transaction_id]);
        $transaction = $stmt_fetch->fetch(PDO::FETCH_ASSOC);

        if (!$transaction) {
            throw new Exception('العملية قد تم تأكيدها مسبقاً أو لا يمكن العثور عليها.');
        }
        if (empty($transaction['amount']) || empty($transaction['installment_months']) || empty($transaction['deductions_per_month']) || empty($transaction['start_date'])) {
            throw new Exception('لا يمكن تأكيد العملية. يجب تحديد المبلغ, الأقساط, وتاريخ بداية السحب أولاً عبر شاشة التعديل.');
        }

        $pdo->prepare("UPDATE transactions SET status = 'confirmed', confirmed_at = NOW() WHERE id = ?")->execute([$transaction_id]);
        
        $start_date_obj = new DateTime($transaction['start_date']);
        $initials = strtoupper(substr($transaction['first_name'] ?: $transaction['prenom'], 0, 1) . substr($transaction['last_name'] ?: $transaction['nom'], 0, 1));
        $tx_id_part = str_pad($transaction['id'], 5, '0', STR_PAD_LEFT);
        $per_deduction_amount = round($transaction['amount'] / $transaction['installment_months'] / $transaction['deductions_per_month'], 2);

        $fixed_references = [];
        $first_month_part = $start_date_obj->format('m');
        for ($d = 1; $d <= $transaction['deductions_per_month']; $d++) {
            $deduction_part = str_pad($d, 2, '0', STR_PAD_LEFT);
            $random_part = random_int(10000, 99999);
            $sub_reference_id = $initials . $tx_id_part . $first_month_part . $deduction_part . $random_part;
            $fixed_references[] = $sub_reference_id;
        }
        
        $stmt_insert_sub = $pdo->prepare("INSERT INTO sub_transactions (transaction_id, sub_reference_id, monthly_deduction_amount, deduction_date) VALUES (?, ?, ?, ?)");
        
        for ($m = 0; $m < $transaction['installment_months']; $m++) {
            $current_deduction_date = clone $start_date_obj;
            $current_deduction_date->modify("+$m month");
            $deduction_date_sql = $current_deduction_date->format('Y-m-d');

            for ($d = 1; $d <= $transaction['deductions_per_month']; $d++) {
                $sub_reference_id = $fixed_references[$d - 1];
                $stmt_insert_sub->execute([$transaction_id, $sub_reference_id, $per_deduction_amount, $deduction_date_sql]);
            }
        }

        $pdo->commit();
        $_SESSION['message'] = 'تم تأكيد العملية وإنشاء جدول الاقتطاعات الكامل بنجاح.';
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = 'حدث خطأ أثناء التأكيد: ' . $e->getMessage();
    }
    header("Location: " . $_SERVER['HTTP_REFERER']);
    exit();
}

if ($is_admin_branch && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_payment_changes'])) {
    $ids_to_mark_paid = isset($_POST['mark_paid']) ? array_map('intval', $_POST['mark_paid']) : [];
    $ids_to_mark_unpaid = isset($_POST['mark_unpaid']) ? array_map('intval', $_POST['mark_unpaid']) : [];
    
    if (!empty($ids_to_mark_paid) || !empty($ids_to_mark_unpaid)) {
        $pdo->beginTransaction();
        try {
            if (!empty($ids_to_mark_paid)) {
                $in_query_paid = implode(',', array_fill(0, count($ids_to_mark_paid), '?'));
                $pdo->prepare("UPDATE sub_transactions SET payment_status = 'paid' WHERE id IN ($in_query_paid) AND payment_status = 'unpaid'")->execute($ids_to_mark_paid);
            }
            if (!empty($ids_to_mark_unpaid)) {
                $in_query_unpaid = implode(',', array_fill(0, count($ids_to_mark_unpaid), '?'));
                $pdo->prepare("UPDATE sub_transactions SET payment_status = 'unpaid' WHERE id IN ($in_query_unpaid) AND payment_status = 'paid'")->execute($ids_to_mark_unpaid);
            }
            $pdo->commit();
            $_SESSION['message'] = 'تم تحديث حالة الدفع بنجاح.';
        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['error'] = 'خطأ في تحديث حالة الدفع: ' . $e->getMessage();
        }
    }
    header("Location: " . $_SERVER['HTTP_REFERER']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_transaction_id'])) {
    $transaction_id = (int)$_POST['delete_transaction_id'];
    $return_stock = $_POST['return_stock'] ?? 'no';

    $stmt_check = $pdo->prepare("SELECT status, branch_id FROM transactions WHERE id = ?");
    $stmt_check->execute([$transaction_id]);
    $transaction_to_delete = $stmt_check->fetch(PDO::FETCH_ASSOC);

    if (!$transaction_to_delete) {
        $_SESSION['error'] = 'لم يتم العثور على العملية.';
    } elseif ($transaction_to_delete['status'] === 'confirmed' && !$is_admin_branch) {
        $_SESSION['error'] = 'لا يمكن حذف العملية بعد تأكيدها إلا من قبل الفرع الرئيسي.';
    } else {
        $pdo->beginTransaction();
        try {
            if ($return_stock === 'yes' && $transaction_to_delete['branch_id']) {
                $branch_id = $transaction_to_delete['branch_id'];
                
                $stmt_products = $pdo->prepare("SELECT product_id, quantity FROM transaction_products WHERE transaction_id = ?");
                $stmt_products->execute([$transaction_id]);
                $products_to_return = $stmt_products->fetchAll(PDO::FETCH_ASSOC);

                if (!empty($products_to_return)) {
                    $update_stock_stmt = $pdo->prepare("UPDATE branch_stock SET quantity = quantity + ? WHERE branch_id = ? AND product_id = ?");
                    foreach ($products_to_return as $product) {
                        $update_stock_stmt->execute([$product['quantity'], $branch_id, $product['product_id']]);
                    }
                }
            }

            $pdo->prepare("DELETE FROM payment_history WHERE sub_transaction_id IN (SELECT id FROM sub_transactions WHERE transaction_id = ?)")->execute([$transaction_id]);
            $pdo->prepare("DELETE FROM sub_transactions WHERE transaction_id = ?")->execute([$transaction_id]);
            $pdo->prepare("DELETE FROM transaction_products WHERE transaction_id = ?")->execute([$transaction_id]);
            $pdo->prepare("DELETE FROM transactions WHERE id = ?")->execute([$transaction_id]);
            
            $_SESSION['message'] = 'تم حذف العملية بنجاح.';
            if ($return_stock === 'yes' && !empty($products_to_return)) {
                $_SESSION['message'] .= ' وتم إرجاع المنتجات إلى المخزون.';
            }
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['error'] = 'حدث خطأ أثناء الحذف: ' . $e->getMessage();
        }
    }
    header("Location: " . $_SERVER['HTTP_REFERER']);
    exit();
}

$filter_status = $_GET['status'] ?? '';
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$filter_year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
$filter_month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');
$open_tx_id = isset($_GET['open_tx']) ? (int)$_GET['open_tx'] : 0;

$base_sql = "SELECT DISTINCT t.id, t.status, t.creation_date, t.confirmed_at, t.start_date, t.end_date, t.amount, t.installment_months, t.deductions_per_month,
             t.ccp_account, t.nom, t.prenom, c.first_name, c.last_name, b.name as branch_name,
             (SELECT SUM(st_paid.monthly_deduction_amount) 
              FROM sub_transactions st_paid 
              WHERE st_paid.transaction_id = t.id AND st_paid.payment_status = 'paid') as total_paid_amount,
             (SELECT GROUP_CONCAT(CONCAT(p.name, ' (x', tp.quantity, ')') SEPARATOR '<br>') 
              FROM transaction_products tp 
              JOIN products p ON tp.product_id = p.id 
              WHERE tp.transaction_id = t.id) as products_list
             FROM transactions t 
             LEFT JOIN customers c ON t.customer_id = c.id
             JOIN branches b ON t.branch_id = b.id";
$params = [];
$where_clauses = [];

if (!$is_admin_branch) {
    $where_clauses[] = "t.branch_id = ?";
    $params[] = $_SESSION['branch_id'];
}
if ($search_term) {
    $base_sql .= " LEFT JOIN sub_transactions st ON t.id = st.transaction_id";
    $where_clauses[] = "(CONCAT(COALESCE(c.first_name, ''), ' ', COALESCE(c.last_name, '')) LIKE ? OR CONCAT(COALESCE(t.prenom, ''), ' ', COALESCE(t.nom, '')) LIKE ? OR t.ccp_account LIKE ? OR st.sub_reference_id LIKE ?)";
    $like_term = "%{$search_term}%";
    array_push($params, $like_term, $like_term, $like_term, $like_term);
}
$status_conditions = [];
if ($filter_status !== 'confirmed') {
    $status_conditions[] = "t.status = 'pending'";
}
if ($filter_status !== 'pending') {
    $confirmed_part = "(t.status = 'confirmed' AND EXISTS (SELECT 1 FROM sub_transactions st_check WHERE st_check.transaction_id = t.id AND YEAR(st_check.deduction_date) = ? AND MONTH(st_check.deduction_date) = ?))";
    $status_conditions[] = $confirmed_part;
    array_push($params, $filter_year, $filter_month);
}
if (!empty($status_conditions)) {
    $where_clauses[] = '(' . implode(' OR ', $status_conditions) . ')';
}

$sql = $base_sql;
$final_where_clause = '';

if (!empty($where_clauses)) {
    $final_where_clause = '(' . implode(" AND ", $where_clauses) . ')';
}

if ($open_tx_id > 0) {
    if (!empty($final_where_clause)) {
        $final_where_clause = "($final_where_clause OR t.id = ?)";
    } else {
        $final_where_clause = "t.id = ?";
    }
    $params[] = $open_tx_id;
}

if (!empty($final_where_clause)) {
    $sql .= " WHERE " . $final_where_clause;
}

$sql .= " ORDER BY t.status DESC, t.creation_date DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$all_transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sub_transactions = [];
$transaction_products = [];
if (!empty($all_transactions)) {
    $tx_ids = array_column($all_transactions, 'id');
    if (!empty($tx_ids)) {
        $unique_tx_ids = array_unique($tx_ids);
        $in_query = implode(',', array_fill(0, count($unique_tx_ids), '?'));
        
        $stmt_sub = $pdo->prepare("SELECT id, transaction_id, sub_reference_id, monthly_deduction_amount, payment_status, deduction_date FROM sub_transactions WHERE transaction_id IN ($in_query) ORDER BY deduction_date, sub_reference_id");
        $stmt_sub->execute(array_values($unique_tx_ids));
        while ($row = $stmt_sub->fetch(PDO::FETCH_ASSOC)) {
            $sub_transactions[$row['transaction_id']][] = $row;
        }

        $stmt_prods = $pdo->prepare("SELECT tp.transaction_id, tp.quantity, p.name FROM transaction_products tp JOIN products p ON tp.product_id = p.id WHERE tp.transaction_id IN ($in_query)");
        $stmt_prods->execute(array_values($unique_tx_ids));
        while ($row = $stmt_prods->fetch(PDO::FETCH_ASSOC)) {
            $transaction_products[$row['transaction_id']][] = $row;
        }
    }
}

function render_transactions_table($transactions, $sub_transactions, $transaction_products, $is_admin_branch, $filter_year, $filter_month) {
    if (empty($transactions)) {
        $colspan = $is_admin_branch ? '9' : '8';
        echo '<tr><td colspan="' . $colspan . '" class="no-results">لا توجد عمليات تطابق معايير البحث.</td></tr>';
        return;
    }
    $first_of_current_month = new DateTime('first day of this month');
    $first_of_current_month->setTime(0, 0, 0);

    foreach ($transactions as $tx) {
        $total_amount = (float)($tx['amount'] ?? 0);
        $total_paid = (float)($tx['total_paid_amount'] ?? 0);
        $is_complete = $total_amount > 0 && round($total_paid, 2) >= round($total_amount, 2);
        
        echo '<tr class="transaction-main" data-details-id="details-row-' . $tx['id'] . '">';
        echo '<td data-label="العميل / الحساب"><strong>' . htmlspecialchars(($tx['first_name'] ?? '') . ' ' . ($tx['last_name'] ?? '') ?: ($tx['prenom'] ?? '') . ' ' . ($tx['nom'] ?? '')) . '</strong><br><small style="color:#555;">' . htmlspecialchars($tx['ccp_account'] ?? '') . '</small></td>';
        echo '<td data-label="التواريخ" class="dates-cell">';
        if ($tx['creation_date']) echo '<div><strong class="date-label">الإنشاء:</strong> ' . date('Y-m-d', strtotime($tx['creation_date'])) . '</div>';
        if ($tx['confirmed_at']) echo '<div><strong class="date-label">التأكيد:</strong> ' . date('Y-m-d', strtotime($tx['confirmed_at'])) . '</div>';
        if ($tx['start_date']) echo '<div><strong class="date-label">بداية السحب:</strong> ' . date('Y-m-d', strtotime($tx['start_date'])) . '</div>';
        echo '</td>';
        if ($is_admin_branch) echo '<td data-label="الفرع">' . htmlspecialchars($tx['branch_name']) . '</td>';
        echo '<td data-label="المبلغ">' . ($tx['amount'] ? number_format($tx['amount'], 2) . ' د.ج' : 'غير محدد') . '</td>';
        echo '<td data-label="الأقساط">';
        if ($tx['installment_months']) echo $tx['installment_months'] . ' أشهر / ' . $tx['deductions_per_month'] . ' خصم شهريا';
        else echo 'غير محدد';
        echo '</td>';
        echo '<td data-label="الحالة"><span class="status-badge status-' . htmlspecialchars($tx['status']) . '">' . ($tx['status'] === 'pending' ? 'قيد الانتظار' : 'مؤكدة') . '</span></td>';
        echo '<td data-label="السداد">';
        if ($tx['status'] === 'confirmed' && $total_amount > 0) {
            echo '<div class="progress-cell">';
            echo '<span>' . number_format($total_paid, 2) . ' / ' . number_format($total_amount, 2) . '</span>';
            if ($is_complete) {
                echo '<span class="status-badge status-complete">مكتمل</span>';
                if ($total_paid > $total_amount) {
                     $surplus = $total_paid - $total_amount;
                     echo '<span class="status-badge status-surplus" title="مبلغ زائد يجب إرجاعه للعميل">فائض: '.number_format($surplus, 2).'</span>';
                }
            }
            echo '</div>';
        } else {
            echo 'N/A';
        }
        echo '</td>';
        echo '<td class="actions-cell">';
        if ($tx['status'] === 'pending') {
            echo '<a href="edit_transaction.php?id=' . $tx['id'] . '" class="btn btn-edit">تعديل</a>';
            if ($is_admin_branch) {
                echo '<form method="POST" onsubmit="return confirm(\'هل أنت متأكد من تأكيد هذه العملية؟\');" style="display:inline;"><input type="hidden" name="confirm_transaction_id" value="' . $tx['id'] . '"><button type="submit" class="btn btn-confirm">تأكيد</button></form>';
            }
        } elseif ($tx['status'] === 'confirmed') {
            echo '<a href="invoice.php?id=' . $tx['id'] . '&year=' . $filter_year . '&month=' . $filter_month .'" class="btn btn-invoice" target="_blank">فاتورة</a>';
            if ($is_admin_branch) {
                echo '<form method="POST" onsubmit="return confirm(\'هل أنت متأكد من إرجاع هذه العملية؟ سيتم حذف جميع الاقتطاعات.\');" style="display:inline;"><input type="hidden" name="return_to_pending_id" value="' . $tx['id'] . '"><button type="submit" class="btn btn-return">إرجاع</button></form>';
            }
        }
        if ($tx['status'] === 'pending' || $is_admin_branch) {
            $products_for_this_tx = $transaction_products[$tx['id']] ?? [];
            $products_json = json_encode(array_map(function($p) { return ['name' => $p['name'], 'quantity' => $p['quantity']]; }, $products_for_this_tx));
            echo '<form method="POST" class="delete-form" style="display:inline;">';
            echo '<input type="hidden" name="delete_transaction_id" value="' . $tx['id'] . '">';
            echo '<input type="hidden" name="return_stock" value="yes">';
            echo '<button type="button" class="btn btn-delete" data-products-info=\'' . htmlspecialchars($products_json, ENT_QUOTES, 'UTF-8') . '\'>حذف</button>';
            echo '</form>';
        }
        echo '</td></tr>';

        $colspan = $is_admin_branch ? '9' : '8';
        echo '<tr class="transaction-details" id="details-row-' . $tx['id'] . '"><td colspan="' . $colspan . '" class="details-cell"><div class="details-content-wrapper">';
        if (!empty($tx['products_list'])) {
            echo '<div class="details-section"><h5>المنتجات المباعة:</h5><p>' . $tx['products_list'] . '</p></div>';
        }
        if ($tx['status'] === 'confirmed') {
            if (isset($sub_transactions[$tx['id']])) {
                echo '<div class="details-section">';
                echo '<form method="POST" class="sub-transaction-form"><input type="hidden" name="save_payment_changes" value="1">';
                if ($is_admin_branch) {
                    echo '<div class="batch-actions-header"><span>قائمة الاقتطاعات الكاملة</span><div class="batch-actions"><button type="button" class="btn btn-pay-all">دفع الكل</button><button type="button" class="btn btn-unpay-all">إلغاء الكل</button></div></div>';
                }
                $grouped_subs = [];
                foreach($sub_transactions[$tx['id']] as $sub) {
                    $grouped_subs[date('Y-m', strtotime($sub['deduction_date']))][] = $sub;
                }
                ksort($grouped_subs);
                foreach ($grouped_subs as $month => $subs) {
                    $is_current_filter_month = (date('Y-n', strtotime($month)) == $filter_year.'-'.$filter_month);
                    echo '<div class="deductions-month-group ' . ($is_current_filter_month ? 'current-month-group' : '') . '">';
                    echo '<h5 class="deductions-month-header">' . date('F Y', strtotime($month)) . '</h5>';
                    foreach ($subs as $sub) {
                        $is_paid = $sub['payment_status'] === 'paid';
                        $deduction_date_obj = new DateTime($sub['deduction_date']);
                        $row_class = 'ref-item';
                        if ($is_paid) {
                            $row_class .= ' status-paid-row';
                        } else {
                            if ($deduction_date_obj < $first_of_current_month) {
                                $row_class .= ' status-overdue-row';
                            }
                        }
                        echo '<div class="' . $row_class . '"><div class="ref-item-info"><span class="ref-status-text">' . ($is_paid ? 'مدفوع' : 'غير مدفوع') . '</span><span>' . htmlspecialchars($sub['sub_reference_id']) . '</span></div><div class="ref-item-actions"><strong>' . number_format($sub['monthly_deduction_amount'], 2) . ' د.ج</strong><input type="checkbox" class="payment-checkbox" data-sub-id="' . $sub['id'] . '" data-original-status="' . $sub['payment_status'] . '" ' . ($is_paid ? 'checked' : '') . ' ' . ($is_admin_branch ? '' : 'disabled') . '></div></div>';
                    }
                    echo '</div>';
                }
                if ($is_admin_branch) {
                    echo '<div class="save-actions" style="display: none; margin-top: 1rem; text-align: left;"><button type="submit" class="btn btn-success">حفظ التغييرات</button></div>';
                }
                echo '</form>';
                echo '</div>';
            } else {
                echo '<p>لا توجد اقتطاعات مجدولة لهذه العملية.</p>';
            }
        } else {
            echo '<p>التفاصيل تكون متاحة عند تأكيد العملية.</p>';
        }
        echo '</div></td></tr>';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة العمليات - <?php echo htmlspecialchars($branch['name']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #161332;
            --secondary-color: #6a5af9;
            --background-color: #f0f2f5;
            --card-bg-color: rgba(255, 255, 255, 0.7);
            --text-color: #333;
            --header-text-color: #ffffff;
            --shadow-color: rgba(22, 19, 50, 0.15);
            --font-family: 'Cairo', sans-serif;
            --status-pending-bg: #fff3cd; 
            --status-pending-text: #664d03;
            --status-confirmed-bg: #d1e7dd; 
            --status-confirmed-text: #0f5132;
            --status-cancelled-bg: #f8d7da; 
            --status-cancelled-text: #58151c;
            --btn-success-bg: #198754;
            --status-complete-bg: #198754;
            --status-surplus-bg: #fd7e14;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: var(--font-family); background-color: var(--background-color); line-height: 1.6; color: var(--text-color); background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); }
        .header { background: var(--primary-color); color: var(--header-text-color); padding: 1rem 1.5rem; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); }
        .header-content { max-width: 1400px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; }
        .header h1 { font-size: 1.5rem; }
        .nav-links { display: flex; gap: 0.5rem; }
        .nav-links a { color: var(--header-text-color); text-decoration: none; padding: 0.5rem 1rem; border-radius: 8px; transition: background 0.3s ease; font-weight: 500; }
        .nav-links a:hover, .nav-links a.active { background: rgba(255, 255, 255, 0.1); }
        .container { max-width: 1400px; margin: 1rem auto; padding: 0 1rem; }
        .card { background: var(--card-bg-color); border-radius: 15px; padding: 1.5rem; box-shadow: 0 10px 30px var(--shadow-color); border: 1px solid rgba(255, 255, 255, 0.8); backdrop-filter: blur(10px); }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
        .page-header h2, .section-header { font-size: 1.5rem; font-weight: 700; color: var(--primary-color); }
        .section-header { font-size: 1.3rem; margin-top: 1.5rem; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid var(--secondary-color); }
        .page-header .header-actions { display: flex; flex-wrap: wrap; gap: 0.5rem; }
        .filter-section { padding: 1rem; background: rgba(22, 19, 50, 0.03); border-radius: 8px; margin-bottom: 1.5rem; }
        .filter-controls { display: grid; grid-template-columns: 1fr; gap: 1rem; align-items: center; }
        .filter-group { display: flex; flex-direction: column; gap: 0.5rem;}
        .filter-group label { font-weight: 700; font-size: 0.9rem; }
        .filter-group select, .filter-group input { padding: 0.5rem; border-radius: 6px; border: 1px solid #ccc; font-size: 1rem; }
        .filter-buttons { display: flex; gap: 0.5rem; flex-wrap: wrap; }
        .filter-buttons a { text-decoration: none; padding: 0.5rem 1rem; border-radius: 8px; font-weight: 500; transition: all 0.3s; border: 1px solid transparent; }
        .filter-buttons a.all { background: #6c757d; color: white; }
        .filter-buttons a.pending { background: var(--status-pending-bg); color: var(--status-pending-text); }
        .filter-buttons a.confirmed { background: var(--status-confirmed-bg); color: var(--status-confirmed-text); }
        .filter-buttons a.active { border-color: var(--primary-color); box-shadow: 0 0 5px rgba(22, 19, 50, 0.3); font-weight: 700; }
        .search-form { display: flex; width: 100%; }
        .search-form input { width: 100%; padding: 0.6rem 1rem; border: 1px solid #ccc; border-radius: 8px 0 0 8px; font-family: var(--font-family); }
        .search-form button { padding: 0.6rem 1.2rem; border-radius: 0 8px 8px 0; border: none; background: var(--primary-color); color: white; cursor: pointer; }
        .alert { padding: 1rem; border-radius: 8px; margin-bottom: 1rem; border-left: 5px solid; font-weight: 500; white-space: pre-wrap; }
        .alert.success { background-color: var(--status-confirmed-bg); color: var(--status-confirmed-text); border-color: #198754; }
        .alert.error { background-color: var(--status-cancelled-bg); color: var(--status-cancelled-text); border-color: #dc3545; }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 0.8rem; text-align: right; vertical-align: middle; }
        th { background-color: rgba(22, 19, 50, 0.05); font-weight: 700; }
        tbody tr.transaction-main { border-bottom: 1px solid #ddd; cursor: pointer; transition: background-color 0.2s ease; }
        tbody tr.transaction-main:hover { background-color: #f0f4f8; }
        tbody tr.transaction-main.active-row { background-color: #e9eef2; }
        tbody tr.transaction-details { display: table-row; }
        .details-cell { padding: 0; background-color: #fdfdfd; }
        .details-content-wrapper { max-height: 0; overflow-y: hidden; transition: max-height 0.4s ease-out, padding 0.4s ease-out; padding: 0 1.5rem; }
        tr.transaction-details.details-visible .details-content-wrapper { max-height: 1000px; overflow-y: auto; padding: 1.5rem; }
        .details-section { margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 1px solid #eee; }
        .details-section:last-child { border-bottom: none; margin-bottom: 0; padding-bottom: 0; }
        .details-section h5 { margin-bottom: 0.5rem; }
        .status-badge { padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.8rem; font-weight: 700; margin: 2px; display: inline-block; }
        .status-pending { background-color: var(--status-pending-bg); color: var(--status-pending-text); }
        .status-confirmed { background-color: var(--status-confirmed-bg); color: var(--status-confirmed-text); }
        .status-complete { background-color: var(--status-complete-bg); color: white; }
        .status-surplus { background-color: var(--status-surplus-bg); color: white; }
        .actions-cell { display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap; }
        .btn { border: none; padding: 0.5rem 0.8rem; border-radius: 6px; cursor: pointer; transition: all 0.2s; text-decoration: none; display: inline-block; font-family: var(--font-family); font-size: 0.85rem; font-weight: 500; color: white; }
        .btn-confirm { background: #198754; } .btn-confirm:hover { background: #157347; }
        .btn-edit { background: #0d6efd; } .btn-edit:hover { background: #0b5ed7; }
        .btn-delete { background: #dc3545; } .btn-delete:hover { background: #bb2d3b; }
        .btn-return { background: #ffc107; color: #212529; } .btn-return:hover { background: #e0a800; }
        .btn-invoice { background: #6c757d; } .btn-invoice:hover { background: #5c636a; }
        .btn-pay-all, .btn-unpay-all { background: #28a745; color: white; padding: 2px 8px; font-size: 0.8em; border: none; border-radius: 4px; } .btn-pay-all:hover { background: #218838; }
        .btn-unpay-all { background: var(--status-cancelled-text); } .btn-unpay-all:hover { background: #a1232c; }
        .btn-success { background-color: var(--btn-success-bg); }
        .no-results { text-align: center; padding: 3rem; font-size: 1.2rem; color: #666; }
        .progress-cell { display: flex; flex-direction: column; align-items: flex-start; gap: 4px; }
        .dates-cell { font-size: 0.85rem; line-height: 1.5; white-space: nowrap; }
        .date-label { font-weight: 700; color: #555; }
        .batch-actions-header { display: flex; justify-content: space-between; align-items: center; padding: 0.5rem; background-color: #f0f4f8; border-radius: 6px; margin-bottom: 1rem; }
        .deductions-month-group { margin-bottom: 1rem; border: 1px solid #e9ecef; border-radius: 8px; overflow: hidden; }
        .deductions-month-header { background-color: #f8f9fa; padding: 0.5rem 1rem; font-size: 1rem; color: var(--primary-color); border-bottom: 1px solid #e9ecef; }
        .current-month-group { border-color: var(--secondary-color); box-shadow: 0 0 8px rgba(106, 90, 249, 0.2); }
        .ref-item { display: flex; justify-content: space-between; align-items: center; font-family: monospace; font-size: 0.9em; padding: 8px 1rem; border-bottom: 1px solid #f5f5f5; flex-wrap: wrap; gap: 0.5rem; transition: background-color 0.3s ease; }
        .ref-item:last-child { border-bottom: none; }
        .ref-item.status-paid-row { background-color: var(--status-confirmed-bg); color: var(--status-confirmed-text); }
        .ref-item.status-overdue-row { background-color: var(--status-cancelled-bg); color: var(--status-cancelled-text); }
        .ref-item strong { color: var(--primary-color); }
        .ref-item.status-paid-row strong, .ref-item.status-overdue-row strong { color: inherit; }
        .ref-status-text { font-weight: bold; margin-left: 10px; }
        .ref-item-info { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .ref-item-actions { display: flex; align-items: center; gap: 1rem; }
        .payment-checkbox { transform: scale(1.3); cursor: pointer; }
        .payment-checkbox:disabled { cursor: not-allowed; opacity: 0.5; }
        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); z-index: 2000; display: none; justify-content: center; align-items: center; padding: 1rem; }
        .modal-content { background: white; padding: 2rem; border-radius: 10px; width: 100%; max-width: 500px; box-shadow: 0 5px 15px rgba(0,0,0,0.3); text-align: center; }
        .modal-content h3 { margin-bottom: 1.5rem; color: var(--primary-color); }
        .modal-content input[type="file"] { margin-bottom: 1.5rem; }
        #deleteModalProducts { margin: 1rem 0; text-align: right; background: #f1f1f1; padding: 0.5rem 1rem; border-radius: 6px; font-size: 0.9rem; }
        #deleteModalProducts h5 { margin-bottom: 0.5rem; }
        #deleteModalProducts ul { list-style-position: inside; padding-right: 0; }
        .modal-actions { display: flex; justify-content: center; gap: 1rem; }
        @media (min-width: 769px) { .filter-controls { grid-template-columns: auto auto 1fr; } .search-form { justify-self: end; } }
        @media (max-width: 992px) {
            .table-responsive { border: none; }
            table thead { display: none; }
            table tbody tr.transaction-main { display: block; margin-bottom: 1.5rem; border: 1px solid #ddd; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); padding: 1rem; }
            table td { display: flex; justify-content: space-between; align-items: center; text-align: right; padding: 0.75rem 0.5rem; border-bottom: 1px solid #eee; }
            table td:last-child { border-bottom: none; }
            table td::before { content: attr(data-label); font-weight: 700; color: var(--primary-color); margin-left: 1rem; }
            .actions-cell { flex-direction: row; flex-wrap: wrap; justify-content: flex-start; }
            .actions-cell::before { display: none; }
            .actions-cell { justify-content: center; padding-top: 1rem; }
            .dates-cell { flex-direction: column; align-items: flex-start; }
            .dates-cell div { width: 100%; display: flex; justify-content: space-between; }
            .filter-controls { grid-template-columns: 1fr; } 
            .search-form { justify-self: stretch; }
        }
        @media (max-width: 768px) {
            .header-content { flex-direction: column; gap: 1rem; }
            .nav-links { flex-direction: column; align-items: center; width: 100%; }
            .nav-links a { width: 100%; text-align: center; }
            .page-header { flex-direction: column; align-items: flex-start; }
            .filter-controls > div { flex-direction: column; align-items: stretch; }
        }
    </style>
</head>
<body data-open-tx="<?php echo $open_tx_id; ?>">
    <header class="header">
        <div class="header-content">
            <h1><?php echo htmlspecialchars($branch['name']); ?></h1>
            <nav class="nav-links">
                <a href="index.php">الرئيسية</a>
                <a href="add_customer.php">إضافة عميل</a>
                <a href="ccp_automation.php">إنشاء وثيقة</a>
                <a href="transactions.php" class="active">العمليات</a>
                <?php if ($is_admin_branch): ?>
                    <a href="delinquent_payments.php">تقرير المتأخرات</a>
                    <a href="inventory.php">لوحة تحكم المخزون</a>
                <?php endif; ?>
                <a href="logout.php">تسجيل الخروج</a>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <div class="card">
            <div class="page-header">
                <h2>سجل العمليات</h2>
                <div class="header-actions">
                    <?php if ($is_admin_branch): ?>
                        <a href="payment_report.php?year=<?php echo $filter_year; ?>&month=<?php echo $filter_month; ?>" class="btn" style="background-color: #6f42c1;">عرض تقرير الدفع</a>
                        <button id="processFileBtn" class="btn" style="background-color: #0dcaf0;">معالجة ملف التسديد</button>
                        <a href="export_excel.php?year=<?php echo $filter_year; ?>&month=<?php echo $filter_month; ?>" class="btn" style="background-color: #157347;">تصدير إلى Excel</a>
                    <?php endif; ?>
                </div>
            </div>

            <form action="transactions.php" method="GET" id="filterForm" class="filter-section">
                <div class="filter-controls">
                    <div class="filter-group">
                        <label>فلترة حسب الحالة</label>
                        <div class="filter-buttons">
                            <a href="?year=<?php echo $filter_year; ?>&month=<?php echo $filter_month; ?>&search=<?php echo urlencode($search_term);?>" class="all <?php echo !$filter_status ? 'active' : ''; ?>">الكل</a>
                            <a href="?status=pending&year=<?php echo $filter_year; ?>&month=<?php echo $filter_month; ?>&search=<?php echo urlencode($search_term);?>" class="pending <?php echo $filter_status == 'pending' ? 'active' : ''; ?>">قيد الانتظار</a>
                            <a href="?status=confirmed&year=<?php echo $filter_year; ?>&month=<?php echo $filter_month; ?>&search=<?php echo urlencode($search_term);?>" class="confirmed <?php echo $filter_status == 'confirmed' ? 'active' : ''; ?>">المؤكدة</a>
                        </div>
                    </div>
                    <div style="display: flex; gap: 1rem; align-items: flex-end;">
                        <div class="filter-group"><label for="month_filter">الشهر</label><select name="month" id="month_filter" onchange="this.form.submit()"><?php for ($m = 1; $m <= 12; $m++): ?><option value="<?php echo $m; ?>" <?php echo $m == $filter_month ? 'selected' : ''; ?>><?php echo date('F', mktime(0, 0, 0, $m, 10)); ?></option><?php endfor; ?></select></div>
                        <div class="filter-group"><label for="year_filter">السنة</label><select name="year" id="year_filter" onchange="this.form.submit()"><?php for ($y = date('Y'); $y >= date('Y') - 5; $y--): ?><option value="<?php echo $y; ?>" <?php echo $y == $filter_year ? 'selected' : ''; ?>><?php echo $y; ?></option><?php endfor; ?></select></div>
                    </div>
                    <div class="search-form">
                        <?php if ($filter_status): ?><input type="hidden" name="status" value="<?php echo htmlspecialchars($filter_status); ?>"><?php endif; ?>
                        <input type="text" name="search" placeholder="ابحث بالاسم، CCP، أو المرجع..." value="<?php echo htmlspecialchars($search_term); ?>">
                        <button type="submit">بحث</button>
                    </div>
                </div>
            </form>

            <?php if ($message): ?><div class="alert success"><?php echo nl2br(htmlspecialchars($message)); ?></div><?php endif; ?>
            <?php if ($error): ?><div class="alert error"><?php echo nl2br(htmlspecialchars($error)); ?></div><?php endif; ?>

            <div class="table-responsive">
                 <table>
                    <thead>
                        <tr>
                            <th>العميل / الحساب</th>
                            <th>التواريخ الرئيسية</th>
                            <?php if ($is_admin_branch): ?><th>الفرع</th><?php endif; ?>
                            <th>المبلغ الإجمالي</th>
                            <th>تفاصيل الأقساط</th>
                            <th>حالة العملية</th>
                            <th>حالة السداد</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php render_transactions_table($all_transactions, $sub_transactions, $transaction_products, $is_admin_branch, $filter_year, $filter_month); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <?php if ($is_admin_branch): ?>
    <div id="uploadModal" class="modal-overlay">
        <div class="modal-content">
            <h3>معالجة ملف التسديد</h3>
            <p style="margin-bottom: 1rem; color: #555;">اختر ملف التسديد النصي لتحديث حالات الدفع تلقائياً.</p>
            <form action="process_return_file.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="month" value="<?php echo $filter_month; ?>">
                <input type="hidden" name="year" value="<?php echo $filter_year; ?>">
                <input type="file" name="return_file" required accept=".txt, text/plain">
                <div class="modal-actions">
                    <button type="submit" class="btn btn-success">رفع ومعالجة</button>
                    <button type="button" id="closeModalBtn" class="btn" style="background-color: #6c757d;">إلغاء</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <div id="deleteConfirmModal" class="modal-overlay">
        <div class="modal-content">
            <h3>تأكيد الحذف</h3>
            <p id="deleteModalText">هل أنت متأكد من حذف هذه العملية بشكل دائم؟</p>
            <div id="deleteModalProducts" style="display: none;"></div>
            <div class="modal-actions">
                <button id="deleteConfirmBtn" class="btn btn-delete">تأكيد الحذف</button>
                <button id="deleteCancel" class="btn" style="background-color: #6c757d;">إلغاء</button>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelector('tbody').addEventListener('click', function(event) {
            const row = event.target.closest('.transaction-main');
            if (row && !event.target.closest('a, button, form')) {
                const detailsRow = document.getElementById(row.dataset.detailsId);
                if (!detailsRow) return;

                const isVisible = detailsRow.classList.contains('details-visible');
                document.querySelectorAll('.transaction-details.details-visible').forEach(openDetail => {
                    if (openDetail !== detailsRow) {
                        openDetail.classList.remove('details-visible');
                        const correspondingMainRow = document.querySelector(`.transaction-main[data-details-id="${openDetail.id}"]`);
                        if(correspondingMainRow) correspondingMainRow.classList.remove('active-row');
                    }
                });
                detailsRow.classList.toggle('details-visible', !isVisible);
                row.classList.toggle('active-row', !isVisible);
            }
        });

        function handleCheckboxChanges(form) {
            const saveActions = form.querySelector('.save-actions');
            if (!saveActions) return;
            let hasChanges = false;
            form.querySelectorAll('.payment-checkbox').forEach(cb => {
                if (cb.checked !== (cb.dataset.originalStatus === 'paid')) hasChanges = true;
            });
            saveActions.style.display = hasChanges ? 'block' : 'none';
        }

        document.querySelectorAll('.sub-transaction-form').forEach(form => {
            form.addEventListener('change', e => e.target.classList.contains('payment-checkbox') && handleCheckboxChanges(form));
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                this.querySelectorAll('input[name^="mark_"]').forEach(i => i.remove());
                this.querySelectorAll('.payment-checkbox').forEach(cb => {
                    const originalStatus = cb.dataset.originalStatus;
                    let action = null;
                    if (cb.checked && originalStatus === 'unpaid') action = 'mark_paid[]';
                    else if (!cb.checked && originalStatus === 'paid') action = 'mark_unpaid[]';
                    if (action) {
                        const input = document.createElement('input');
                        input.type = 'hidden';
                        input.name = action;
                        input.value = cb.dataset.subId;
                        this.appendChild(input);
                    }
                });
                this.submit();
            });
            form.querySelector('.btn-pay-all')?.addEventListener('click', () => {
                form.querySelectorAll('.payment-checkbox:not(:checked)').forEach(cb => !cb.disabled && (cb.checked = true));
                handleCheckboxChanges(form);
            });
            form.querySelector('.btn-unpay-all')?.addEventListener('click', () => {
                form.querySelectorAll('.payment-checkbox:checked').forEach(cb => !cb.disabled && (cb.checked = false));
                handleCheckboxChanges(form);
            });
        });
    
        <?php if ($is_admin_branch): ?>
        const uploadModal = document.getElementById('uploadModal');
        const processFileBtn = document.getElementById('processFileBtn');
        const closeModalBtn = document.getElementById('closeModalBtn');
        if(processFileBtn) processFileBtn.addEventListener('click', () => uploadModal.style.display = 'flex');
        if(closeModalBtn) closeModalBtn.addEventListener('click', () => uploadModal.style.display = 'none');
        if(uploadModal) uploadModal.addEventListener('click', e => e.target === uploadModal && (uploadModal.style.display = 'none'));
        <?php endif; ?>

        const deleteModal = document.getElementById('deleteConfirmModal');
        const deleteModalProducts = document.getElementById('deleteModalProducts');
        const confirmBtn = document.getElementById('deleteConfirmBtn');
        const cancelBtn = document.getElementById('deleteCancel');
        let activeDeleteForm = null;

        document.querySelector('tbody').addEventListener('click', function(e) {
            if (e.target.classList.contains('btn-delete')) {
                e.preventDefault();
                activeDeleteForm = e.target.closest('form.delete-form');
                const productsInfo = JSON.parse(e.target.dataset.productsInfo);
                
                if (productsInfo && productsInfo.length > 0) {
                    let productListHtml = '<h5>سيتم إرجاع المنتجات التالية إلى المخزون:</h5><ul>';
                    productsInfo.forEach(item => {
                        productListHtml += `<li>${item.name} (x${item.quantity})</li>`;
                    });
                    productListHtml += '</ul>';
                    deleteModalProducts.innerHTML = productListHtml;
                    deleteModalProducts.style.display = 'block';
                } else {
                    deleteModalProducts.style.display = 'none';
                }
                deleteModal.style.display = 'flex';
            }
        });

        function hideDeleteModal() {
            deleteModal.style.display = 'none';
            activeDeleteForm = null;
        }

        confirmBtn.addEventListener('click', () => {
            if (activeDeleteForm) {
                activeDeleteForm.submit();
            }
        });

        cancelBtn.addEventListener('click', hideDeleteModal);
        deleteModal.addEventListener('click', e => e.target === deleteModal && hideDeleteModal());

        const body = document.body;
        const txIdToOpen = body.dataset.openTx;
        if (txIdToOpen && txIdToOpen !== '0') {
            const targetRow = document.querySelector(`.transaction-main[data-details-id="details-row-${txIdToOpen}"]`);
            const targetDetails = document.getElementById(`details-row-${txIdToOpen}`);
            if (targetRow && targetDetails) {
                targetRow.classList.add('active-row');
                targetDetails.classList.add('details-visible');
                targetRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
    });
    </script>
</body>
</html>