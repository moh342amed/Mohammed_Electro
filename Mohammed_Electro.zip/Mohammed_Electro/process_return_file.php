<?php
require_once 'config.php';
requireLogin();

$redirect_url = 'transactions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . $redirect_url);
    exit();
}

$batch_month = isset($_POST['month']) ? (int)$_POST['month'] : 0;
$batch_year = isset($_POST['year']) ? (int)$_POST['year'] : 0;

$report_url = 'payment_report.php?' . http_build_query(['year' => $batch_year, 'month' => $batch_month]);

if (empty($batch_month) || empty($batch_year) || !isset($_FILES['return_file']) || $_FILES['return_file']['error'] !== 0) {
    $_SESSION['error'] = 'خطأ في رفع الملف أو أن الشهر والسنة غير محددين. يرجى المحاولة مرة أخرى.';
    header('Location: ' . $redirect_url . '?' . http_build_query(['year' => $batch_year, 'month' => $batch_month]));
    exit();
}

$file_path = $_FILES['return_file']['tmp_name'];

try {
    $pdo->beginTransaction();

    $pdo->prepare("DELETE FROM payment_history WHERE batch_year = ? AND batch_month = ?")->execute([$batch_year, $batch_month]);

    $stmt_expected = $pdo->prepare("
        SELECT st.id, st.sub_reference_id, t.ccp_account
        FROM sub_transactions st
        JOIN transactions t ON st.transaction_id = t.id
        WHERE t.status = 'confirmed' 
          AND st.payment_status = 'unpaid'
          AND YEAR(st.deduction_date) = ? 
          AND MONTH(st.deduction_date) = ?
    ");
    $stmt_expected->execute([$batch_year, $batch_month]);
    $results = $stmt_expected->fetchAll(PDO::FETCH_ASSOC);

    $expected_transactions = [];
    foreach ($results as $row) {
        $expected_transactions[$row['sub_reference_id']] = ['id' => $row['id'], 'ccp_account' => $row['ccp_account'], 'matched' => false];
    }

    $file_handle = @fopen($file_path, 'r');
    if (!$file_handle) {
        throw new Exception('لا يمكن فتح الملف المرفوع.');
    }

    $stmt_insert_history = $pdo->prepare("INSERT INTO payment_history (batch_year, batch_month, sub_transaction_id, reference_id_from_file, status_code_from_file, line_from_file, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt_update_paid = $pdo->prepare("UPDATE sub_transactions SET payment_status = 'paid' WHERE id = ?");

    $lines = explode("\n", trim(stream_get_contents($file_handle)));
    fclose($file_handle);

    $successful_payments = [];
    foreach ($lines as $line) {
        if (empty($line) || strlen($line) < 75) continue;

        $status_code = trim(substr($line, 71, 1));
        $reference_id_from_file = trim(substr($line, 74));
        if (empty($reference_id_from_file)) continue;

        if ($status_code === '0') {
            if (!isset($successful_payments[$reference_id_from_file])) {
                $successful_payments[$reference_id_from_file] = 0;
            }
            $successful_payments[$reference_id_from_file]++;
        }

        $sub_transaction_id = null;
        if (isset($expected_transactions[$reference_id_from_file])) {
            $sub_transaction_id = $expected_transactions[$reference_id_from_file]['id'];
            $expected_transactions[$reference_id_from_file]['matched'] = true;
            $stmt_insert_history->execute([$batch_year, $batch_month, $sub_transaction_id, $reference_id_from_file, $status_code, $line, 'processed']);
            if ($status_code === '0') {
                $stmt_update_paid->execute([$sub_transaction_id]);
            }
        } else {
            $stmt_insert_history->execute([$batch_year, $batch_month, null, $reference_id_from_file, $status_code, $line, 'unmatched']);
        }
    }

    $revision_messages = [];
    $forward_payment_messages = [];
    $excess_payment_messages = [];

    $transaction_payment_data = [];
    $stmt_get_info = $pdo->prepare("
        SELECT t.id as transaction_id, st.monthly_deduction_amount 
        FROM sub_transactions st 
        JOIN transactions t ON st.transaction_id = t.id 
        WHERE st.sub_reference_id = ? 
        LIMIT 1
    ");

    foreach ($successful_payments as $ref_id => $count) {
        $stmt_get_info->execute([$ref_id]);
        $info = $stmt_get_info->fetch(PDO::FETCH_ASSOC);

        if ($info && $info['transaction_id']) {
            $transaction_id = $info['transaction_id'];
            if (!isset($transaction_payment_data[$transaction_id])) {
                $transaction_payment_data[$transaction_id] = [
                    'total_payments' => 0,
                    'batch_payments_due' => 0,
                    'amount' => $info['monthly_deduction_amount'],
                    'refs' => []
                ];
            }
            $transaction_payment_data[$transaction_id]['total_payments'] += $count;
            if ($count > 0) {
                 $transaction_payment_data[$transaction_id]['batch_payments_due']++;
            }
            $transaction_payment_data[$transaction_id]['refs'][] = $ref_id;
        }
    }

    foreach ($transaction_payment_data as $transaction_id => $data) {
        $extra_deductions_available = $data['total_payments'] - $data['batch_payments_due'];

        if ($extra_deductions_available <= 0) {
            continue;
        }

        $reference_amount = $data['amount'];
        $representative_ref_id = $data['refs'][0];

        $stmt_unpaid = $pdo->prepare("
            SELECT id, sub_reference_id, YEAR(deduction_date) as year, MONTH(deduction_date) as month, deduction_date
            FROM sub_transactions
            WHERE transaction_id = ? AND payment_status = 'unpaid'
            ORDER BY deduction_date ASC
        ");
        $stmt_unpaid->execute([$transaction_id]);
        
        $current_month_start = date('Y-m-01', mktime(0, 0, 0, $batch_month, 1, $batch_year));

        while (($unpaid = $stmt_unpaid->fetch(PDO::FETCH_ASSOC)) && $extra_deductions_available > 0) {
            $stmt_update_paid->execute([$unpaid['id']]);
            
            $period_type = ($unpaid['deduction_date'] < $current_month_start) ? 'past' : 'future';
            $log_type = ($period_type === 'past') ? 'REVISION' : 'FORWARD-PAID';
            $msg_period = ($period_type === 'past') ? 'السابق' : 'المستقبلي';

            $line_info = "{$log_type}: Paid by extra deduction from batch {$batch_year}-{$batch_month}";
            $stmt_insert_history->execute([$unpaid['year'], $unpaid['month'], $unpaid['id'], $representative_ref_id, '0', $line_info, 'processed']);

            $message = "ملف العملية {$transaction_id} (عبر المرجع {$representative_ref_id}): تم تسديد الشهر {$msg_period} " . $unpaid['year'] . '-' . str_pad($unpaid['month'], 2, '0', STR_PAD_LEFT) . " (للمرجع: {$unpaid['sub_reference_id']}).";
            
            if ($period_type === 'past') {
                $revision_messages[] = $message;
            } else {
                $forward_payment_messages[] = $message;
            }

            $extra_deductions_available--;
        }

        if ($extra_deductions_available > 0) {
            $total_excess_amount = $extra_deductions_available * $reference_amount;
            $refs_display = implode(', ', $data['refs']);
            $excess_payment_messages[] = "ملف العملية {$transaction_id}: تم خصم مبلغ إضافي {$extra_deductions_available} مرة (المبلغ الإجمالي: " . number_format($total_excess_amount, 2) . " د.ج) بعد تسديد كل الأقساط المتاحة. المراجع المعنية: ({$refs_display}).";
        }
    }
    
    foreach ($expected_transactions as $ref_id => $details) {
        if (!$details['matched']) {
            $stmt_insert_history->execute([$batch_year, $batch_month, $details['id'], $ref_id, '-1', null, 'missing']);
        }
    }

    $_SESSION['revision_messages'] = $revision_messages;
    $_SESSION['forward_payment_messages'] = $forward_payment_messages;
    $_SESSION['excess_payment_messages'] = $excess_payment_messages;
    
    $pdo->commit();

} catch (Exception $e) {
    $pdo->rollBack();
    $_SESSION['error'] = 'حدث خطأ فادح أثناء المعالجة: ' . $e->getMessage();
    header('Location: ' . $report_url);
    exit();
}

$_SESSION['message'] = "تمت معالجة ملف التسديد بنجاح. يتم الآن عرض التقرير.";
header('Location: ' . $report_url);
exit();
?>