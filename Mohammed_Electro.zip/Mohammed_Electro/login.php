<?php
require_once 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitizeInput($_POST['username']);
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM branches WHERE username = ? AND password = MD5(?)");
    $stmt->execute([$username, $password]);
    $branch = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($branch) {
        session_regenerate_id(true);
        $_SESSION['branch_id'] = $branch['id'];
        $_SESSION['branch_name'] = $branch['name'];
        $_SESSION['branch_location'] = $branch['location'];
        header('Location: index.php');
        exit();
    } else {
        $error = 'اسم المستخدم أو كلمة المرور غير صحيحة';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>دخول الفرع - نظام إدارة العملاء</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(-45deg, #1a1a2e, #16213e, #0f3460, #1a1a2e);
            background-size: 400% 400%;
            animation: gradientShift 20s ease infinite;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        #spiderCanvas {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            pointer-events: none;
        }
        .login-container {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 3rem;
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            width: 100%;
            max-width: 450px;
            position: relative;
            z-index: 10;
            transform: translateY(50px);
            opacity: 0;
            animation: slideIn 1s ease-out forwards;
        }
        @keyframes slideIn {
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
            position: relative;
        }
        .login-header::before {
            content: '';
            position: absolute;
            top: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 50px;
            height: 4px;
            background: linear-gradient(45deg, #4a90e2, #357abd);
            border-radius: 2px;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { transform: translateX(-50%) scale(1); }
            50% { transform: translateX(-50%) scale(1.2); }
        }
        .login-header h1 {
            color: rgba(255, 255, 255, 0.95);
            margin-bottom: 0.5rem;
            font-size: 2rem;
            font-weight: 700;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            animation: textGlow 3s ease-in-out infinite alternate;
        }
        @keyframes textGlow {
            from { text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5); }
            to { text-shadow: 0 0 20px rgba(74, 144, 226, 0.3), 2px 2px 4px rgba(0, 0, 0, 0.5); }
        }
        .login-header p {
            color: rgba(255, 255, 255, 0.8);
            font-size: 1rem;
            font-weight: 300;
        }
        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }
        .input-container {
            position: relative;
            overflow: hidden;
        }
        .input-container::before {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: linear-gradient(45deg, #4a90e2, #357abd);
            transition: width 0.5s ease;
        }
        .input-container:focus-within::before {
            width: 100%;
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            color: rgba(255, 255, 255, 0.9);
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 1rem;
            border: none;
            border-bottom: 2px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px 10px 0 0;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.08);
            color: rgba(255, 255, 255, 0.95);
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }
        input[type="text"]:focus, input[type="password"]:focus {
            outline: none;
            background: rgba(255, 255, 255, 0.12);
            border-bottom-color: rgba(74, 144, 226, 0.8);
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        input::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }
        .login-btn {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(45deg, #4a90e2, #357abd);
            color: white;
            border: none;
            border-radius: 50px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(74, 144, 226, 0.3);
        }
        .login-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }
        .login-btn:hover::before {
            left: 100%;
        }
        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(74, 144, 226, 0.4);
            background: linear-gradient(45deg, #357abd, #2c5f94);
        }
        .login-btn:active {
            transform: translateY(0);
            box-shadow: 0 2px 10px rgba(74, 144, 226, 0.3);
        }
        .error {
            color: #ff6b6b;
            text-align: center;
            margin-bottom: 1rem;
            padding: 0.8rem;
            background: rgba(255, 107, 107, 0.1);
            border-radius: 10px;
            border: 1px solid rgba(255, 107, 107, 0.3);
            backdrop-filter: blur(10px);
            animation: shake 0.5s ease-in-out;
        }
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }
        @media (max-width: 480px) {
            .login-container {
                margin: 1rem;
                padding: 2rem;
            }
            .login-header h1 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <canvas id="spiderCanvas"></canvas>
    <div class="login-container">
        <div class="login-header">
            <h1>نظام إدارة العملاء</h1>
            <p>دخول الفرع</p>
        </div>
        
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="username">اسم المستخدم:</label>
                <div class="input-container">
                    <input type="text" id="username" name="username" placeholder="أدخل اسم المستخدم" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="password">كلمة المرور:</label>
                <div class="input-container">
                    <input type="password" id="password" name="password" placeholder="أدخل كلمة المرور" required>
                </div>
            </div>
            
            <button type="submit" class="login-btn">دخول</button>
        </form>
    </div>
    <script>
        class SpiderWeb{constructor(){this.canvas=document.getElementById('spiderCanvas');this.ctx=this.canvas.getContext('2d');this.particles=[];this.mouse={x:0,y:0};this.particleCount=80;this.connectionDistance=150;this.mouseConnectionDistance=200;this.init()}
init(){this.resize();this.createParticles();this.animate();window.addEventListener('resize',()=>this.resize());window.addEventListener('mousemove',(e)=>this.updateMouse(e))}
resize(){this.canvas.width=window.innerWidth;this.canvas.height=window.innerHeight}
createParticles(){for(let i=0;i<this.particleCount;i++){this.particles.push({x:Math.random()*this.canvas.width,y:Math.random()*this.canvas.height,vx:(Math.random()-.5)*.5,vy:(Math.random()-.5)*.5,radius:Math.random()*2+1,opacity:Math.random()*.5+.2})}}
updateMouse(e){this.mouse.x=e.clientX;this.mouse.y=e.clientY}
animate(){this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height);this.particles.forEach(particle=>{particle.x+=particle.vx;particle.y+=particle.vy;if(particle.x<0||particle.x>this.canvas.width)particle.vx*=-1;if(particle.y<0||particle.y>this.canvas.height)particle.vy*=-1;particle.x=Math.max(0,Math.min(this.canvas.width,particle.x));particle.y=Math.max(0,Math.min(this.canvas.height,particle.y))});this.drawConnections();this.drawParticles();requestAnimationFrame(()=>this.animate())}
drawConnections(){for(let i=0;i<this.particles.length;i++){for(let j=i+1;j<this.particles.length;j++){const dx=this.particles[i].x-this.particles[j].x;const dy=this.particles[i].y-this.particles[j].y;const distance=Math.sqrt(dx*dx+dy*dy);if(distance<this.connectionDistance){const opacity=(1-distance/this.connectionDistance)*.3;this.ctx.strokeStyle=`rgba(74, 144, 226, ${opacity})`;this.ctx.lineWidth=.5;this.ctx.beginPath();this.ctx.moveTo(this.particles[i].x,this.particles[i].y);this.ctx.lineTo(this.particles[j].x,this.particles[j].y);this.ctx.stroke()}}}
this.particles.forEach(particle=>{const dx=this.mouse.x-particle.x;const dy=this.mouse.y-particle.y;const distance=Math.sqrt(dx*dx+dy*dy);if(distance<this.mouseConnectionDistance){const opacity=(1-distance/this.mouseConnectionDistance)*.6;this.ctx.strokeStyle=`rgba(74, 144, 226, ${opacity})`;this.ctx.lineWidth=1;this.ctx.beginPath();this.ctx.moveTo(this.mouse.x,this.mouse.y);this.ctx.lineTo(particle.x,particle.y);this.ctx.stroke()}})}
drawParticles(){this.particles.forEach(particle=>{const dx=this.mouse.x-particle.x;const dy=this.mouse.y-particle.y;const distance=Math.sqrt(dx*dx+dy*dy);let glowIntensity=0;if(distance<this.mouseConnectionDistance){glowIntensity=(1-distance/this.mouseConnectionDistance)*.8}
this.ctx.beginPath();this.ctx.arc(particle.x,particle.y,particle.radius,0,Math.PI*2);this.ctx.fillStyle=`rgba(74, 144, 226, ${particle.opacity+glowIntensity})`;this.ctx.fill()})}}
new SpiderWeb();
    </script>
</body>
</html>