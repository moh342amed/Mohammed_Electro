<?php
// api_get_products.php

header('Content-Type: application/json');
require_once 'config.php';
requireLogin();

$branch_id = $_SESSION['branch_id'];
$response = ['status' => 'error', 'products' => []];

try {
    // This complex query does the following:
    // 1. Gets products available in the current user's branch (from branch_stock).
    // 2. For each product, it finds the ID of the MOST RECENT distribution record 
    //    for that specific product and branch.
    // 3. It then joins with stock_distribution again using that ID to fetch the correct cash_selling_price.
    $stmt = $pdo->prepare(
        "SELECT 
            p.id, 
            p.name, 
            bs.quantity,
            sd.cash_selling_price AS cash_price
         FROM products p
         JOIN branch_stock bs ON p.id = bs.product_id
         LEFT JOIN stock_distribution sd ON sd.id = (
             SELECT MAX(id) 
             FROM stock_distribution 
             WHERE product_id = p.id AND branch_id = :branch_id
         )
         WHERE bs.branch_id = :branch_id AND bs.quantity > 0
         ORDER BY p.name"
    );
    $stmt->execute(['branch_id' => $branch_id]);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $response['status'] = 'success';
    $response['products'] = $products;

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);