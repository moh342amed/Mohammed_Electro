<?php
require_once 'config.php';
requireLogin();
$branch = getBranchInfo($pdo, $_SESSION['branch_id']);
if ($branch['username'] !== 'ElOued') {
    die('Access Denied: This page is for the main branch only.');
}

// Handle Add/Edit/Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_product'])) {
        $stmt = $pdo->prepare("INSERT INTO products (name, description) VALUES (?, ?)");
        $stmt->execute([$_POST['name'], $_POST['description']]);
    }
    header("Location: manage_products.php");
    exit();
}

$products = $pdo->query("SELECT * FROM products ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المنتجات</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #161332ff;
            --secondary-color: #d1d1f7;
            --background-color: #f0f2f5;
            --card-bg-color: rgba(255, 255, 255, 0.6);
            --text-color: #333;
            --header-text-color: #ffffff;
            --shadow-color: rgba(106, 90, 249, 0.2);
            --font-family: 'Cairo', sans-serif;
            --success-color: #28a745;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: var(--font-family);
            background-color: var(--background-color);
            line-height: 1.6;
            color: var(--text-color);
            background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        .header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #8A2BE2 100%);
            color: var(--header-text-color);
            padding: 1.5rem 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .header-content {
            max-width: 900px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        /* --- CSS FIX: Style for the header link --- */
        .header-content a {
            color: var(--header-text-color);
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: background 0.3s ease;
        }
        .header-content a:hover {
            background: rgba(255, 255, 255, 0.15);
        }
        /* --- END OF FIX --- */
        .container { max-width: 900px; margin: 2rem auto; padding: 0 2rem; }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .page-header h1 { color: var(--primary-color); }
        .btn {
            padding: 0.75rem 1.5rem;
            color: #fff;
            text-decoration: none;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.15); }
        .btn-primary { background: var(--primary-color); }
        .btn-secondary { background: #161332ff; }
        .card {
            background: var(--card-bg-color);
            border-radius: 15px;
            padding: 2.5rem;
            box-shadow: 0 10px 30px var(--shadow-color);
            border: 1px solid rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            margin-bottom: 2.5rem;
        }
        .card h3 {
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            padding-bottom: 0.75rem;
            border-bottom: 3px solid var(--primary-color);
            font-size: 1.5rem;
        }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; margin-bottom: .5rem; font-weight: 500; font-size: 0.9rem; color: #444; }
        input[type="text"], textarea {
            width: 100%;
            padding: 0.8rem 1rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            font-family: var(--font-family);
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        textarea { min-height: 100px; resize: vertical; }
        input[type="text"]:focus, textarea:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px var(--secondary-color);
        }
        .table-responsive { overflow-x: auto; }
        .styled-table { width: 100%; border-collapse: collapse; }
        .styled-table th, .styled-table td { padding: 1rem; text-align: right; border-bottom: 1px solid #ddd; }
        .styled-table th { background: rgba(22, 19, 50, 0.05); }
        .styled-table tbody tr:hover { background-color: rgba(230, 230, 250, 0.7); }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1>إدارة المنتجات</h1>
            <a href="index.php">العودة للرئيسية</a>
        </div>
    </header>

    <div class="container">
        <div class="page-header">
            <a href="inventory.php" class="btn btn-secondary">العودة إلى لوحة التحكم بالمخزون</a>
        </div>
        
        <div class="card">
            <h3>إضافة منتج جديد</h3>
            <form method="POST">
                <div class="form-group">
                    <label for="name">اسم المنتج</label>
                    <input type="text" id="name" name="name" placeholder="مثال: تلفاز سامسونج 55 بوصة" required>
                </div>
                <div class="form-group">
                    <label for="description">وصف المنتج (اختياري)</label>
                    <textarea id="description" name="description" placeholder="مثال: Smart TV, 4K UHD"></textarea>
                </div>
                <button type="submit" name="add_product" class="btn btn-primary">إضافة المنتج</button>
            </form>
        </div>

        <div class="card">
            <h3>المنتجات الحالية</h3>
            <div class="table-responsive">
                <table class="styled-table">
                    <thead>
                        <tr>
                            <th>الاسم</th>
                            <th>الوصف</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($products)): ?>
                            <tr><td colspan="2" style="text-align: center; padding: 2rem;">لم تتم إضافة أي منتجات بعد.</td></tr>
                        <?php else: ?>
                            <?php foreach($products as $product): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($product['name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($product['description']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>