<?php
require_once 'config.php';
requireLogin();

// Ensure only an admin can run this critical script
$branch = getBranchInfo($pdo, $_SESSION['branch_id']);
if ($branch['username'] !== 'ElOued') {
    die('ACCESS DENIED: Only the main admin branch can run this script.');
}

echo '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>تحديث تواريخ الاستحقاق</title>';
echo '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">';
echo '<style>body { font-family: "Cairo", sans-serif; background-color: #f0f2f5; padding: 40px; text-align: center; } .container { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); display: inline-block; } h1 { color: #161332; } p { color: #333; font-size: 1.2rem; } .success { color: #157347; } .error { color: #bb2d3b; } a { display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #6a5af9; color: #fff; text-decoration: none; border-radius: 5px; } </style>';
echo '</head><body><div class="container">';

try {
    $pdo->beginTransaction();

    // Find all sub_transactions that have not been updated yet (deduction_date is NULL)
    // and join with their parent transaction to get the original start/confirmation date.
    $stmt_select = $pdo->prepare("
        SELECT 
            st.id as sub_transaction_id, 
            st.sub_reference_id,
            t.id as transaction_id,
            t.confirmed_at,
            t.start_date
        FROM sub_transactions st
        JOIN transactions t ON st.transaction_id = t.id
        WHERE st.deduction_date IS NULL
        ORDER BY t.id, st.id -- Process them in order
    ");
    $stmt_select->execute();
    $sub_transactions_to_fix = $stmt_select->fetchAll(PDO::FETCH_ASSOC);

    if (empty($sub_transactions_to_fix)) {
        echo '<h1>لا يوجد شيء لتحديثه</h1>';
        echo '<p class="success">جميع سجلات الاقتطاعات تحتوي بالفعل على تاريخ استحقاق. لا يلزم اتخاذ أي إجراء.</p>';
        echo '<a href="transactions.php">العودة إلى صفحة العمليات</a>';
        exit('</div></body></html>');
    }

    // Group by transaction to correctly calculate month offsets
    $grouped_by_tx = [];
    foreach ($sub_transactions_to_fix as $sub) {
        $grouped_by_tx[$sub['transaction_id']][] = $sub;
    }

    $update_count = 0;
    $stmt_update = $pdo->prepare("UPDATE sub_transactions SET deduction_date = ? WHERE id = ?");

    foreach ($grouped_by_tx as $transaction_id => $subs) {
        // Use the transaction's specific start_date if it exists, otherwise fall back to the confirmation date
        $base_date_str = $subs[0]['start_date'] ?: $subs[0]['confirmed_at'];
        if (!$base_date_str) {
            echo "<p class='error'>تحذير: تم تخطي العملية رقم $transaction_id لعدم وجود تاريخ تأكيد.</p>";
            continue;
        }
        
        $base_date = new DateTime($base_date_str);
        
        // Iterate through each installment for THIS transaction and assign a sequential date
        $month_offset = 0;
        foreach ($subs as $sub_to_fix) {
            $current_due_date = clone $base_date;
            $current_due_date->modify("+$month_offset months");
            $new_date = $current_due_date->format('Y-m-d');
            
            $stmt_update->execute([$new_date, $sub_to_fix['sub_transaction_id']]);
            $update_count++;
            $month_offset++;
        }
    }

    $pdo->commit();

    echo '<h1>نجاح!</h1>';
    echo '<p class="success">تم تحديث تواريخ الاستحقاق لـ <strong>' . $update_count . '</strong> سجل اقتطاع بنجاح.</p>';
    echo '<p>يمكنك الآن العودة إلى صفحة العمليات ورؤية جميع بياناتك السابقة بشكل صحيح.</p>';
    echo '<p style="color:red; font-weight:bold;">مهم: يرجى حذف هذا الملف (migrate_old_dates.php) الآن.</p>';

} catch (Exception $e) {
    $pdo->rollBack();
    echo '<h1>حدث خطأ!</h1>';
    echo '<p class="error">لم يتم إجراء أي تغييرات. الخطأ: ' . htmlspecialchars($e->getMessage()) . '</p>';
}

echo '<a href="transactions.php">العودة إلى صفحة العمليات</a>';
echo '</div></body></html>';