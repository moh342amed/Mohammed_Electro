<?php
header('Content-Type: application/json');
require_once 'config.php';

if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Customer ID.']);
    exit();
}

$customer_id = (int)$_GET['id'];
$response = [
    'status' => 'success',
    'is_delinquent' => false,
    'active_transactions' => 0,
    'total_transactions' => 0
];

try {
    $first_day_of_current_month = date('Y-m-01');
    $delinquency_sql = "
        SELECT 1 FROM transactions t
        JOIN sub_transactions st ON t.id = st.transaction_id
        WHERE t.customer_id = ?
        AND t.status = 'confirmed'
        AND st.payment_status = 'unpaid'
        AND st.deduction_date < ?
        GROUP BY t.id
        HAVING COUNT(DISTINCT DATE_FORMAT(st.deduction_date, '%Y-%m')) >= 3
        LIMIT 1
    ";
    $stmt_delinquent = $pdo->prepare($delinquency_sql);
    $stmt_delinquent->execute([$customer_id, $first_day_of_current_month]);
    if ($stmt_delinquent->fetch()) {
        $response['is_delinquent'] = true;
    }

    $active_trans_sql = "
        SELECT 
            COUNT(CASE WHEN status = 'confirmed' AND (end_date IS NULL OR end_date >= CURDATE()) THEN 1 END),
            COUNT(CASE WHEN status = 'confirmed' THEN 1 END)
        FROM transactions
        WHERE customer_id = ?
    ";
    $stmt_active = $pdo->prepare($active_trans_sql);
    $stmt_active->execute([$customer_id]);
    list($active_count, $total_count) = $stmt_active->fetch(PDO::FETCH_NUM);
    
    $response['active_transactions'] = (int)$active_count;
    $response['total_transactions'] = (int)$total_count;

} catch (Exception $e) {
    $response['status'] = 'error';
    $response['message'] = 'Database query failed: ' . $e->getMessage();
}

echo json_encode($response);
exit();